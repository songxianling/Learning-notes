/**
 * Created by Weil on 16/3/26.
 */

const MAX_LEN = 140;

MAX_LEN - "user input str len";