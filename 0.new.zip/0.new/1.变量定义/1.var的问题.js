
/**
 * Created by Weil on 16/3/26.
 */

//for ( var i = 0; i < 3; i++ ) {
//  setTimeout(function () {
//    alert(i);
//  })
//}

//for ( let i = 0; i < 3; i++ ) {
//  setTimeout(function () {
//    alert(i);
//  })
//}

// i, j, k

for (let i = 0; i < 2; i++) {
  console.log('out' + i);
  for (let i = 0; i < 2; i++) {
    console.log('in' + i);
  }
  console.log('---');
}



{
  let a = '1';
}

{
  let a = '2';
}










