/**
 * Created by Weil on 16/3/26.
 */
'use strict';

let arr = [1, [2.1, 2.2], 3];

let [a, [b1, b2], c, d] = arr;
//let a = arr[0];
//let b = arr[1];
//let c = arr[2];
//let d = arr[3];
console.log(a, b1, b2 , c, d);