/**
 * Created by Weil on 16/3/26.
 */
'use strict';

// ...

let arr = [0, 1, 2, 3 ,4, 5];
let [a, b, ...other] = arr;

console.log(a, b, other);