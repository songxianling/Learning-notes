/**
 * Created by Weil on 16/3/27.
 */

let arr = ['a', 'b', 'c'];

// 数组的迭代
let en = arr.entries();

console.log(en);

for (item of arr) {
  console.log(item);
}



