/**
 * Created by Weil on 16/3/27.
 */
let body = document.body;

let map = new Map([[1, 2], ['a', 'b'], [body, 'imbody']]);
let obj = {1: 2, 'a': 'b', [body]: 'imbody'};
console.log(map, obj);
















