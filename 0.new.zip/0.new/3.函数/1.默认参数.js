/**
 * Created by Weil on 16/3/26.
 */


// $.ajax

//$.ajax({
//  url: '',
//  type: 'get',
//  data: {},
//  success: function () {
//
//  },
//  isCatch: false
//});

//function ajax (url = 'zf.cn', type = 'get', data, success, error) {
//  console.log(url, type);
//}
//
//ajax('zf.com');

// 弱类语言
// TypeScript

function ajax ({url, type} = {url: 'zf.cn', type: 'get'}) {

}





























