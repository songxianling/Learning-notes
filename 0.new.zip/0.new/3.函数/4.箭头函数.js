/**
 * Created by Weil on 16/3/26.
 */

//let func = function () {
//
//};
//
//function func2 () {
//
//}

//

//let func = () => {
//
//};

let func2 = (x, y) => {
  return x+y;
};

let res = func2(6, 7);
console.log(res);








