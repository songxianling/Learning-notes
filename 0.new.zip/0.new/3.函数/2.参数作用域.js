/**
 * Created by Weil on 16/3/26.
 */

let a = 'out_a';
let b = 'out_b';

function func (a, b) {
  console.log(a, b)
}

func('give_a');