/**
 * Created by Weil on 16/3/27.
 */

let str = '😂132';
let arr = [...str];

// console.log(str, str.length);
console.log(arr.length);

for (let item of str) {
  console.log(item);
}
