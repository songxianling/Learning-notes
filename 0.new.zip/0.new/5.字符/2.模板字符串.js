/**
 * Created by Weil on 16/3/27.
 */


let body = document.body;
let a = '1289217893312789';

let str = `front${body}end`;

console.log(str);
