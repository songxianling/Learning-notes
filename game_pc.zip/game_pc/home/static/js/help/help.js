define('home.static.js.help.help', function () {

    
})