define('home.static.js.article.article_list', function () {

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scParAd = $(".sc_article_default_ad");

    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/article/default";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = "gamecenter_articlelist_pagead";

        comAjax.commonAjax(postUrl,data); 
    })

})