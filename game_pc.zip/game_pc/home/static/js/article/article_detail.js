define('home.static.js.article.article_detail', function () {

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_article_default");
    var $scParAd = $(".sc_article_default_ad");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/article/default/view";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parent('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_gift_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/article/default/view";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = "gamecenter_articleddetail_pagead";

        comAjax.commonAjax(postUrl,data); 
    })

})