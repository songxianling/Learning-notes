define('home.static.js.index.error404', function () {
	var timebox = $('.js-timebox');
	var timer;
	var time = 5;
	function init(){
		timer = setInterval(function(){
			time--;
			timebox.text(time);
			if(time == 0){
				window.location.href = '/';
				clearInterval(timer);
			}
		},1000);
	}
	function clear(){
		clearInterval(timer);
	}
	init();
	return {clear:clear};
})