define('home.static.js.index.index', function () {

	
})