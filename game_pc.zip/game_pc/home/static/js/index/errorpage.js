define('home.static.js.index.errorpage', function () {
	var url = $("#p-common-error-returnurl").val(),
		time = $("#p-common-error-time").val();
		setTimeout(function(){
			window.location.href = url;
		},time)	
})