<?php
return array(
array("id"=>"297","name"=>"暗黑黎明","firstletter"=>"A","spelling"=>"anheiliming","pic"=>"/assets/upload/Data/gamepic/10/caaf5e9a9edba619ba49b74b2ea28713.jpg","goodsid"=>array("20","10","13","14")),
array("id"=>"374","name"=>"COS大乱斗","firstletter"=>"C","spelling"=>"cosdaluandou","pic"=>"/assets/upload/Data/gamepic/17/d1c29c0f9b953d94d1da98a74afbb527.jpg","goodsid"=>array("20","14")),
array("id"=>"5","name"=>"刀塔传奇","firstletter"=>"D","spelling"=>"daotachuanqi","pic"=>"/assets/upload/Data/gamepic/7/e7d74b8c160b7d3ca9314349cc4c7ba8.jpg","goodsid"=>array("20","10","14")),
array("id"=>"2","name"=>"放开那三国","firstletter"=>"F","spelling"=>"fangkainasanguo","pic"=>"/assets/upload/Data/gamepic/22/f6d59350001709c87d51217ef2707b75.jpg","goodsid"=>array("20","10","14")),
array("id"=>"1003","name"=>"九阴真经","firstletter"=>"J","spelling"=>"jiuyinzhenjing","pic"=>"/assets/upload/Data/gamepic/18/f2e0ff25ef8914e2f0359fd38450a0e6.png","goodsid"=>array("14")),
array("id"=>"275","name"=>"乱斗西游","firstletter"=>"L","spelling"=>"luandouxiyou","pic"=>"/assets/upload/Data/gamepic/7/67f70e5dd81e65b15a89312906c9a292.jpg","goodsid"=>array("20")),
array("id"=>"352","name"=>"梦幻西游","firstletter"=>"M","spelling"=>"menghuanxiyou","pic"=>"","goodsid"=>array("20","10","14")),
array("id"=>"4","name"=>"秦时明月","firstletter"=>"Q","spelling"=>"qinshimingyue","pic"=>"/assets/upload/Data/gamepic/20/541c9272b6a06a0a649d1934ebb347ac.jpg","goodsid"=>array("10","14")),
array("id"=>"290","name"=>"全民奇迹","firstletter"=>"Q","spelling"=>"quanminqiji","pic"=>"/assets/upload/Data/gamepic/1/413fd4d3ab07f265166b22eb7dcb65ed.png","goodsid"=>array("20","10","14","17")),
	);