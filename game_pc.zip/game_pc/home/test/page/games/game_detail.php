<?php





$fis_data = array(
    'ImageServerHost' => 'http://img.taoshouyou.com',
    // 'ImageServerHost' => 'http://192.168.0.10:8088',
    
    'game2goodsIndex' => $game2goodsIndex,
    'title' => '淘手游-最具影响力的手游交易第一平台',
    'lang' => 'en-US',
    'CsrfParam' => "_csrf",
    'CsrfToken' => "eVQ1OTgzSEZAHXdqbWV4DSA5WXEBZiw1OxV0T1AGKX8KGH8IUH58MA==",
    'description' => '淘手游—国内最安全、最权威、服务最完善的手游交易第一平台：提供最具性价比的游戏账号、装备、金币，手游代充等自由买卖、担保寄售交易、安全快捷！淘手游手游交易平台。',
    'metakeyword' => '淘手游,淘手游交易平台,淘手游官网,淘手游手游交易平台,手游交易,手游交易平台,手游交易网,手机游戏交易,手机游戏交易平台',
    // 'imgHost' => 'http://img.taoshouyou.com',
    'imgHost' => 'http://192.168.0.10:8088',
    'user' => [
        "isGuest"=>true,    //用户是否匿名访问，在YII中用Yii::$app->user->isGuest获取 
        'username' => '张三',
        'mobile' => '',
        'pic' => '/img/2015-08-03/8/a7ad78745af1057747880b7816e5bfc2.png', //用户头像
    ],
    "ControllerUniqueId" => "indexpage/indexs",  //Controller的唯一id
    'bannerlist' => array(
        array(
            'id' => '1',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 1
        ),
        array(
            'id' => '3',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 2
        ),array(
            'id' => '2',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 3
        ),array(
            'id' => '4',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 4
        )
        ,array(
            'id' => '5',
            'name' => '图片55',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=6',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 5
        ),
    ),
    'promoteUrl' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=6',
    'wd' => 132,
    'game' => array(
        'id' => '1',
        'name' => '梦幻西游',
        'categoryid' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
        'quit_game_cashback_ratio' => '15.00',
        'has_android' => '0',
        'has_ios' => '1',
        'pic' => '',
        'spelling' => '',
        'addtime' => '20016-06-27',
        'vendor_name' => '淘手游',
        'ischarge' => '1',
        'render_engine' => '2',
        'support_system' => 'Android 4.0以上',
        'score' => '9.7',
        'comment' => '2016国民手游，网易手游史诗级巨作，新门派化生寺 隆重登场，人人都玩，无处不在！人人都玩，无处不 在！',
        'extra_info' => '<span>梦幻西游游戏官方群：1234567775</span><span>官方游戏QQ客服：39102832</span>',
        'gamepic' => array(
            0 => '/img/2016-07-25/12/4e25b54a5a16a7ee4fdde76d3c92e190-pc-l.jpg',
            1 => '/img/2016-07-25/24/8583d8149a55a2ee9d4daf7f6197bd4d-pc-l.jpg',
            2 => '/img/2016-07-25/9/c074810108ecd2a7d6a634f299148de0-pc-l.jpg',
            3 => '/img/2016-07-25/22/4eb8f9babf2364ed6ebcc08e22735b85-pc-l.jpg',
            4 => '/img/2016-07-25/4/30b5346ee826896bfe2a38708e4514df-pc-l.jpg'
        ),
        'introduce' => '<p>梦幻西游安卓版中不论是场景还是整个的画面的设计都是具有玄幻色彩的，这里的整个的作品气息都笼罩在了古典之中，而再加上Q萌的角色，这样的配置会骚乱你的心哦，休闲时间挑战本作，展开西游新的梦哦。该作只要是你进入了，就能被其中的仙气的画面相融合，而那些视觉上的特色也是精致的哦。</p><p>【游戏特色】</p><p>-人人都玩，无处不在</p><p>《梦幻西游》手游自问世以来，新增注册用户突破1亿，并凭不竭魅力，源源不断的吸引新玩家，用事实证明国民手游的卓越品质。而在未来，它还将不断改写历史，为每一个玩家延续自己的西游剑侠情缘！</p>',
        'download_count' => '24444',
        'android_qrpic' => '12345.html',
        'android_download_url' => '12345.html',
        'ios_qrpic' => '24325435.jpg',
        'ios_download_url' => 'img.img.jpg',
        'categoryname' => '角色扮演'
    ),
    'articles' => array(
        array(
            'id' => '1',
            'gameid' => '1',
            'title' => '热血传奇巅峰巨作，经典强势回归！《赤血屠龙》8月5日不删档震撼公测！',
            'pic' => '/img/2016-07-26/31/798d2d221b860fca2bbb1b228b1a3a6e.jpg',
            'introduction' => '还停留在杀公鸡打猪的年代？！你OUT了！新版传奇巨献《赤血屠龙》，带你领略不一样的厮杀盛宴！\r\n新增游戏特色系统，VIP专属BOSS地图，顶级公会团战BOSS，日日团战厮杀自由PK！砍人砍到手软！炫酷挖宝系统，极品装备尽收囊中！押镖系统滚滚金币赚不停！更有超多炫目技能提升！只等你来战！',
            'typename' => '新闻'
        ),
        array(
            'id' => '1',
            'gameid' => '1',
            'title' => '热血传奇巅峰巨作，经典强势回归！《赤血屠龙》8月5日不删档震撼公测！',
            'pic' => '/img/2016-07-26/31/798d2d221b860fca2bbb1b228b1a3a6e.jpg',
            'introduction' => '还停留在杀公鸡打猪的年代？！你OUT了！新版传奇巨献《赤血屠龙》，带你领略不一样的厮杀盛宴！\r\n新增游戏特色系统，VIP专属BOSS地图，顶级公会团战BOSS，日日团战厮杀自由PK！砍人砍到手软！炫酷挖宝系统，极品装备尽收囊中！押镖系统滚滚金币赚不停！更有超多炫目技能提升！只等你来战！',
            'typename' => '新闻'
        ),
        array(
            'id' => '1',
            'gameid' => '1',
            'title' => '热血传奇巅峰巨作，经典强势回归！《赤血屠龙》8月5日不删档震撼公测！',
            'pic' => '/img/2016-07-26/31/798d2d221b860fca2bbb1b228b1a3a6e.jpg',
            'introduction' => '还停留在杀公鸡打猪的年代？！你OUT了！新版传奇巨献《赤血屠龙》，带你领略不一样的厮杀盛宴！\r\n新增游戏特色系统，VIP专属BOSS地图，顶级公会团战BOSS，日日团战厮杀自由PK！砍人砍到手软！炫酷挖宝系统，极品装备尽收囊中！押镖系统滚滚金币赚不停！更有超多炫目技能提升！只等你来战！',
            'typename' => '新闻'
        ),
        array(
            'id' => '1',
            'gameid' => '1',
            'title' => '热血传奇巅峰巨作，经典强势回归！《赤血屠龙》8月5日不删档震撼公测！',
            'pic' => '/img/2016-07-26/31/798d2d221b860fca2bbb1b228b1a3a6e.jpg',
            'introduction' => '还停留在杀公鸡打猪的年代？！你OUT了！新版传奇巨献《赤血屠龙》，带你领略不一样的厮杀盛宴！\r\n新增游戏特色系统，VIP专属BOSS地图，顶级公会团战BOSS，日日团战厮杀自由PK！砍人砍到手软！炫酷挖宝系统，极品装备尽收囊中！押镖系统滚滚金币赚不停！更有超多炫目技能提升！只等你来战！',
            'typename' => '新闻'
        ),
        array(
            'id' => '1',
            'gameid' => '1',
            'title' => '热血传奇巅峰巨作，经典强势回归！《赤血屠龙》8月5日不删档震撼公测！',
            'pic' => '/img/2016-07-26/31/798d2d221b860fca2bbb1b228b1a3a6e.jpg',
            'introduction' => '还停留在杀公鸡打猪的年代？！你OUT了！新版传奇巨献《赤血屠龙》，带你领略不一样的厮杀盛宴！\r\n新增游戏特色系统，VIP专属BOSS地图，顶级公会团战BOSS，日日团战厮杀自由PK！砍人砍到手软！炫酷挖宝系统，极品装备尽收囊中！押镖系统滚滚金币赚不停！更有超多炫目技能提升！只等你来战！',
            'typename' => '新闻'
        )
    ),
    'newGifts' => array(
        array(
            'gift_name' => '梦幻西游新手礼包梦幻西游新手礼包',
            'gift_pic' => '/img/2016-09-01/12/a26f46089d84179cae8d125188cc60fa-pc-l.jpg',
            'gameid' => '热血传奇巅峰巨作，经典强势回归！《赤血屠龙》8月5日不删档震撼公测！',
            'id' => '1'
        ),
        array(
            'gift_name' => '梦幻西游新手礼包梦幻西游新手礼包',
            'gift_pic' => '/img/2016-09-01/12/a26f46089d84179cae8d125188cc60fa-pc-l.jpg',
            'gameid' => '1',
            'id' => '1'
        ),
    ),
    'relatedGames' => array(
        array(
            'id' => '1',
            'name' => '炼妖壶传奇',
            'has_android' => '1',
            'has_ios' => '1',
            'pic' => '/img/2016-08-08/6/8268e4d027d456c63106deed07baa764-pc-l.jpg',
            'spelling' => '1',
            'download_count' => '234'
        ),
        array(
            'id' => '1',
            'name' => '炼妖壶传奇',
            'has_android' => '1',
            'has_ios' => '1',
            'pic' => '/img/2016-08-08/6/8268e4d027d456c63106deed07baa764-pc-l.jpg',
            'spelling' => '1',
            'download_count' => '234'
        ),
        array(
            'id' => '1',
            'name' => '炼妖壶传奇',
            'has_android' => '1',
            'has_ios' => '1',
            'pic' => '/img/2016-08-08/6/8268e4d027d456c63106deed07baa764-pc-l.jpg',
            'spelling' => '1',
            'download_count' => '234'
        ),
        array(
            'id' => '1',
            'name' => '炼妖壶传奇',
            'has_android' => '1',
            'has_ios' => '1',
            'pic' => '/img/2016-08-08/6/8268e4d027d456c63106deed07baa764-pc-l.jpg',
            'spelling' => '1',
            'download_count' => '234'
        ),
        array(
            'id' => '1',
            'name' => '炼妖壶传奇',
            'has_android' => '1',
            'has_ios' => '1',
            'pic' => '/img/2016-08-08/6/8268e4d027d456c63106deed07baa764-pc-l.jpg',
            'spelling' => '1',
            'download_count' => '234'
        )
    ),
    'topiclist' => array(
        array(
            'id' => '1',
            'title' => '1D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-08-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),
        array(
            'id' => '2',
            'title' => '2D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),array(
            'id' => '3',
            'title' => '3D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),array(
            'id' => '4',
            'title' => '4D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),
    ),
    "recommendShopsList" => [
        0 => [
            'onlineTradeNum' => 0,
            'shopname' => '赵科平的店',
            'recommendedindex' => '3',
            'shoppic' => null,
            'id' => '406'
        ],
        1 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        2 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        3 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        4 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
    ],
    "tradelogcountModel" => "1000",  //安全成交笔数
    "tradeloglistModel" => array(    //右侧最新成交数量
        array(
            "tradeid" => 198607,
            "tradename" => "飒飒的"
        ),array(
            "tradeid" => 198605,
            "tradename" => "用途图一图一"
        ),array(
            "tradeid" => 198605,
            "tradename" => "123123"
        ),array(
            "tradeid" => 198605,
            "tradename" => "432423"
        ),
    ),
    "initiallist" => ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"],
    'recommandgamelist' => $recommandgamelist,
    'tradehighqualitylistModel' =>$tradehighqualitylistModel,
    'tradelistModel' =>$tradelistModel,
    'helpModel' => $helper,
    'complaintModel' => array(array("id"=>"3", "title"=>"111111111111111", ),array("id"=>"2", "title"=>"1111111111", ),array("id"=>"1", "title"=>"111"),array("id"=>"4", "title"=>"111"),array("id"=>"5", "title"=>"111"),array("id"=>"6", "title"=>"111") ),
    'noticelistModel' => $noticelistModel,
    'friendLink' => array(
        array(
            'id' => '1',
            'name' => '手游交易',
            'url' => 'http://www.taoshouyou.com'
        ),
        array(
            'id' => '3',
            'name' => '手机游戏专区',
            'url' => 'http://www.gao7.com/zq/'
        ),array(
            'id' => '2',
            'name' => '苹果角色扮演游戏下载',
            'url' => 'http://app.tongbu.com/iphone-jiaoseyouxi/苹果角色扮演游戏下载'
        )
    ),
    'pageadlist' => array(
        'isshow' => 1,
        'href' => 'http://www.baidu.com',
        'title' => '所得税地方',
        'picurl' => '/img/2016-05-05/23/72711197f7a22d345f7df4409cc277c0-pc-l.jpg',
    ),
    'pageadlistfloat' => array(
        'isshow' => 1,
        'href' => 'http://www.baidu.com',
        'title' => '所得税地方',
        'picurl' => '/img/2016-05-05/23/72711197f7a22d345f7df4409cc277c0-pc-l.jpg',
    ),
    'gameitem' => [
            "downloaurl" => "www.tsy.com",
            "pic" => "http://img.taoshouyou.com/img/2016-05-16/23/7b3332a1f9380660b23a7af17ba6533b-pc-l.jpg",
            "comment" => "芈月传」官方唯一正版授权手游，尽展历史上战国第一美女皇帝的传奇一生。",
            "name" => "芈月传",
            "os" => "0",
            "categoryname" => "角色扮演",
            "version" => "1.4.2",
            "updatetime" => "2016-05-01",
            "vendor_name" => "蓝港互动",
            "ischarge" => 0,
            "support_system" => "ios 1.5以上",
            "language" => 0,
            "size" => "4.5M",
            "erweima" => "http://www.taoshouyou.com/static/common/widget/common/floatright/img/appdownload_d49f3d0.jpg",
            "downloaurl" => "www.tsy.com",
            "gameimg" => ["http://127.0.0.1:8080/static/home/widget/download/common/img/img1_c154b45.png","http://127.0.0.1:8080/static/home/widget/download/common/img/img2_ba00b9d.png","http://127.0.0.1:8080/static/home/widget/download/common/img/img1_c154b45.png","http://127.0.0.1:8080/static/home/widget/download/common/img/img1_c154b45.png","http://127.0.0.1:8080/static/home/widget/download/common/img/img1_c154b45.png"],
            "introduce" => "《芈月传》是孙俪、刘涛主演同名电视剧官方唯一正版授权手游，由金牌导演郑晓龙全程监制，蓝港互动独家发行的全球首款美女国战手游。游戏通过精美的3D画面呈现电影级视听体验，尽展历史上战国第一美女皇帝的传奇一生。国战争雄，女王称霸，尽在《芈月传》官方唯一正版授权手游。【游戏特色】 ·同名电视剧改编《芈月传》电视剧正版授权，金牌导演郑晓龙跨界监制，完美再现电视剧经典剧情、场景和人物，亲历一代枭后的传奇人生！"                              
    ],
    'fiveArticles' => array(
        Array(
            id => 297,
            title => "暗黑黎暗黑黎明1暗黑黎明1明1",
            pic => "img/img.png",
            introduction => "1暗黑黎明暗黑黎明暗黑暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
        ),
        Array(
            id => 297,
            title => "暗黑黎暗黑黎明1暗黑黎明1明1",
            pic => "img/img.png",
            introduction => "2暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
        ),
        Array(
            id => 297,
            title => "暗黑黎暗黑黎明1暗黑黎明1明1",
            pic => "img/img.png",
            introduction => "3暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
        ),
        Array(
            id => 297,
            title => "暗黑黎暗黑黎明1暗黑黎明1明1",
            pic => "img/img.png",
            introduction => "4暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
        ),
        Array(
            id => 297,
            title => "暗黑黎暗黑黎明1暗黑黎明1明1",
            pic => "img/img.png",
            introduction => "5暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
        ),
    ),
);
// var_dump($fis_data["recommandgamelist"]);