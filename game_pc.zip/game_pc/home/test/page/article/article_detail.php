<?php

$fis_data = array(
    'title' => '淘手游-最具影响力的手游交易第一平台',
    'lang' => 'en-US',
    'CsrfParam' => "_csrf",
    'CsrfToken' => "eVQ1OTgzSEZAHXdqbWV4DSA5WXEBZiw1OxV0T1AGKX8KGH8IUH58MA==",
    'description' => '淘手游—国内最安全、最权威、服务最完善的手游交易第一平台：提供最具性价比的游戏账号、装备、金币，手游代充等自由买卖、担保寄售交易、安全快捷！淘手游手游交易平台。',
    'metakeyword' => '淘手游,淘手游交易平台,淘手游官网,淘手游手游交易平台,手游交易,手游交易平台,手游交易网,手机游戏交易,手机游戏交易平台',
    //'imgHost' => 'http://192.168.0.10:8088',
    'user' => [
        "isGuest"=>true,    //用户是否匿名访问，在YII中用Yii::$app->user->isGuest获取 
        'username' => '张三',
        'mobile' => '',
        'pic' => '/img/2015-08-03/8/a7ad78745af1057747880b7816e5bfc2.png', //用户头像
    ],
    'pagecount'=>100,
    'pagesize'=>10,
    'pagenumber'=>1,
    'ad' => [
        'id' => '43',
        'title' => '天天裁决游戏下载',
        'picurl' => 'http://img-test.taoshouyou.com/img/2016-08-30/6/8268e4d027d456c63106deed07baa764.jpg',
        'href' => 'http://bj-test-sdk.taoshouyou.com:8095/adminpagead/index',
        'isshow' => '1',
        'position' => '3',
        'type' => '1',
        'addtime' => '2016-08-30 11:56:41'
    ],
    'friendLink' => array(
        array(
            'id' => '1',
            'name' => '手游交易1',
            'url' => 'http://www.taoshouyou.com'
        ),
        array(
            'id' => '3',
            'name' => '手机游戏专区',
            'url' => 'http://www.gao7.com/zq/'
        ),array(
            'id' => '2',
            'name' => '苹果角色扮演游戏下载',
            'url' => 'http://app.tongbu.com/iphone-jiaoseyouxi/苹果角色扮演游戏下载'
        )
    ),
    'crumblist' => array(
        array(
            "active" => true,
            "url"=>'',
            "name"=>"文章详情"
        )
    ),
    'articleResult' => [
        'from' => '淘手游',
        "title" => "芈月传」官方唯一正版授权手游，尽展历史上战国第一美女皇帝的传奇一生。",
        "name" => "芈月传",
        "addtime" => "2016-05-01",
        'author' => "wbg",
        "typename" => "蓝港互动",
        "introduction" => "16年前，一款火爆大陆的端游横空出世，被无数玩家奉为经典；16年后，其经典的玩法，熟悉的场景依然在各大游戏中随处可见。",
        "content" => "《芈月传》是孙俪、刘涛主演同名电视剧官方唯一正版授权手游，由金牌导演郑晓龙全程监制，蓝港互动独家发行的全球首款美女国战手游。游戏通过精美的3D画面呈现电影级视听体验，尽展历史上战国第一美女皇帝的传奇一生。国战争雄，女王称霸，尽在《芈月传》官方唯一正版授权手游。【游戏特色】 ·同名电视剧改编《芈月传》电视剧正版授权，金牌导演郑晓龙跨界监制，完美再现电视剧经典剧情、场景和人物，亲历一代枭后的传奇人生！"                              
    ],
    'searchWord' => "aaa",
    'gameList_search' => array(
        Array(
            id => 297,
            name => "暗黑黎明",
            firstletter => "A",
            spelling => "anheiliming",
            pic => "/img/2015-09-14/1/caaf5e9a9edba619ba49b74b2ea28713.jpg",
            goodsid=>array(20,17,14,13,10)
        ),
        Array(
            id => 314,
            name => "暗黑战神",
            firstletter => "A",
            spelling => "anheizhanshen",
            pic => "/gamepic/314.jpg",
            goodsid=>array(20,14,13)
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg",
            goodsid=>array(20,14,13)
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg"
        ),
        Array(
            id => 325,
            name => "暗黑女王",
            firstletter => "A",
            spelling => "anheinvwang",
            pic => "/gamepic/325.jpg",
            goodsid=>array(20,14,13)
        )
    ),
    'HotArticles' => array(
            Array(
                id => 297,
                title => "暗黑黎暗黑黎明1暗黑黎明1明1",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑暗黑黎明1暗黑黎明1黎明2",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑黎暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1明3",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1黎明",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑黎暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1明",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),   
        ),
    'gamegifts' => array(
            Array(
                id => 297,
                title => "暗黑黎暗黑黎明1暗黑黎明1明1",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑暗黑黎明1暗黑黎明1黎明2",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑黎暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1明3",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1黎明",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),
            Array(
                id => 297,
                title => "暗黑黎暗黑黎明1暗黑黎明1暗黑黎明1暗黑黎明1明",
                pic => "img/img.png",
                typename => "攻略",
                addtime => "2016-06-06 12:00",
                introduction => "暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明"
            ),   
        ),
    'arrIndex' => array(
        Array(10,13,14),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(325),
        Array(325),
        Array(297,314,325),
        Array(297,314),
        Array(297,314),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
        Array(297,314,325),
    ),
    'ImageServerHost' => 'http://img.taoshouyou.com',
    "initiallist" => array(Array(name=>"A"),Array(name=>"B"),Array(name=>"C"),Array(name=>"D"),Array(name=>"E"),Array(name=>"F"),Array(name=>"G"),Array(name=>"H"),Array(name=>"I"),
        Array(name=>"J"),Array(name=>"K"),Array(name=>"L"),Array(name=>"M"),Array(name=>"N"),Array(name=>"O"),Array(name=>"P"),Array(name=>"Q"),Array(name=>"V"),Array(name=>"T"),
        Array(name=>"W"),Array(name=>"X"),Array(name=>"Y"),),
    "letter"=>'A',
);








// var_dump($fis_data["user"]["isGuest"]);