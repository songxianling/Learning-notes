define('home.widget.gifts.list.js.list',function(require,exports,module) {
	var $out = $(".stock .out"),
		$in = $(".stock"),
		$search = $(".js-gift-gift_list_serchbox");

	$(function($){
		var $percent,
			percent,
			outWidth = $out.width(),
			inWidth;

		$in.each(function(){
			$percent = $(this).find("em");
        	percent = parseInt($percent.text())/100;
			inWidth = outWidth*percent;
			$(this).find(".in").width(inWidth);
		});
		$search.on("click",".btn",function(){
			var val = $.trim($search.find("input").val());
			if(val !="" && val !=null){
				window.location.href = "/gift/search?wd="+val;
			}
			
		})
	});

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_gift_index_list");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/index";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parents('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_gift_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })	
	
});
