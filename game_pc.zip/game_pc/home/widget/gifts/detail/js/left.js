define('home.widget.gifts.detail.js.left',function(require,exports,module) {
	var $out = $(".stock .out"),
		$in = $(".stock .in"),
		$percent = $(".stock em"),
		$panelTitle = $(".detail-panel .panel-title"),
		$relatedTitle = $(".related-gift .textL");

	var percent = parseInt($percent.text())/100,
		outWidth = $out.width(),
		inWidth = outWidth*percent;
	$(function($){
		$in.width(inWidth);
	});

	var textL = require("home.widget.article.js.textLength");

    if($panelTitle.length>0){
        $panelTitle.each(function(){
           textL($(this),28);  
        })
    }
    if($relatedTitle.length>0){
        $relatedTitle.each(function(){
           textL($(this),14);  
        })
    }
    /*领取验证码弹窗*/
    var $giftReceive = $("#js-gift-receive");//领取礼包按钮
    var $yzCode = $("#js-yz-code");//领取礼包弹窗
    var $yzCodeClose = $("#js-yz-code .code-close-btn");//关闭弹窗按钮
    var $yzCodeSub = $("#js-yz-code .code-sub-btn");//提交验证码按钮
    var $yzCodeA = $("#js-yz-code .code-img a");//验证码链接
    var $yzCodeImg = $("#js-yz-code .code-img img");//验证码图片
    var $yzCodeInput = $("#js-yz-code .code-input input");//验证码输入框
    var $yzCodeMsg = $("#js-yz-code .code-msg");//温馨提示
    var $giftCopyBox = $("#js-gift-copybox");//复制领取码
    var $yzCodeGiftId = $("#yz-code-gift-id");//礼包ID
    /*点击复制功能*/
    var $iuput = $("#js-gift-num"),
        $btn = $("#js-gift-copyBtn"),
        btnName = "js-gift-copyBtn";

    $giftReceive.on("click",function(){
        $yzCodeInput.val("");
        $yzCodeMsg.text("温馨提示：全部礼包兑换码，可在【个人中心】-【我的礼包】中查看。");
        $yzCode.show();
        refreshVerifyImg($yzCodeImg);
    });
    $yzCodeA.on("click",function(){
        refreshVerifyImg($yzCodeImg);
    });
    $yzCodeSub.on("click",function(){
        refreshVerifySub();
    });
    $yzCodeInput.keydown(function(event){
        switch(event.keyCode){
            case 13:refreshVerifySub();break;
        }
    });
    $yzCodeClose.on("click",function(){
        $yzCode.hide();
    });

    function refreshVerifySub(){
        var code = $yzCodeInput.val();
        var idVal = $yzCodeGiftId.val();
        $.ajax({
            type:'post',
            url:'/gift/default/getexchangecode',
            dataType:'json',
            data:{
                verifycode:code,
                giftid:idVal
            },
            success:function(data){
              if(data.errcode == 0){
                $yzCode.hide();
                $giftReceive.hide();
                $giftCopyBox.show();
                $giftCopyBox.find('#js-gift-num-show').text(data.data.exchange_code);
                $giftCopyBox.find('#js-gift-num').val(data.data.exchange_code);
                /*点击复制功能*/
                btnCopy($iuput,$btn,btnName);
              }else if(data.errcode == 100001){
                 window.location.href=data.data.url+"returnurl="+encodeURIComponent(document.location.href);
              }else{
                $yzCodeMsg.text(data.msg);
              }
            }
        });
    }

    function refreshVerifyImg(obj){
        
        $.getJSON('/gift/default/captcha',{
            refresh:1,
            _: (Math.random() * (100000 + 1))
        },function(data){
            obj.attr('src', ""+data.url+"");
        });

    }



    /*点击复制功能*/

    btnCopy($iuput,$btn,btnName);

    function btnCopy(i,btn,b) {
        
        i.click(function(){
            $(this).select();
        });
        btn.each(function(){
            ZeroClipboard.setMoviePath($(this).attr("data-url"));
            var clip = new ZeroClipboard.Client(); // 新建一个对象
            clip.setHandCursor(true ); // 设置鼠标为手型
            clip.setText(""); // 设置要复制的文本。
            clip.setHandCursor(true);
            clip.setCSSEffects(true);
            clip.addEventListener('complete', function(client, text) {
                alert("礼包兑换码复制成功！" );
            } );
            clip.addEventListener('mouseDown', function(client) {
                clip.setText(i.val());
            } );
            clip.glue(b);
            $(this).click(function(e){
                e.preventDefault();
                alert("啊哦，好像复制失败了……手动复制一下吧！");
            });
        });
    }

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_gift_giftinfo_left");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/giftinfo";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_gift_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })    

});
