define('home.widget.gifts.gift.js.content',function(require,exports,module) {
	var $out = $(".js-stock .out"),
		$in = $(".js-stock"),
		$giftMsg = $(".b-game-gift-list .textL");

	$(function($){
		var $percent,
			percent,
			outWidth = $out.width(),
			inWidth;

		$in.each(function(){
			$percent = $(this).find("em");
        	percent = parseInt($percent.text())/100;
			inWidth = outWidth*percent;
			$(this).find(".in").width(inWidth);
		});
	});

	var textL = require("home.widget.article.js.textLength");

    if($giftMsg.length>0){
        $giftMsg.each(function(){
           textL($(this),20);  
        })
    }

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_gift_list");
    var $scParAd = $(".sc_gift_list_ad");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/list";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parents('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_currentpage = $(this).attr('data-sc-oc')?$(this).attr('data-sc-oc'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/list";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })    

});
