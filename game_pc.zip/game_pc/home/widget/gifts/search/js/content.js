define('home.widget.gifts.search.js.content',function(require,exports,module) {
	var $out = $(".stock .out"),
		$in = $(".stock"),
		$giftMsg = $(".b-game-gift-list .textL");

	$(function($){
		var $percent,
			percent,
			outWidth = $out.width(),
			inWidth;

		$in.each(function(){
			$percent = $(this).find("em");
        	percent = parseInt($percent.text())/100;
			inWidth = outWidth*percent;
			$(this).find(".in").width(inWidth);
		});
	});

	var textL = require("home.widget.article.js.textLength");

    if($giftMsg.length>0){
        $giftMsg.each(function(){
           textL($(this),20);  
        })
    }
	
});
