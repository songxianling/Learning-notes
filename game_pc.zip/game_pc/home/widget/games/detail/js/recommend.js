define('home.widget.games.detail.js.recommend',function(require,exports,module) {
	var $par = $("#js-b-game-detail-ul"),
		$dilog = $(".js-index-common-dilog"),
		$closeBtn = $(".js-index-common-closeBtn"),
		$box = $("#js-downbox");
		
	$par.on("click",".btn-box a.btn",function(){
		var _this = $(this);

		var an = _this.attr("data-an"),
			ios = _this.attr("data-ios"),
			name = _this.attr("data-gamename"),
		    anerweima,
			ioserweima,
			iosdownloadurl,
			andownloadurl;

		$dilog.show();

		$dilog.find(".js-index-common-p1").html(name);
		$box.find("a").hide();
		if( an == 1 ){
			anerweima = _this.attr("data-anErweima");
			andownloadurl = _this.attr("data-anDownload");
			$box.find("a.an img").attr("src",""+anerweima+"");
			$box.find("a.an").show();
			$box.find("a.an").attr("href",""+andownloadurl+"");
			$box.find("a.an").attr("download",""+andownloadurl+"");

		} 

		if( ios == 1){
			ioserweima = _this.attr("data-iosErweima");
			iosdownloadurl = _this.attr("data-iosDownload");
			$box.find("a.io img").attr("src",""+ioserweima+"");
			$box.find("a.io").show();
			$box.find("a.io").attr("href",""+iosdownloadurl+"");
			$box.find("a.io").attr("download",""+iosdownloadurl+"");	
		}

	})
	$closeBtn.on("click",function(){
		$dilog.hide();
	})

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_game_detail_recommend");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parents('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_game_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })

});
