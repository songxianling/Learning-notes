define('home.widget.games.detail.js.news',function(require,exports,module) {

    var $index_box = $("#js-b-game-detail-news-listcont");

	var index_one = ".js-b-game-detail-news-one",
        index_two = ".js-b-game-detail-news-two";
    

    /*首页滑过效果*/
    if($index_box.length>0){
        $index_box.on("mouseover","li",function(){
            $(this).addClass("show-m").removeClass("close-m");
        }).on("mouseleave","li",function(){
            $(this).addClass("close-m").removeClass("show-m");
        })
    }


    /*首页大图*/
    if($(index_one).length>0){
        $(index_one).each(function(){
            textL($(this),150);
        })
        //textL(index_one[i],150);     
    }
    /*首页小图*/
    if($(index_two).length>0){
        $(index_two).each(function(){
            textL($(this),40);
        })
    }

    /*多行溢出为省略号*/
    function textL(d,l){
        var cont = d.html(),
            leng = cont.length,
            html = '';
        if(leng){
            if(leng > l){
                html = cont.slice(0,l);
                d.html(html+"...");
            }
        } 

           
        
    }

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_game_detail_game_news");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parent('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_article_name = $(this).attr('data-sc-oan')?$(this).attr('data-sc-oan'):"";

        comAjax.commonAjax(postUrl,data); 
    })    

});
