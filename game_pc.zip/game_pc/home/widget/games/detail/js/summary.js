define('home.widget.games.detail.js.summary',function(require,exports,module) {

    // 点击展开/收起
    var $summary = $(".js-b-game-detail-summary"),
        $summaryCont = $(".content",$summary),
        $summaryBtn = $(".btn",$summary);
        
    $summaryBtn.on("click",function(){
        if($summary.hasClass("close")){
            $summary.removeClass("close");
            $summaryBtn.find("span").text("点击收起");
        }else{
            $summary.addClass("close");
            $summaryBtn.find("span").text("点击展开");
        }
    });

});
