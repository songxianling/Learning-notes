define('home.widget.index.ad.mp4ad', function () {

	var $videoBox = $("#video-box");
	var $closeBtn = $("#close-btn");

	    $closeBtn.on("click",function(){
	    	document.getElementById('video1').pause();
	    	$videoBox.hide();
	    });

    var commC =  require("common.static.js.common");

	    if(!commC.getCookie("mp4adpc")){
            $videoBox.show();
            document.getElementById('video1').play();
            commC.setCookie("mp4adpc","1",1);
        }else{
            $videoBox.hide();
        }

})
