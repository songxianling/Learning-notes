define('home.widget.index.recommend.recommend', function () {

	var $btnbox = $("#js-b-index-recommend-btnbox"),
        $imgbox = $(".js-p-index-recommend-imgbox"),
        $titbox = $(".js-p-index-recommend-titbox");  

    var len = $imgbox.find("ul>li").length,
        uls = $imgbox.find("ul"),
        tituls = $titbox.find("ul"),
        index = 0,
        timer = "",
        left = ".js-b-index-recommend-left",
        right = ".js-b-index-recommend-right";

        /*设置ul的宽*/
        uls.css({"width":len*400+"px"});

        tituls.css({"width":len*395+"px"});

        /*点击切换事件*/
        $btnbox.on("click",left,function(){
            index++;
            if(index>len-1){
                index=0
            }
            go(index);
        })
        $btnbox.on("click",right,function(){
            index--;
            if(index < 0){
                index=len-1;
            }
            go(index);
        })

        $imgbox.on("mouseover",function(){
            clearInterval(timer);
        })

        $imgbox.off("mouseout").on("mouseout",function(){
            timer = setInterval(function(){
                index ++;
                if(index>len-1){
                    index=0
                }
                go(index);
            },5000)  
        })

        timer = setInterval(function(){
            index ++;
            if(index>len-1){
                index=0
            }
            go(index);
        },5000)

        function go(i){
            uls.css({"-webkit-transform":"translate(-"+i * 400+"px,0)",
                    "-moz-transform":"translate(-"+i * 400+"px,0)",
                        "-ms-transform":"translate(-"+i * 400+"px,0)",
                            "-o-transform":"translate(-"+i * 400+"px,0)",
                                "transform":"translate(-"+i * 400+"px,0)"});


            setTimeout(function(){
                tituls.css({"-webkit-transform":"translate3d(-"+i * 395+"px,0,0)",
                        "-moz-transform":"translate3d(-"+i * 395+"px,0,0)",
                            "-ms-transform":"translate3d(-"+i * 395+"px,0,0)",
                                "-o-transform":"translate3d(-"+i * 395+"px,0,0)",
                                    "transform":"translate3d(-"+i * 395+"px,0,0)"})
            },400)

                

        }

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_index_recommend");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gamecenter/index";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        if($(this).attr('data-sc-ogn')){
            data.opt_game_name = $(this).attr('data-sc-ogn');
        }
        if($(this).attr('data-sc-otn')){
            data.opt_title_name = $(this).attr('data-sc-otn');
        }

        comAjax.commonAjax(postUrl,data); 
    })

});