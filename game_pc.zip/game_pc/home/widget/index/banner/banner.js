define('home.widget.index.banner.banner', function () {
	
    

    function ImgBox(p,i,u,o){

        this.$par = p,
        this.$img = i,
        this.$ul = u,
        this.$ol = o,
        this.$left = $("#imgboxLeft"),
        this.$right = $("#imgboxRight"),
        this.len = this.$ol.find("li").length,
        this.w = 0,
        this.timer = "",

        // 公有属性
        this.evt = {

            imgw:800,
            index:0

        },
        this.init = function(){
            var _this = this;
            
                
            // 设置样式
            _this.w = _this.$par.innerWidth();
            _this.$ul.find("li").css({"width":_this.w+"px"});
            _this.evt.imgw = _this.$img.eq(0).height()>100 ? _this.$img.eq(0).height() :  _this.w/3.1;
            _this.$ul.css({"width":_this.w * _this.len+"px","height":_this.evt.imgw+"px"});
            _this.$par.css({"height":_this.evt.imgw+"px"}) ;
            _this.$par.find("div").css({"top":_this.evt.imgw/2+"px"});
            _this.$ol.show();
            _this.$ol.css({"top":""+_this.evt.imgw-30+"px","margin-left":-_this.len*80/2+"px","width":_this.len*80+20+"px"})
            // 调用点击事件
            _this.move(); 
            
        },
        this.move = function(){
            var _this = this;
            // 左右点击事件
            // left
            _this.$left.off("click").on("click",function(){
                _this.evt.index == 0 ?  _this.evt.index = _this.len-1 : _this.evt.index--;
                clearInterval(_this.timer);
                _this.go();
            })
            // right
            _this.$right.off("click").on("click",function(){
                _this.evt.index ==  _this.len-1 ?  _this.evt.index = 0  : _this.evt.index++;
                clearInterval(_this.timer);
                _this.go();
            })
            // ol li
            this.olgo();

             // 清除定时器
            _this.$par.off("mouseover").on("mouseover",function(){

                clearInterval(_this.timer);
            })
            // 添加定时器
            _this.$par.off("mouseout").on("mouseout",function(){

                _this.timer = setInterval(function(){
                _this.evt.index++;
                if(_this.evt.index > _this.len-1){
                    _this.evt.index = 0;
                }
                _this.go();
            },5000)
            })

        },
        // 执行动画函数
        this.go = function(){
            var _this = this;
            _this.$ul.css(
                {"-webkit-transform":"translate(-"+_this.evt.index * _this.w+"px,0)",
                    "-moz-transform":"translate(-"+_this.evt.index * _this.w+"px,0)",
                        "-ms-transform":"translate(-"+_this.evt.index * _this.w+"px,0)",
                            "-o-transform":"translate(-"+_this.evt.index * _this.w+"px,0)",
                                "transform":"translate(-"+_this.evt.index * _this.w+"px,0)"});
            // ol li 高亮
            _this.$ol.find("li").eq(_this.evt.index).addClass("cur").siblings().removeClass("cur");
            
        },

        // 定时器
        this.autogo = function(){
            var _this = this;
            _this.timer = setInterval(function(){
                _this.evt.index++;
                if(_this.evt.index > _this.len-1){
                    _this.evt.index = 0;
                }
                _this.go();
            },5000) 
        },
        // 点击 ol li
        this.olgo = function(){
            var _this = this;
            clearInterval(_this.timer);
            _this.$ol.find("li").on("click",function(){
                var index = $(this).index();
                _this.evt.index = index;
                _this.go();
            })
        }
    }

    var par = $("#imgbox"),
        imgs = $(".banners"),
        ul = $("#uls"),
        ol = $("#imgboxbtn");
     // 实例 
    var imgbox = new ImgBox(par,imgs,ul,ol);

       // 初始化样式
       imgbox.init();
       // 自动播
       imgbox.autogo();

        // 窗口发生改变响应
    $(window).resize(function(){

        imgbox.init();

    })

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_index_banner");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gamecenter/index";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parent("li").index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    
});