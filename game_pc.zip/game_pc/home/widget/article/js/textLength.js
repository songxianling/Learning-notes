define('home.widget.article.js.textLength', function () {

	var list_p = ".js-b-article-list-p",
        recommend_p = ".js-article-recommend-p",
        gifts = ".js-article-gifts-p";


    /*list介绍*/
    if($(list_p).length>0){
        $(list_p).each(function(){
            textL($(this),80);
        })
        
    }
    /*推荐介绍*/
    if($(recommend_p).length>0){
        $(recommend_p).each(function(){
           textL($(this),25);  
        })
       
    }
    /*游戏礼包*/
    
    if($(gifts).length>0){
        $(gifts).each(function(){
           textL($(this),20);  
        })
       
    }

    /*多行溢出为省略号*/
    function textL(d,l){
        var cont = d.html(),
            leng = cont.length,
            html = '';
        if(leng){
            if(leng > l){
                html = cont.slice(0,l);
                d.html(html+"...");
            }
        } 

           
        
    }

    return textL;

});