define('home.widget.percenter.center.js.center',function(require,exports,module) {
	
	
    
});
