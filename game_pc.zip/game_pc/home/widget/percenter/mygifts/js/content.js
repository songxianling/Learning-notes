define('home.widget.percenter.mygifts.js.content',function(require,exports,module) {

	var uls = $(".js-p-user-center-mygifts-uls");
		for(var i=0;i<uls.length;i++){
			var input = $("#js-user-mygifts-input"+i),
				btn = $("#js-user-mygifts-fuzhi"+i),
				b = "js-user-mygifts-fuzhi"+i;
				// console.log(input);
			init(input,btn,b)
		}
	    

	function init(i,btn,b) {
	    
	    i.click(function(){
	        $(this).select();
	    });
	    btn.each(function(){
	        ZeroClipboard.setMoviePath($(this).attr("data-url"));
	        var clip = new ZeroClipboard.Client(); // 新建一个对象
	        clip.setHandCursor(true ); // 设置鼠标为手型
	        clip.setText(""); // 设置要复制的文本。
	        clip.setHandCursor(true);
	        clip.setCSSEffects(true);
	        clip.addEventListener('complete', function(client, text) {
	            alert("礼包兑换码复制成功！" );
	        } );
	        clip.addEventListener('mouseDown', function(client) {
	            clip.setText(i.val());
	        } );
	        clip.glue(b);
	        $(this).click(function(e){
	            e.preventDefault();
	            alert("啊哦，好像复制失败了……手动复制一下吧！");
	        });
	    });
	}

});
