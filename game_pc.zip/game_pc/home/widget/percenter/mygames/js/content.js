define('home.widget.percenter.mygames.js.content',function(require,exports,module) {

    var $extractNobankno = $('.js-extract-nobankno');
    $extractNobankno.on('click',function(){
        alert('请先绑定提现账户！');
    });

    var commonClass = require("common.static.js.common");

	// 提现账户管理弹框
    var $changePopBtn = $(".js-b-change-pop-btn"),
        $changePopBox = $("#js-b-change-pop-box");



    // 提现账户管理弹框弹出
    $changePopBtn.on('click',function(){
        
            commonClass.showTips({
                top : '50%',
                left : "50%",
                margin : "-199px 0 0 -291px",
                body : $changePopBox.html(), 
                status:-1,
                title:"提现账户管理",
                cancelBtn : false,
                onShow : function(pobj,cancel){
                    regevent(pobj,cancel);
                }
            })
        
    });
    function regevent(pobj,cancel){
        var $changePopBoxDialog = $('#js-b-change-pop-box-dialog',pobj);
        var $checkboxBox = $changePopBoxDialog.find('#js-checkbox-box');
        var $zfbTextBox = $changePopBoxDialog.find('#js-zfb-text-box');
        var $yhkTextBox = $changePopBoxDialog.find('#js-yhk-text-box');
        var $submitBtn = $changePopBoxDialog.find('#js-btns-box').find('#js-submit-btn');
        var $cancelBtn = $changePopBoxDialog.find('#js-btns-box').find('#js-cancel-btn');
        var $zfbErrorBox = $zfbTextBox.find('.error-box');
        var $yhkErrorBox = $yhkTextBox.find('.error-box');

        var $changeBanktype = $changePopBoxDialog.find('.js-b-change-banktype');
        var changeBanktype = parseInt($changeBanktype.val());

        var msg = {
        	type : changeBanktype==2?2:1,
            zfbCanSubmit : [
            [false,"真实姓名不能为空"],
            [false,"支付宝账号不能为空"]
            ],
            yhkCanSubmit : [
            [false,"真实姓名不能为空"],
            [false,"银行名称不能为空"],
            [false,"银行账号不能为空"],
            [false,"开户行所在地不能为空"]
            ],
            submitOk : true,
            err : "为保证您的资金提现无误，请填写真实有效的银行账户信息，如因账号信息有误造成损失，本平台不承担风险！",
            reg : /[\u4E00-\u9FFF]/
        };

        // 账户类型切换
    	$checkboxBox.on("click","a",function(){
			$(this).siblings().removeClass("ac");
			$(this).addClass("ac");
			if($(this).attr("id")=="js-checkbox-zfb"){
                msg.type = 1;
				$yhkTextBox.removeClass("ac");
				$zfbTextBox.addClass("ac");
			}else if($(this).attr("id")=="js-checkbox-yhk"){
                msg.type = 2;
				$zfbTextBox.removeClass("ac");
				$yhkTextBox.addClass("ac");
			}
    	});

    	// 失去焦点验证
    	$zfbTextBox.find('.js-true-name').on('blur',function(){
    		var _this = $(this);
    		var c = msg.zfbCanSubmit;
    		isOk(_this,$zfbErrorBox,0,c,1);
    	});
    	$zfbTextBox.find('.js-zfb-name').on('blur',function(){
    		var _this = $(this);
    		var c = msg.zfbCanSubmit;
    		isOk(_this,$zfbErrorBox,1,c,1);
    	});
    	$yhkTextBox.find('.js-true-name').on('blur',function(){
    		var _this = $(this);
    		var c = msg.yhkCanSubmit;
    		isOk(_this,$yhkErrorBox,0,c,2);
    	});
    	$yhkTextBox.find('.js-yhk-name').on('blur',function(){
    		var _this = $(this);
    		var c = msg.yhkCanSubmit;
    		isOk(_this,$yhkErrorBox,1,c,2);
    	});
    	$yhkTextBox.find('.js-yhk-code').on('blur',function(){
    		var _this = $(this);
    		var c = msg.yhkCanSubmit;
    		isOk(_this,$yhkErrorBox,2,c,2);
    	});
    	$yhkTextBox.find('.js-yhk-address').on('blur',function(){
    		var _this = $(this);
    		var c = msg.yhkCanSubmit;
    		isOk(_this,$yhkErrorBox,3,c,2);
    	});

    	function isOk(_this,m,n,c,t){
    		var v = _this.val();
    		var reg = msg.reg;

    		if(v == "" || v == null){
    			_this.css("border-color","#ff3300");
    			m.text(c[n][1]);
    			c[n][0] = false;
    		}else if(t==1 && n==1 && reg && reg.test(v)){
    			_this.css("border-color","#ff3300");
    			m.text('支付宝账号不能有汉字');
    			c[n][0] = false;
    		}else if(t==2 && n==2 && reg && reg.test(v)){
                _this.css("border-color","#ff3300");
                m.text('银行账号不能有汉字');
                c[n][0] = false;
            }else{
    			_this.css("border-color","#999");
    			m.text(msg.err);
    			c[n][0] = true;
    		}
    	}

    	// 表单提交
    	$submitBtn.on("click",function(){
            var reg = msg.reg;
    		if(msg.type == 1){
                if(!$zfbTextBox.find('.js-true-name').val()){
                    $(this).css("border-color","#ff3300");
                    $zfbErrorBox.text(msg.zfbCanSubmit[0][1]);
                    return false;
                }
                if(!$zfbTextBox.find('.js-zfb-name').val()){
                    $(this).css("border-color","#ff3300");
                    $zfbErrorBox.text(msg.zfbCanSubmit[1][1]);
                    return false;
                }
                if(reg && reg.test($zfbTextBox.find('.js-zfb-name').val())){
                    $(this).css("border-color","#ff3300");
                    $zfbErrorBox.text('支付宝账号不能有汉字');
                    return false;
                }
    			var c = msg.zfbCanSubmit;
    			var val = {
                    banktype : 1,
    				realname : $zfbTextBox.find('.js-true-name').val(),
    				bankno : $zfbTextBox.find('.js-zfb-name').val()
    			};
    			isSub($zfbErrorBox,c,val);
    		}else if(msg.type == 2){
                if(!$yhkTextBox.find('.js-true-name').val()){
                    $(this).css("border-color","#ff3300");
                    $yhkErrorBox.text(msg.yhkCanSubmit[0][1]);
                    return false;
                }
                if(!$yhkTextBox.find('.js-yhk-name').val()){
                    $(this).css("border-color","#ff3300");
                    $yhkErrorBox.text(msg.yhkCanSubmit[1][1]);
                    return false;
                }
                if(!$yhkTextBox.find('.js-yhk-code').val()){
                    $(this).css("border-color","#ff3300");
                    $yhkErrorBox.text(msg.yhkCanSubmit[2][1]);
                    return false;
                }
                if(reg && reg.test($yhkTextBox.find('.js-yhk-code').val())){
                    $(this).css("border-color","#ff3300");
                    $yhkErrorBox.text('银行账号不能有汉字');
                    return false;
                }
                if(!$yhkTextBox.find('.js-yhk-address').val()){
                    $(this).css("border-color","#ff3300");
                    $yhkErrorBox.text(msg.yhkCanSubmit[3][1]);
                    return false;
                }
    			var c = msg.yhkCanSubmit;
    			var val = {
                    banktype : 2,
    				realname : $yhkTextBox.find('.js-true-name').val(),
    				bankname : $yhkTextBox.find('.js-yhk-name').val(),
    				bankno : $yhkTextBox.find('.js-yhk-code').val(),
    				address : $yhkTextBox.find('.js-yhk-address').val()
    			};
    			isSub($yhkErrorBox,c,val);
    		}
    	});
        $cancelBtn.on("click",function(){
            cancel();
        });

    	function isSub(m,c,val){

    		if(/*canSubmit && */msg.submitOk){
    			msg.submitOk = false;
    			$.ajax({
    				url:'/usercenter/bank/savebank',
    				type:'post',
    				dataType:'json',
                    data:val,
                    success:function(data){
                        if(data.errcode == 0){
                          window.location.reload();
                        }else if(data.errcode == 100001){
                          window.location.reload();
                        }else{
                          m.text(data.msg);
                          msg.submitOk = true;
                        }
                    },
                    error:function(data){
                    	console.log('error!');
                    }
    			});
    		}
    	}

    }


    // 短信验证弹框
    var $smsCodeBtn = $(".js-b-sms-code-btn"),
        $smsCodeBox = $("#js-b-sms-code-box");

    // 短信验证弹框弹出
    $smsCodeBtn.on('click',function(){
        if(Number($(this).attr("data-pre")) == 0){
            commonClass.showTips({
                title:"退游验证",
                status:"4",
                body:"<p class='tishi-msg'><span></span>温馨提示：您好，该游戏您暂无充值，无法进行退游返现。</p>"
            })
        }else{
            var gameuserid = $(this).attr("data-gameuserid");
            commonClass.showTips({
                top : '50%',
                left : "50%",
                margin : "-199px 0 0 -291px",
                body : $smsCodeBox.html(), 
                status:-1,
                title:"退游验证",
                cancelBtn : false,
                gameuserid:gameuserid,
                onShow : function(pobj,cancel,gameuserid){
                    smsRegevent(pobj,cancel,gameuserid);
                }
            })
        }
    });

    function smsRegevent(pobj,cancel,gameuserid){
        var $smsCodeBoxDialog = $('#js-b-sms-code-box-dialog',pobj);
        var $smsTxt = $smsCodeBoxDialog.find('.js-sms-txt');
        var $getSms = $smsCodeBoxDialog.find('.js-get-sms');
        var $msgBox = $smsCodeBoxDialog.find('.js-msg-box');
        var $submitBtn = $smsCodeBoxDialog.find('.js-submit-btn');
        var $cancelBtn = $smsCodeBoxDialog.find('.js-cancel-btn');

        var msg = {
            canSubmit : false,
            submitOk : true,
            smsOk : true,
            err : "请输入短信验证码",
            countdown : 60,
            timer : null
        };

        // 失去焦点验证
        $smsTxt.on("blur",function(){
            if($(this).val()=="" || $(this).val()==null){
                msg.canSubmit = false;
            }else{
                msg.canSubmit = true;
            }
        });

        // 获取短信验证码
        $getSms.on('click',function(){
            if(msg.smsOk){
                msg.smsOk = false;
                $getSms.addClass("dis");
                $.ajax({
                    url:'/com/verify/sms-vcode-user',
                    type:'get',
                    dataType:'json',
                    data:{
                        position : 1
                    },
                    success:function(data){
                        if(data.errcode == 0){
                          settime($getSms);
                        }else{
                          msg.smsOk = true;
                          $getSms.removeClass("dis");
                          $msgBox.text(data.msg);
                        }
                    },
                    error:function(data){
                        console.log('error!');
                    }
                });
            }
        });
        // 短信验证码倒计时
        function settime(val){
            if(msg.countdown<=0){
                msg.smsOk = true;
                val.removeClass("dis");
                val.text('获取短信验证码');
                msg.countdown=60;
                clearTimeout(msg.timer);
            }else{
                msg.smsOk = false;
                val.addClass("dis");
                val.text('重新获取('+msg.countdown+')');
                msg.countdown--;
                msg.timer=setTimeout(function(){
                  settime(val)
                },1000);
            }
        }

        // 提交申请
        $submitBtn.on("click",function(){

            if(msg.canSubmit && msg.submitOk){
                msg.submitOk = false;
                $.ajax({
                    url:'/usercenter/mygame/quit',
                    type:'post',
                    dataType:'json',
                    data:{
                        gameuserid : gameuserid,
                        verifycode : $smsTxt.val()
                    },
                    success:function(data){
                        if(data.errcode == 0){
                          window.location.reload();
                        }else if(data.errcode == 100001){
                          window.location.reload();
                        }else{
                          $msgBox.text(data.msg);
                          msg.submitOk = true;
                        }
                    },
                    error:function(data){
                        console.log('error!');
                    }
                });
            }else if(!msg.canSubmit){
                $msgBox.text('验证码不能为空');
            }

        });

        $cancelBtn.on("click",function(){
            cancel();
        });

    }



    // 充值记录弹窗

    var pageNav = require("common.static.js.chongzhijilu"),
        commmsg = {
                isque : "亲，确认退游后，您的游戏角色将无法继续登录，该游戏下退游返现金额将退回到您的淘手游余额",
                already : "亲爱的用户，您已经退游了！",
                delurl : "/user/mygames/quit",
                ok : true
            };
    var $chongzhiBtn = $(".js-b-mygame-btn"),
        $closeBtn = $("#area-list-close-btn"),
        $doilg = $('#js-p-user-center-mygames-list-pop');

    /* 显示充值记录 */
    var tradeClass = {
        showjilu:function (par){
            var cpage = 1,pagesum = 1,str = "",gamename = par.attr("data-gamename"),gameuserid = par.attr("data-gameuserid");

            var $name = $("#js-p-user-center-mygames-gamesname"),
                $box = $("#js-p-user-center-mygames-list-pop");

            var getData = "";
            $.ajax({
				url:'/usercenter/mygame/get-recharge-list?gameuserid='+gameuserid,
				type:'get',
				dataType:'json',
                data:{},
                success:function(data){
                    if(data.errcode == 0){
                      getData = data.data.tradelogList;
                      showData(getData);
                    }else if(data.errcode == 100001){
                      // window.location.reload();
                    }else{
                      // window.location.reload();
                    }
                },
                error:function(data){
                	console.log('error!');
                }
            });

			function showData(getData){
				var data = getData;
                if(data.length == 0 ){
                    alert("您的充值记录为空！");
                }else{
      
                    pagesum = data.length%5==0?data.length/5:Math.ceil(data.length/5);

                    pageNav.data=data;

                    pageNav.fn = function(p,pn){
                        document.getElementById("pagesum").innerHTML ='总共'+ pn +'页';
                    };

                    pageNav.go(cpage,pagesum);
                    
                    $name.html(gamename+"-充值记录")
                    $box.show();
                }
			}

               
        }
    };

        // 关闭
        $closeBtn.on("click",function(){
            $doilg.hide();
        })

        // 充值记录点击事件
        $chongzhiBtn.on("click",function(){
            var _this = $(this);
            tradeClass.showjilu(_this);
        })
        //点击页码
        $('#pageNav').on('click','.pageNum',function () {
            pageNav.go(parseInt($(this).attr('pageno')),parseInt($(this).attr('pn')));
        });

});
