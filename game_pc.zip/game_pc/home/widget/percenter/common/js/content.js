define('home.widget.percenter.common.js.content',function(require,exports,module) {

});
