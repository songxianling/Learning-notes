define('home.widget.percenter.extract.js.content',function(require,exports,module) {
	var $accountBox = $("#js-account-box"),//切换提现类型
	    $skAccountInfo = $("#js-sk-account-info"),//收款账户信息
	    $extractNumTxt = $(".js-extract-num-txt"),//提现金额input
	    $smsCodeTxt = $(".js-sms-code-txt"),//短信验证input
	    $extractNumMsg = $(".js-extract-num-msg"),//提现金额msg
	    $smsCodeMsg = $(".js-sms-code-msg"),//短信验证msg
	    $getSmsCode = $(".js-get-sms-code"),//获取验证码btn
	    $submitBtn = $(".js-submit-btn"),//提交申请btn
	    $extractNumMin = $(".js-extract-num-min"),//最小提现金额
	    $extractNumMax = $(".js-extract-num-max"),//最大提现金
	    $msg = $(".js-extract-msg");

    var msg = {
    	type : 0,
        canSubmit : [false,false],
        submitOk : true,
        smsOk : true,
        err : $smsCodeMsg.text(),
        countdown : 60,
        timer : null,
        min : parseInt($extractNumMin.val()),
        max : parseInt($extractNumMax.val())
    };

    //点击切换提现类型
	$accountBox.on("click","a",function(){
		$(this).siblings().removeClass("ac");
		$(this).addClass("ac");
		if($(this).attr("id")=="js-tsy-account"){
			msg.type = 0;
			$skAccountInfo.hide();
			$extractNumTxt.val("").css("border-color","#999");
			$smsCodeTxt.val("").css("border-color","#999");
			$smsCodeMsg.text(msg.err);
			$msg.hide();
		}else if($(this).attr("id")=="js-sk-account"){
			msg.type = 1;
			$skAccountInfo.show();
			$extractNumTxt.val("").css("border-color","#999");
			$smsCodeTxt.val("").css("border-color","#999");
			$smsCodeMsg.text(msg.err);
			$msg.show();
		}
	});

	//失去焦点验证
	$extractNumTxt.on("blur",function(){
		var v = $(this).val();
		if(v=="" || v==null){
			msg.canSubmit[0] = false;
			$(this).css("border-color","#ff3300");
			$smsCodeMsg.text("提现金额不能为空");
		}else if(v == parseInt(v) && v >= msg.min && v <= msg.max){
			msg.canSubmit[0] = true;
			$(this).css("border-color","#999");
			$smsCodeMsg.text(msg.err);
		}else{
			msg.canSubmit[0] = false;
			$(this).css("border-color","#ff3300");
			$smsCodeMsg.text("提现金额输入不正确");
		}
	});
	$smsCodeTxt.on("blur",function(){
		if($(this).val()=="" || $(this).val()==null){
			msg.canSubmit[1] = false;
			$(this).css("border-color","#ff3300");
			$smsCodeMsg.text("短信验证码不能为空");
		}else{
			msg.canSubmit[1] = true;
			$(this).css("border-color","#999");
			$smsCodeMsg.text(msg.err);
		}
	});

	//获取短信验证码
	$getSmsCode.on("click",function(){
        if(msg.smsOk){
            msg.smsOk = false;
            $getSmsCode.addClass("dis");
            $.ajax({
                url:'/com/verify/sms-vcode-user',
                type:'get',
                dataType:'json',
                data:{
                    position : 2
                },
                success:function(data){
                    if(data.errcode == 0){
                      settime($getSmsCode);
                    }else{
                      msg.smsOk = true;
                      $getSmsCode.removeClass("dis");
                      $smsCodeMsg.text(data.msg);
                    }
                },
                error:function(data){
                    console.log('error!');
                }
            });
        }
	});
	// 短信验证码倒计时
    function settime(val){
        if(msg.countdown<=0){
            msg.smsOk = true;
            val.removeClass("dis");
            val.text('获取短信验证码');
            msg.countdown=60;
            clearTimeout(msg.timer);
        }else{
            msg.smsOk = false;
            val.addClass("dis");
            val.text('重新获取('+msg.countdown+')');
            msg.countdown--;
            msg.timer=setTimeout(function(){
              settime(val)
            },1000);
        }
    }
	//提交申请
	$submitBtn.on("click",function(){
		var canSubmit = true;
		var c = msg.canSubmit;
		for(var i=0;i<c.length;i++){
			if(c[i]==false){
				canSubmit = false;
				break;
			}
		}
		if(canSubmit && msg.submitOk){
			msg.submitOk = false;
			var banktype;
			if(msg.type==0){
				banktype=2;
			}else if(msg.type==1){
				banktype=1;
			}
			$.ajax({
				url:'/usercenter/extraction/save',
				type:'post',
				dataType:'json',
                data:{
                	banktype : banktype,
                	price : $extractNumTxt.val(),
                	verifycode : $smsCodeTxt.val()
                },
                success:function(data){
                    if(data.errcode == 0){
                      window.location.href="/usercenter/extraction/list";
                    }else if(data.errcode == 100001){
                      window.location.reload();
                    }else{
                      $smsCodeMsg.text(data.msg);
                      msg.submitOk = true;
                    }
                },
                error:function(data){
                	console.log('error!');
                }
			});
		}
	});

});
