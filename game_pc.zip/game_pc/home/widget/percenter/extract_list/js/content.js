define('home.widget.percenter.extract_list.js.content',function(require,exports,module) {

});
