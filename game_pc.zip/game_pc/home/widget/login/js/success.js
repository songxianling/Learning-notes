define('home.widget.login.js.success',function(require,exports,module) {
	var btn = $("#js-autogo");

	var num = 3;
	setInterval(function(){
		num--;
		if(num<=0){
			window.location.href = "/";
		}
		btn.html(""+num+"秒后自动跳转至游戏中心首页")
	},1000)
})