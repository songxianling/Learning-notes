define('home.widget.login.js.register',function(require,exports,module) {
	
	var reerurl = $('#js-reerurl').val();
	
	// 注册接口变量
	var rego = reerurl+'/api/user/register', //总接口
		reyzp = reerurl+'/api/sms/check-mobile', //验证码手机号
		resms = reerurl+'/api/sms/reg-code', //发送验证码（短信or语音）
		reyzsms = reerurl+'/api/sms/check-code', //验证验证码
		reimg = reerurl+'/api/user/captcha', //图片验证码
		reyzimg = reerurl+'/api/user/check-verify-code'; //验证码图片验证码
	
	
	
	// 第一步
	var $st1 = $(".js-status1"),
		$st2 = $(".js-status2"),
		$st3 = $(".js-status3"),
		$btn1 = $("#js-phone-btn"),
		$yan = $(".js-yan"),
		$phoneyan = $(".js-phoneyan"),
		$tongyi = $(".js-tongyi"),
		$loginbtnOne = $(".js-loginBtn-one"),
		$yuyinyan = $(".js-yuyin-msg"); 

	var commsg = {
		msg1:"手机号为空",
		msg2:"手机号格式不正确",
		msg3:"验证码为空",
		msg4:"手机验证码为空",
		msg5:"请您同意淘手游服务协议",
		msg6:"用户名为空",
		msg7:"密码为空",
		msg8:"密码长度小于6位",
		msg9:"验证码不正确",
		msg10:"手机号或图形验证码填写有误",
		msg11:"内容填写有误",
		msg12:"密码输入不一致",
		msg13:"您的请求过于频繁"
	},
	phone = $(".js-phonenum"),
	num = 60,
	ok = true,
	timer = '',
	yanok = false,
	phoneok = false;

	var	comFun = require("common.static.js.common");

	var commonAjax = function(u,d,callback){
		$.ajax({
			url:u,
			data : d,
			type:'post',
			xhrFields:{withCredentials:true},
			dataType :"json",
            success : function(data){
            	callback(data); 
            }
			
		});
	}

	// 载入加密文件
    if(!$.jCryption){
        require.loadJs('/static/common/static/js/jquery/jquery_jcryption_3_1_0.js');
    }

	// 图形验证码
	var $yanBtn = $(".js-yanzhengma");
	refreshVerifyImg($yanBtn);
	function refreshVerifyImg(obj){
		$.ajax({
			url:reimg,
			data : {refresh: 1, _: Math.random() * (1e5 + 1)},
			type:'get',
			xhrFields:{withCredentials:true},
			dataType :"json",
            success : function(data){
            	obj.prop("src", reerurl+data.url)
               
            }
			
		});
	}
	$yanBtn.on("click",function(){
		refreshVerifyImg($yanBtn);
	})

	// 失去焦点验证
	$st1.on("blur","input",function(){
		var _this = $(this);
		// 手机号
		if(_this.hasClass("js-phonenum")){
			if(_this.val() == "" || _this.val == null){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg1);
			}else if(!comFun.telValid($.trim(_this.val()))){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg2);
			}else{

				commonAjax(reyzp,{mobile:$.trim(_this.val())},phoneNum)

				function phoneNum(data){
					if(data.errcode == "0"){
						phoneok = true;
						$st1.find(".error-msg").hide();
					    $st1.find(".error-msg span").html("");
					}else{
						phoneok = false;
						$st1.find(".error-msg").show();
					    $st1.find(".error-msg span").html(data.msg);
					}   
				}
			}
		}
		// 图形验证码
		if(_this.hasClass("js-yan")){
			if(_this.val() == "" || _this.val == null){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg3);
			}else{

				commonAjax(reyzimg,{picVerifyCode:$.trim(_this.val())},imgyanFun)

				function imgyanFun(data){
					if(data.errcode == 0){	
		            		yanok = true;
		            		$st1.find(".error-msg").hide();
		            	  	$st1.find(".error-msg span").html("");
		            	}else{
		            		yanok = false;
			            	$st1.find(".error-msg").show();
			            	$st1.find(".error-msg span").html(data.msg);
		            	}
				}
			}
		}
		// 手机验证码
		if(_this.hasClass("js-phoneyan")){
			if(_this.val() == "" || _this.val == null){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg4);
			}else{

				commonAjax(reyzsms,{mobile:$.trim($(".js-phonenum").val()),smsVerifyCode:$.trim(_this.val())},phoneYannum)

				function phoneYannum(data){
					if(data.errcode == 0){
						$st1.find(".error-msg").hide();
					  	$st1.find(".error-msg span").html("");
					}else{
					  $st1.find(".error-msg").show();
					  $st1.find(".error-msg span").html(data.msg);
					}
				}
			}
		}
	})

	// 点击发送手机验证码
	$btn1.on("click",function(){
		var _this = $(this);
		if(yanok && phoneok){
			$st1.find(".error-msg").hide();
		    $st1.find(".error-msg span").html("");
			// 点击获取
			if(ok){
				ok = false;
				$st1.find(".error-msg").hide();
	            $st1.find(".error-msg span").html("");
				var phoneNum = $.trim($(".js-phonenum").val());
				var _data = {mobile:phoneNum,sendType:'sms'};

				commonAjax(
					resms,
					_data,
					function(data){
		            	if(data.errcode =="0"){
		            		_this.addClass("hui");
		            		num = 60;
		            		timer = setInterval(function(){
		            			num--;
		            			if(num <= 0){
		            				num = 60; 		            				
		            				clearInterval(timer);
		            				_this.removeClass("hui");
		            				_this.html("点击获取");
		            				ok = true;
		            				$yuyinyan.show();
		            			}else{
		            				_this.html(""+num+"s后重试");
		            			}
		            			
		            		},1000);
		            	}else{
		            		ok = true;
	            			$st1.find(".error-msg").show();
	            		    $st1.find(".error-msg span").html(data.msg);
		            	}
					}
				)
				
			}else{
				$st1.find(".error-msg").show();
			    $st1.find(".error-msg span").html(commsg.msg13);
			}
		}else{
			if(!yanok){

				commonAjax(reyzimg,{picVerifyCode:$.trim($('.js-yan').val())},function(data){

	            	if(data.errcode == 0){	
	            		yanok = true;
	            		$st1.find(".error-msg").hide();
	            	  	$st1.find(".error-msg span").html("");
	            	}else{
	            		yanok = false;
		            	$st1.find(".error-msg").show();
		            	$st1.find(".error-msg span").html(data.msg);
	            	}
				})

			}else if(!phoneok){
				commonAjax(reyzp,{mobile:$.trim($('.js-phonenum').val())},function(data){

	            	if(data.errcode == "0"){
	            		phoneok = true;
	            		$st1.find(".error-msg").hide();
	            	    $st1.find(".error-msg span").html("");
	            	}else{
	            		phoneok = false;
	            		$st1.find(".error-msg").show();
	            	    $st1.find(".error-msg span").html(data.msg);
	            	} 
				})

			}else{
				$st1.find(".error-msg").hide();
			    $st1.find(".error-msg span").html("");
			}
			
		}
		

	})
	// 点击发送语音验证码
	$yuyinyan.on("click",'span',function(){
		var _this = $(this);
		if(yanok && phoneok){
			$st1.find(".error-msg").hide();
		    $st1.find(".error-msg span").html("");
			if(ok){
				ok = false;
				var phoneNum = $.trim($(".js-phonenum").val());
				var _data = {mobile:phoneNum,sendType:'voice'};
				$st1.find(".error-msg").hide();
	            $st1.find(".error-msg span").html("");
    			commonAjax(resms,_data,function(data){
	            	if(data.errcode == "0"){
	            		num = 60;
	            		timer = setInterval(function(){
	            			num--;
	            			if(num <= 0){
	            				num = 0;
	            				clearInterval(timer);
	            				_this.html("点击获取");
	            				_this.removeClass("hui");
	            				ok = true;
	            			}else{
	            				_this.addClass("hui");
	            				_this.html(""+num+"s后重试");
	            			}
	            			
	            		},1000);
	            	}else{
	            		ok = true;
            			$st1.find(".error-msg").show();
            		    $st1.find(".error-msg span").html(data.msg);
	            	} 
    			})

			}else{
				$st1.find(".error-msg").show();
			    $st1.find(".error-msg span").html(commsg.msg13);
			}
		}
	})


	// 同意验证码
	var tongyi = true;
	$tongyi.on("click",function(){
		var _this=$(this);
		if(_this.hasClass("tongyi")){
			_this.removeClass("tongyi");
			tongyi = false;
		}else{
			_this.addClass("tongyi");
			tongyi = true;
		}
	})

	// 第二步


	var passok = false;
	$st1.on("blur","input",function(){
		var _this = $(this);
		if(_this.hasClass("js-userpd1")){
			if(_this.val() == "" || _this.val() == null){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg7);
			}else if(_this.val().length < 6){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg8);
			}else if(_this.val() != $(".js-userpd2").val()){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg12);
				passok = false;
			}else{
				
				passok = true;
				$st1.find(".error-msg").hide();
				$st1.find(".error-msg span").html("");
			}
		}else if(_this.hasClass("js-userpd2")){
			if(_this.val() != $(".js-userpd1").val()){
				$st1.find(".error-msg").show();
				$st1.find(".error-msg span").html(commsg.msg12);
				passok = false;
			}else{
				$st1.find(".error-msg").hide();
				$st1.find(".error-msg span").html("");
				passok = true;
			}
		}
	})
	//修改为了st1 之前是st2
	$st1.on("input",".js-userpd1",function(){
		var _this = $(this);
		strong($.trim(_this.val()));
	})

	// 确认    2 -> 1
	var sub = true;
	$st1.on("click",".loginBtn",function(){		
		var val = $(".js-phoneyan").val();
		if(!passok){
			$st1.find(".error-msg").show();
		    $st1.find(".error-msg span").html(commsg.msg12);
		    return;
		}
		if($.trim($(".js-userpd1").val()).length < 6 ){
			$st1.find(".error-msg").show();
		    $st1.find(".error-msg span").html(commsg.msg8);
		    return;
		}
		if(tongyi && yanok && phoneok && val!="" && val!=null){
			var data ={
				mobile:$.trim($(".js-phonenum").val()),
				smsVerifyCode:val
			};

			commonAjax(reyzsms,data,function(data){
            	if(data.errcode == "0"){

					var _data = {
							mobile:$.trim($(".js-phonenum").val()),
				            password:$.trim($st1.find(".js-userpd1").val()),
				            passwordAgain:$.trim($st1.find(".js-userpd2").val()),
				           	smsVerifyCode:$.trim($(".js-phoneyan").val()),
				           	source:4
			        	};

			        if(sub){

			        	sub = false;

			        	commonAjax(rego,_data,function(data){
    		            	if(data.errcode == "0"){
    		            		$st1.hide();
    		            		$st3.show();
    		            		var time = 3;
    		            		setInterval(function(){
    		            			time--;
    		            			if(time <= 0){
    		            				window.location.href="/";
    		            			}
    		            			$(".js-goback").html(""+time+"秒后自动跳至首页");
    		            		},1000)
    		            	}else{
    		            		sub = true;
    		            		$st1.find(".error-msg").show();
    							$st1.find(".error-msg span").html(data.msg);
    		            	}
			        	})
			        	
			        }
            	}else{
        			$st1.find(".error-msg").show();
        		    $st1.find(".error-msg span").html(data.msg);
            	} 
			})
			
		}else{
			$st1.find(".error-msg").show();
		    $st1.find(".error-msg span").html(commsg.msg11);
		}
		
	});
	//回车事件
	 $(document).keypress(function(e) {  
    // 回车键事件  
       if(e.which == 13) {
   			$('.loginBtn').click();  
       }  
   });
	


	// 密码强度
	function strong(v){
		var modes = 0;
		//正则表达式验证符合要求的
		var sValue = v;
		if (sValue.length < 6) {
		    modes = 0;
		}else{
		    if (/\d/.test(sValue)) modes++; //数字
		    if (/[a-z]/.test(sValue)) modes++; //小写
		    if (/[A-Z]/.test(sValue)) modes++; //大写
		    if (/\W/.test(sValue)) modes++; //特殊字符
		}
		// 12位以下的算3级别强度
		if (sValue.length < 12 && modes > 3) {
		    modes = 3;
		};

		if(modes <= 1){
			$(".js-strong").html("弱");
		}else if(modes == 2){
			$(".js-strong").html("中");
		}else if(modes == 3){
			$(".js-strong").html("高");
		}else if(modes == 4){
			$(".js-strong").html("强");
		}
	}

});
