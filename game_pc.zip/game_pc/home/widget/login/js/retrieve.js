define('home.widget.login.js.retrieve',function(require,exports,module) {

	var repwdurl = $('#js-repwdurl').val();

	var psdgo = repwdurl+'/api/user/updatepwd', //1
		psdyzp = repwdurl+'/api/user/is-show-username', //验证码手机号用户名
		psdfssms = repwdurl+'/api/sms/pwd-code', //发送验证码（短信or语音）
		psdyzsms = repwdurl+'/api/sms/check-code', //验证验证码
		psdimg = repwdurl+'/api/user/captcha', //图片验证码
		psdyzimg = repwdurl+'/api/user/check-verify-code'; //验证码图片验证码
		

	var $one = $(".js-one"),
		$yanbtn = $(".js-yan-btn"),
		$cuowu = $(".js-cuowu"),
		$phonenum = $("#js-phone-num"),
		$phoneYanbtn = $(".js-yanzheng-btn"),
		$psone = $(".js-pass-one"),
		$pstwo = $(".js-pass-two"),
		$yuyinbtn = $("#js-yuyin-btn"),
		$yiyinbox = $(".js-yuyin-box");

	var commsg = {
		msg1:"手机号为空",
		msg2:"验证码为空",
		msg3:"验证码有误",
		msg4:"手机验证码为空",
		msg5:"您输入的密码为空",
		msg6:"你设置的密码长度必须超过6个字符",
		msg7:"密码输入不一致",
		msg8:"您的请求过于频繁"
	}	
	var yanzheng = false;

	// 载入加密文件
    if(!$.jCryption){
        require.loadJs('/static/common/static/js/jquery/jquery_jcryption_3_1_0.js');
    }

	function comajax(u,data,callback) {
		$.ajax({
                url:u,
                data : data,
                type : 'post',
                dataType :"json",
                xhrFields:{withCredentials:true},
                success : function(data){
                    callback(data);
                }
            })
	}


	//验证码
	$yanbtn.on("click",function(){
		yanNum($yanbtn);
	})
	yanNum($yanbtn);
	function yanNum (obj){
		$.ajax({
			url:psdimg,
			data : {refresh: 1, _: Math.random() * (1e5 + 1)},
			type:'get',
			xhrFields:{withCredentials:true},
			dataType :"json",
            success : function(data){
            	obj.prop("src", repwdurl+data.url)
               
            }	
		});
	}
	
	var userisshow = false;
	
	//失去焦点
	$one.on("blur","input",function(){
		var _this = $(this);
		if(_this.hasClass("js-user-name")){
			if(_this.val() == "" || _this.val() == null){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html(commsg.msg1);
			}else{

				// 验证手机号是否一号对多号
				comajax(psdyzp,{mobile:$('.js-user-name').val()},function(data){

	            	if(data.errcode == 0){
	            		if(data.data.isShow){
	            			$('#js-usershow').show();	
		            		userisshow = true;
	            		}else{
	            			$('.js-userbd').hide();
		            		userisshow = false;
	            		}
		            	$one.find(".error-msg").hide();
		            	$one.find(".error-msg span").html("");
	            	}else{
		            	$one.find(".error-msg").show();
		            	$one.find(".error-msg span").html(data.msg);
	            	}
				})

				/*$.ajax({
				    url : psdyzp,
				    data : {mobile:$('.js-user-name').val()},
				    type : 'post',
				    xhrFields:{withCredentials:true},
				    dataType : 'json',
				    success:function( data ) {
		            	if(data.errcode == 0){
		            		if(data.data.isShow){
		            			$('#js-usershow').show();	
			            		userisshow = true;
		            		}else{
		            			$('.js-userbd').hide();
			            		userisshow = false;
		            		}
			            	$one.find(".error-msg").hide();
			            	$one.find(".error-msg span").html("");
		            	}else{
			            	$one.find(".error-msg").show();
			            	$one.find(".error-msg span").html(data.msg);
		            	}
				    }
				});*/
			}
		}
		if(_this.hasClass("js-userbd")){
			if(_this.val() == "" || _this.val() == null){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html('用户名不能为空');
			}else{
				$one.find(".error-msg").hide();
				$one.find(".error-msg span").html("");
			}
		}
		if(_this.hasClass("js-user-yan")){
			if(_this.val() == "" || _this.val() == null){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html(commsg.msg2);
			}else{
				$one.find(".error-msg").hide();
				$one.find(".error-msg span").html("");
				var val = $.trim(_this.val());

				comajax(psdyzimg,{picVerifyCode:val},function(data){

	            	if(data.errcode == 0){
						yanzheng = true;
						$one.find(".error-msg").hide();	
					}else{
						$one.find(".error-msg span").html(data.msg);
						$one.find(".error-msg").show();
						yanzheng = false;
					}
				})

				/*$.ajax({
				    url : psdyzimg,
				    data : {picVerifyCode:val},
				    type : 'post',
				    xhrFields:{withCredentials:true},
				    dataType : 'json',
				    success:function( data ) {
				        if(data.errcode == 0){
							yanzheng = true;
							$one.find(".error-msg").hide();	
						}else{
							$one.find(".error-msg span").html(data.msg);
							$one.find(".error-msg").show();
							yanzheng = false;
						}
				    }
				})*/
			}			
		}	
	})
	
	// 点击获取手机验证码
	var ok = true,	
		num = 60,
		passlike = false,
		timer = "";
	$phoneYanbtn.on("click",function(){
		var _this = $(this);
		if(ok){
			num = 60;
			ok = false;
			$one.find(".error-msg").hide();
			$one.find(".error-msg span").html("");
			var _data = {
				mobile:$.trim($(".js-user-name").val()),
				sendType:'sms'
				};

			comajax(psdfssms,_data,function(data){

            	if(data.errcode == "0"){
		        	_this.addClass("hui");
		        	timer = setInterval(function(){
		        		num--;
		        		if(num <= 0){
		        			num = 0;
		        			clearInterval(timer);
		        			_this.removeClass("hui");
		        			_this.html("点击获取");
		        			ok = true;
		        			$yiyinbox.show();
		        		}else{
		        			_this.html(""+num+"s后重试");
		        		}
		        		
		        	},1000);
		        }else{
		        	ok = true;
		        	$one.find(".error-msg").show();
		        	$one.find(".error-msg span").html(data.msg);
		        }
			})	

		    /*$.ajax({
			    url : psdfssms,
			    data:_data,
			    xhrFields:{withCredentials:true},
			    type : 'post',
			    dataType : 'json',
			    success:function( data ) {
			        if(data.errcode == "0"){
			        	_this.addClass("hui");
			        	timer = setInterval(function(){
			        		num--;
			        		if(num <= 0){
			        			num = 0;
			        			clearInterval(timer);
			        			_this.removeClass("hui");
			        			_this.html("点击获取");
			        			ok = true;
			        			$yiyinbox.show();
			        		}else{
			        			_this.html(""+num+"s后重试");
			        		}
			        		
			        	},1000);
			        }else{
			        	ok = true;
			        	$one.find(".error-msg").show();
			        	$one.find(".error-msg span").html(data.msg);
			        }
			      }
			})*/
		}else{
			$one.find(".error-msg").show();
			$one.find(".error-msg span").html(commsg.msg8);
		}
	})
	// 语音验证码
	$yuyinbtn.on("click",function(){
		var _this = $(this);
		if(ok){
			ok = false;
			num = 60;
			var _data = {
				mobile:$.trim($(".js-user-name").val()),
				sendType:'voice'
			};

			comajax(psdfssms,_data,function(data){

            	if(data.errcode == "0"){
		        	_this.addClass("hui");
		        	timer = setInterval(function(){
		        		num--;
		        		if(num <= 0){
		        			num = 0;
		        			clearInterval(timer);
		        			_this.removeClass("hui");
		        			_this.html("点击获取");
		        			ok = true;
		        		}else{
		        			_this.html(""+num+"s后重试");
		        		}
		        		
		        	},1000);
		        }else{
		        	ok = true;
		        	$one.find(".error-msg").show();
		        	$one.find(".error-msg span").html(data.msg);
		        }
			})	

			/*$.ajax({
			    url : psdfssms,
			    data:_data,
			    xhrFields:{withCredentials:true},
			    type : 'post',
			    dataType : 'json',
			    success:function( data ) {
			        if(data.errcode == "0"){
			        	_this.addClass("hui");
			        	timer = setInterval(function(){
			        		num--;
			        		if(num <= 0){
			        			num = 0;
			        			clearInterval(timer);
			        			_this.removeClass("hui");
			        			_this.html("点击获取");
			        			ok = true;
			        		}else{
			        			_this.html(""+num+"s后重试");
			        		}
			        		
			        	},1000);
			        }else{
			        	ok = true;
			        	$one.find(".error-msg").show();
			        	$one.find(".error-msg span").html(data.msg);
			        }
			      }
			})*/
		}
	})

	// 失去焦点
	$one.on("blur","input",function(){
		var _this = $(this);
		if(_this.hasClass("js-yanma")){
			if(_this.val() == "" || _this.val == null){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html(commsg.msg4);
			}else{

				comajax(psdyzsms,{
				    	mobile:$.trim($(".js-user-name").val()),
						smsVerifyCode:$.trim($(".js-yanma").val())
				    },function(data){

	            	if(data.errcode == "0"){
			        	$one.find(".error-msg").hide();
			        	$one.find(".error-msg span").html("");
			        }else{				        	
			        	$one.find(".error-msg").show();
			        	$one.find(".error-msg span").html(data.msg);
			        }
				})

				/*$.ajax({
				    url : psdyzsms,
				    data:{
				    	mobile:$.trim($(".js-user-name").val()),
						smsVerifyCode:$.trim($(".js-yanma").val())
				    },
				    type : 'post',
				    xhrFields:{withCredentials:true},
				    dataType : 'json',
				    success:function(data) {
				        if(data.errcode == "0"){
				        	$one.find(".error-msg").hide();
				        	$one.find(".error-msg span").html("");
				        }else{				        	
				        	$one.find(".error-msg").show();
				        	$one.find(".error-msg span").html(data.msg);
				        }
				      }
				})*/
			}
		}else if(_this.hasClass("js-pass-one")){
			if(_this.val() == "" || _this.val == null){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html(commsg.msg5);
			}else if(_this.val().length < 6){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html(commsg.msg6);
			}else{
				if(_this.val() == $pstwo.val()){
					passlike = true;
					$one.find(".error-msg").hide();
					$one.find(".error-msg span").html("");
				}else{
					passlike = false;
					$one.find(".error-msg").show();
					$one.find(".error-msg span").html(commsg.msg7);
				}
			}
		}else if(_this.hasClass("js-pass-two")){

			if(_this.val() == "" || _this.val == null){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html(commsg.msg5);
			}else if(_this.val().length < 6){
				$one.find(".error-msg").show();
				$one.find(".error-msg span").html(commsg.msg6);
			}else{
				if(_this.val() == $psone.val()){
					passlike = true;
					$one.find(".error-msg").hide();
					$one.find(".error-msg span").html("");
				}else{
					passlike = false;
					$one.find(".error-msg").show();
					$one.find(".error-msg span").html(commsg.msg7);
				}
			}
		}
	})

	// 下一步
	$one.on("click",".loginBtn",function(){
		var userN = $.trim($(".js-user-name").val()),
			yanma = $.trim($(".js-yanma").val()),
			passw = $.trim($psone.val()),
			usename = $.trim($(".js-user-name").val());
		if(userN == "" || userN == null){
			$one.find(".error-msg").show();
		    $one.find(".error-msg span").html(commsg.msg1);
			return false;
		}
		if(!yanzheng){
			$one.find(".error-msg").show();
		    $one.find(".error-msg span").html(commsg.msg3);
			return false;
		}
		if(!yanma){
			$one.find(".error-msg").show();
			$one.find(".error-msg span").html(commsg.msg2);
			return false;
		}
		if(!passw){
			$one.find(".error-msg").show();
			$one.find(".error-msg span").html(commsg.msg5);
			return false;
		}else if(passw.length < 6){
			$one.find(".error-msg").show();
			$one.find(".error-msg span").html(commsg.msg6);
			return false;
		}
		if(!passlike){
			$one.find(".error-msg").show();
			$one.find(".error-msg span").html(commsg.msg7);
			return false;
		}

		comajax(psdyzsms,{
		    	mobile:userN,
				smsVerifyCode:$.trim($(".js-yanma").val())		    	
		    },function(data){

        	if(data.errcode == "0"){
	        	var _data = {
				    	mobile:$.trim($(".js-user-name").val()),
						password:$('.js-pass-one').val(),
						passwordAgain:$('.js-pass-two').val(),
						smsVerifyCode:yanma
						};
				if(userisshow){
					_data.userName = $('.js-userbd').val();
				}

				comajax(psdgo,_data,function(data){

			    	if(data.errcode == "0"){
			    		$one.hide();
			    		$(".js-three").show();
			    		var timenum = 3;
			    		setInterval(function(){
			    			timenum--;
			    			if(timenum<=0){
			    				window.location.href = "/";
			    			}
			    			$(".js-timer").html(""+timenum+"秒后自动跳至首页");
			    		},1000)
			    	}else{
			    		$one.find(".error-msg").show();
			    		$one.find(".error-msg span").html(data.msg);
			    	}
				})

		      	}else{
			      	$one.find(".error-msg").show();
			        $one.find(".error-msg span").html(data.msg);
		      	}
		})

		});


	//回车事件
	 $(document).keypress(function(e) {  
    // 回车键事件  
       if(e.which == 13) {
   			$('.loginBtn').click();  
       }  
   });

	// 密码强度
	$psone.on("input",function(){
		var val = $(this).val();
		strong(val);
	})
	// 密码强度
	function strong(v){
		var modes = 0;
		//正则表达式验证符合要求的
		var sValue = v;
		if (sValue.length < 6) {
		    modes = 0;
		}else{
		    if (/\d/.test(sValue)) modes++; //数字
		    if (/[a-z]/.test(sValue)) modes++; //小写
		    if (/[A-Z]/.test(sValue)) modes++; //大写
		    if (/\W/.test(sValue)) modes++; //特殊字符
		}
		// 12位以下的算3级别强度
		if (sValue.length < 12 && modes > 3) {
		    modes = 3;
		};

		if(modes <= 1){
			$(".js-qiangdu").html("弱");
		}else if(modes == 2){
			$(".js-qiangdu").html("中");
		}else if(modes == 3){
			$(".js-qiangdu").html("高");
		}else if(modes == 4){
			$(".js-qiangdu").html("强");
		}
	}

});
