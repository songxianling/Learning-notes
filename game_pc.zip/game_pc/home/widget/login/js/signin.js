define('home.widget.login.js.signin',function(require,exports,module) {

	var $tapbox = $(".js-tapbox"),
		$userBox = $("#js-userlogin-box"),
		$numBox = $("#js-numlogin-box"),
		$loginBtn = $("#js-loginBtn"),
		$username = $(".js-username"),
		$userpassword = $(".js-userpassword"),
		$numname = $(".js-numname"),
		$useryan = $(".js-useryan"),
		$useryanbtn = $(".js-useryan-btn"),
		$useryancot = $(".js-user-yantext");

	
	var signinurl = $('#js-signinurl').val();
	
	/*登录接口变量*/
	var lgimg = signinurl+'/api/user/captcha',
		lgyzuser = signinurl+'/api/user/check-mobile',
		lgsms = signinurl+'/api/user/user-send-code', //(语音和短信,sendType传sms 或 voice)
		showyzm = signinurl+'/api/user/judge-view-code', //是否显示验证码
		lggo = signinurl+'/api/user/login';  // gogogo
	
	/* hotfix_1024 */
	var phoneYan = false;

	var index = 0,
		yanshow = false,
		commsg = {
			msg1:"用户名为空",
			msg2:"密码为空",
			msg3:"手机号为空",
			msg4:"手机号格式不正确",
			msg5:"密码为空",
			msg6:"验证码为空",
			msg7:"请勿频繁操作",
			msg8:"手机验证码为空"
		};

	var	comFun = require("common.static.js.common");

	function comajax(u,data,callback) {
		$.ajax({
                url:u,
                data : data,
                type : 'post',
                dataType :"json",
                xhrFields:{withCredentials:true},
                success : function(data){
                    callback(data);
                }
            })
	}

	// 载入加密文件
    if(!$.jCryption){
        require.loadJs('/static/common/static/js/jquery/jquery_jcryption_3_1_0.js');
    }

    // 验证码
    yanNum();

    $useryanbtn.on("click",function(){
    	yanNum();
    })


    $userBox.find(".js-username").focus();

    function yanNum (){

    	comajax(lgimg,{refresh: 1, _: Math.random() * (1e5 + 1)},function(data){
    		$useryanbtn.prop("src", signinurl+data.url)
    	})
    }

    // 刷新页面是否显示验证码
    isShowyan();
    function isShowyan(){

    	$.ajax({
    	    url : showyzm,
    	    type : 'get',
    	    cache : false,
    	    xhrFields:{withCredentials:true},
    	    dataType : 'json',
    	    success:function( res ) {
    	        if (res.errcode == 0) {
    	            if (res.data.errorNum > 2) {
    	            	yanshow = true;
    	                $useryan.show();
    	            };
    	        }
    	      }
    	    })
    }


	// 用户名登录
	$userBox.on("blur","input",function(){
		var _this = $(this),
			_val = $.trim(_this.val());
		if(_this.hasClass("js-username")){
			if(_this.val() == "" || _this.val() == null){

			}else{
				$userBox.find(".error-msg").hide();
				$userBox.find(".error-msg span").html("");

				comajax(lgyzuser,{
		            	userName:_val
	                },function(data){
	                	if(data.errcode == "0"){
	                		$userBox.find(".error-msg").hide();
							$userBox.find(".error-msg span").html("");
	                		if(data.data.ischeck == "1"){
								$userBox.find(".error-msg").show();
								$userBox.find(".error-msg span").html("亲,您不是在常用的地方登录哦,请确保帐号安全");
	                			phoneYan = true;
	                			$userBox.find(".js-phoneyz").show();
	                			$userBox.find(".js-phoneyz-box").show();
	                			$userBox.find(".js-phoneyz-box a").html(data.data.mobile);
	                			$userBox.find(".js-mima").hide();
	                		}else{
	                			$userBox.find(".js-phoneyz").hide();
	                			$userBox.find(".js-phoneyz-box").hide();
	                			$userBox.find(".js-phoneyz-box a").html("");
	                			$userBox.find(".js-mima").show();
	                			phoneYan = false;
	                		}
	                	}else{
	                		$userBox.find(".error-msg").show();
							$userBox.find(".error-msg span").html(data.msg);
	                	}
				})
				
			}
		}else if(_this.hasClass("js-userpassword")){
			if(_this.val() == "" || _this.val() == null){
				$userBox.find(".error-msg").show();
				$userBox.find(".error-msg span").html(commsg.msg2);
			}else{
				$userBox.find(".error-msg").hide();
				$userBox.find(".error-msg span").html("");
			}
		}else{
			if(_this.val() == "" || _this.val() == null){
				$userBox.find(".error-msg").show();
				$userBox.find(".error-msg span").html(commsg.msg6);
			}else{
				$userBox.find(".error-msg").hide();
				$userBox.find(".error-msg span").html("");
			}
		}
	})

	var huoquyan = true,
		usertimer ,
		num = 60;
	$userBox.on("click",".js-phoneyanBtn",function(){
		if(huoquyan){
			huoquyan = false;
			var _this = $(this),
				_val = $.trim($userBox.find(".js-username").val());
			num = 60;

			comajax(lgsms,{
            	userName:_val
            },function(data){
            	if(data.errcode == "0"){
            		$userBox.find(".error-msg").hide();
					$userBox.find(".error-msg span").html("");
		        	usertimer = setInterval(function(){
		        		num--;
		        		if(num <= 0){
		        			num = 0;
		        			clearInterval(usertimer);
		        			_this.html("点击获取");
		        			huoquyan = true;
		        		}else{
		        			_this.html(""+num+"s后重试");
		        		}
		        		
		        	},1000);
            	}else{
            		huoquyan = true;
            		$userBox.find(".error-msg").show();
					$userBox.find(".error-msg span").html(data.msg);
            	}
            })

		}else{
			$userBox.find(".error-msg").show();
			$userBox.find(".error-msg span").html(commsg.msg7);
		}
	})

	function timereset(data){
        var theTime = parseInt(data);//秒
        var theTime1 = 0;//分
        var theTime2 = 0;//时
        if(theTime>60){
            theTime1 = parseInt(theTime/60);
            theTime = parseInt(theTime%60);
            if(theTime1>60){
                theTime2 = parseInt(theTime1/60);
                theTime1 = parseInt(theTime1%60);
            }
        }
        var result = ""+parseInt(theTime)+"秒";
        if(theTime1>0){
            result=""+parseInt(theTime1)+"分"+result;
        }
        if(theTime2>0){
            result=""+parseInt(theTime2)+"时"+result;
        }
        return result;
    };	
	
	var smstime = null;

	// 如果有returnurl 获取 跳转

	var callbackUrl = comFun.getRequest().returnurl,
		reUrl = "";

	if(callbackUrl){
		reUrl = callbackUrl;
	}

	//点击登录
	var IPtime = null;
	$loginBtn.on("click",function(){
			//用户名登录
			if($username.val() == "" || $username.val() == null){
				$userBox.find(".error-msg").show();
				$userBox.find(".error-msg span").html(commsg.msg1);
				return false;	
			}

			if(!phoneYan){
				if($userpassword.val() == "" || $userpassword.val() == null){
					$userBox.find(".error-msg").show();
					$userBox.find(".error-msg span").html(commsg.msg2);
					return false;	
				}
			}
			if(yanshow && $useryancot.val() == "" || $useryancot.val() == null){
				$userBox.find(".error-msg").show();
				$userBox.find(".error-msg span").html(commsg.msg6);
				return false;	
			}
			/*hotfix_1024*/
			if(phoneYan){
				if($userBox.find(".js-phonenum-yantext").val() == "" || $userBox.find(".js-phonenum-yantext").val() == null){
					$userBox.find(".error-msg").show();
					$userBox.find(".error-msg span").html(commsg.msg8);
					return false;
				}
			}


			var _data = {};
				_data.userName = $.trim($username.val());			
			//传密码还是手机验证码

			if(phoneYan){
				_data.smsVerifyCode = $.trim($(".js-phonenum-yantext").val());
			}else{
				_data.password = $.trim($userpassword.val());
			}

			// 是否需要传验证码
			if(yanshow){
				_data.picVerifyCode = $.trim($useryancot.val());
			}

			comajax(lggo,_data,function(data){
            	if(data.errcode == 101092){
					clearInterval(IPtime);
					var time = data.data.time;
					$userBox.find(".error-msg span").html(data.msg+timereset(time)+'后登录');
					$userBox.find(".error-msg").show();
					IPtime = setInterval(function () {
						if(time <= 0){
							clearInterval(IPtime);
							$userBox.find(".error-msg").hide();
						}else{
							time --;
							$userBox.find(".error-msg span").html(data.msg+timereset(time)+'后登录');
						}	
					},1000);
				}else if(data.errcode){
					//有错误的时候
					$userBox.find(".error-msg span").html(data.msg);
					$userBox.find(".error-msg").show();
					
					if(data.data.errorNum > 2){
						$useryan.show();
						yanshow = true;
						yanNum ();
					}
					
				}else{
					//没有错误跳转

					window.location.href = reUrl ? reUrl : '/';
				}
            })
            
	});
	
	//回车事件
	 $(document).keypress(function(e) {  
    // 回车键事件  
       if(e.which == 13) {
   			$loginBtn.click();  
       }  
   });
	
	
	//qq登录
	var configString = {
	    host : "http://" + window.location.host
	};
	var openWidth = 800; //弹出窗口的宽度;
	var openHeight = 600; //弹出窗口的高度;
	var openTop = (window.screen.availHeight - 30 - openHeight) / 2; //获得窗口的垂直位置;
	var openLeft = (window.screen.availWidth - 10 - openWidth) / 2; //获得窗口的水平位置;

	$("#js-qq-loginbtn").on("click",function(){
		// qq
		window.location.href = configString.host + "/siteauth/auth/qq-login";		
	})
	//神策统计
	var comAjax = require("common.static.js.common");
	$loginBtn.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   
   $('#js-qq-loginbtn').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = signinurl+"/api/qq/login?type=3";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_qq_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   $('#js-wx-loginbtn').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = signinurl+"/api/wechat/login?redirect_type=3";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_wechat_btn";

        comAjax.commonAjax(postUrl,data); 
   });
    $('#sc-newre').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "/siteauth/auth/register";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_register_btn";

        comAjax.commonAjax(postUrl,data); 
   });
    $('#sc-rvpwd').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "/siteauth/auth/retrieve";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_retrieve_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   $('#sc-phoyan').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_smscode_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   $('#sc-ad').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";;
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_ad";

        comAjax.commonAjax(postUrl,data); 
   });
   

});
