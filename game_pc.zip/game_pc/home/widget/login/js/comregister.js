define('home.widget.login.js.comregister',function(require,exports,module) {
	
	// qqre 接口变量
	
	var disantype = $('#js-type').val();
	var qqurl = $('#js-qqurl').val();
	
	
	var comgo = qqurl+'/api/qq/register',
		qqsms = qqurl+'/api/sms/reg-code',
		comimg = qqurl+'/api/user/captcha', //图片验证码
		comyzimg = qqurl+'/api/user/check-verify-code'; //验证码图片验证码
		qqyzsms = qqurl+'/api/sms/check-code'; //验证验证码
	
	if(disantype == 1){
		comgo = qqurl+'/api/qq/register';
	}else if(disantype == 2){
		//微信注册提交url
		comgo = qqurl+'/api/wechat/register';
	}

	var $box = $(".js-one"),
		$yanzhengBtn = $(".js-yan-btn"),
		$yuyinbox = $(".js-yuyin-box"),
		$yuyinbtn = $("#js-yuyin-btn");
		$two = $(".js-two");

	var commsg = {
		msg1:"手机号为空！",
		msg2:"手机号格式有误",
		msg3:"验证码为空",
		msg4:"新密码不能为空",
		msg5:"密码长度不能低于6位",
		msg6:"手机号有误",
		msg7:"您的请求过于频繁",
		msg8:"请输入相同密码",
		msg9:'手机验证码为空'
	};

	var	comFun = require("common.static.js.common");

	// 载入加密文件
    if(!$.jCryption){
        require.loadJs('/static/common/static/js/jquery/jquery_jcryption_3_1_0.js');
    }
    
    //sele切换
    var $seleli = $('.seleul li'),
    	$selecon = $('.selecontent'),
    	newuser = true;
    $seleli.on('click',function () {
    	$(this).addClass('sele').siblings().removeClass('sele');
    	$selecon.eq($(this).index()).show().siblings().hide();
    	$(this).index() == 0?(newuser=true,$('.qqregister-xieyi').show()):(newuser=false,$('.qqregister-xieyi').hide());
    	
    });
    
    
    
    // 图形验证码
	var $yanTu = $(".js-geti");
	refreshVerifyImg($yanTu);
	function refreshVerifyImg(obj){
		$.ajax({
			url:comimg,
			data : {refresh: 1, _: Math.random() * (1e5 + 1)},
			type:'get',
			xhrFields:{withCredentials:true},
			dataType :"json",
            success : function(data){
            	obj.prop("src", qqurl+data.url)
               
            }
			
		});
	}
	$yanTu.on("click",function(){
		refreshVerifyImg($yanTu);
	})
    

	var phoneok = false,	
		ok = true,
		timer = "",
		num = 60,
		smsava = false,
		newimgava = false,
		oldimgava = false;

	function comajax(u,data,callback) {
		$.ajax({
                url:u,
                data : data,
                type : 'post',
                dataType :"json",
                xhrFields:{withCredentials:true},
                success : function(data){
                    callback(data);
                }
            })
	}


	// 失焦判断
	

	$box.on("blur","input",function(){
		var _this = $(this);
		if(_this.hasClass("js-phone-num")){
			if(_this.val() == "" || _this.val() == null){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg1);
				phoneok = false;
			}else if(!comFun.telValid($.trim(_this.val()))){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg2);
				phoneok = false;
			}else{
				phoneok = true;
				$box.find(".error-msg").hide();
				$box.find(".error-msg span").html("");
			}
		}else if(_this.hasClass("js-tuyan")){
			if(_this.val() == "" || _this.val() == null){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg3);
			}else{
				//图片验证码不为空的时候的操作
				var imgdata = {picVerifyCode:$.trim(_this.val())};
				comajax(comyzimg,imgdata,function (data) {
					if(data.errcode =="0"){
	            		$box.find(".error-msg").hide();
	            		newimgava = true;
	            	}else{
	            		newimgava = false;
            			$box.find(".error-msg").show();
            		    $box.find(".error-msg span").html(data.msg);
	            	}
				});								
			}
		}else if(_this.hasClass("js-yan")){
			if(_this.val() == "" || _this.val() == null){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg9);
			}else{
				//手机验证码不为空的操作
				
				var phodata = {
		            	mobile:$.trim($(".js-phone-num").val()),
						smsVerifyCode:$.trim($(".js-yan").val())
		           };
		        comajax(qqyzsms,phodata,function (data) {
		        	if(data.errcode =="0"){
	            		$box.find(".error-msg").hide();
	            		smsava = true;
	            	}else{
	            		smsava = false;
            			$box.find(".error-msg").show();
            		    $box.find(".error-msg span").html(data.msg);
	            	}
		        }); 				
			}
		}else if(_this.hasClass("js-pass")){
			if(_this.val() == "" || _this.val() == null){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg4);
			}else if(_this.val().length < 6){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg5);
			}else{
				$box.find(".error-msg").hide();
				$box.find(".error-msg span").html("");
			}
		}else if(_this.hasClass("js-phone-num2")){
			if(_this.val() == "" || _this.val() == null){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg1);
				phoneok = false;
			}else{
				//old 帐号手机号不为空的操作
				
				
				phoneok = true;
				$box.find(".error-msg").hide();
				$box.find(".error-msg span").html("");
			}
		}else if(_this.hasClass("js-pass2")){
			if(_this.val() == "" || _this.val() == null){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg4);
			}else if(_this.val().length < 6){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg5);
			}else{
				$box.find(".error-msg").hide();
				$box.find(".error-msg span").html("");
			}
		}else if(_this.hasClass("js-tuyan2")){
			if(_this.val() == "" || _this.val() == null){
				$box.find(".error-msg").show();
				$box.find(".error-msg span").html(commsg.msg3);
			}else{
				//old 图片验证码不为空的操作
				var oldimgdata = {picVerifyCode:$.trim(_this.val())};
				comajax(comyzimg,oldimgdata,function (data) {
					if(data.errcode =="0"){
	            		$box.find(".error-msg").hide();
	            		oldimgava = true;
	            	}else{
	            		oldimgava = false;
            			$box.find(".error-msg").show();
            		    $box.find(".error-msg span").html(data.msg);
	            	}
				});	
				$box.find(".error-msg").hide();
				$box.find(".error-msg span").html("");
			}
		}
		
		
		
		
		
	})

	// 点击获取验证码
	$yanzhengBtn.on("click",function(){
			var _this = $(this);
			if(phoneok){
				$box.find(".error-msg").hide();
			    $box.find(".error-msg span").html("");
				// 点击获取
				if(ok){
					ok = false;
					$box.find(".error-msg").hide();
				    $box.find(".error-msg span").html("");
					var phoneNum = $.trim($(".js-phone-num").val());
					var _data = {mobile:phoneNum,sendType:'sms'};
					$.ajax({
			            url:qqsms,
			            data:_data,
			            type:'post',
			            dataType:'json',
			            success : function(data){
			            	if(data.errcode =="0"){
			            		num = 60;
			            		_this.addClass("hui");
			            		timer = setInterval(function(){
			            			num--;
			            			if(num <= 0){
			            				num = 0;
			            				clearInterval(timer);
			            				_this.removeClass("hui");
			            				_this.html("点击获取");
			            				ok = true;
			            				$yuyinbox.show();
			            			}else{
			            				_this.html(""+num+"s后重试");
			            			}
			            			
			            		},1000);
			            	}else{
			            		ok = true;
		            			$box.find(".error-msg").show();
		            		    $box.find(".error-msg span").html(data.msg);
			            	}
			            }
			        })
					
				}else{
					$box.find(".error-msg").show();
				    $box.find(".error-msg span").html(commsg.msg7);
				}
			}else{
				$box.find(".error-msg").show();
			    $box.find(".error-msg span").html(commsg.msg6);
			}
	})
	// 语音验证

	$yuyinbtn.on("click",function(){
			var _this = $(this);
			if(phoneok){
				$box.find(".error-msg").hide();
			    $box.find(".error-msg span").html("");
				// 点击获取
				if(ok){
					ok = false;
					var phoneNum = $.trim($(".js-phone-num").val());
					var _data = {mobile:phoneNum,sendType:'voice'};
					$.ajax({
			            url:qqsms,
			            data:_data,
			            type:'post',
			            dataType:'json',
			            success : function(data){
			            	if(data.errcode =="0"){
			            		num = 60;
			            		_this.addClass("hui");
			            		timer = setInterval(function(){
			            			num--;
			            			if(num <= 0){
			            				num = 0;
			            				clearInterval(timer);
			            				_this.removeClass("hui");
			            				_this.html("点击获取");
			            				ok = true;
			            			}else{
			            				_this.html(""+num+"s后重试");
			            			}
			            			
			            		},1000);
			            	}else{
			            		ok = true;
		            			$box.find(".error-msg").show();
		            		    $box.find(".error-msg span").html(data.msg);
			            	}
			            }
			        })
					
				}
			}else{
				$box.find(".error-msg").show();
			    $box.find(".error-msg span").html(commsg.msg6);
			}
	});
	// 协议同意操作
	var xieyiava = true;
    $('#js-xieyi-yesno').on('click',function () {
    	if($(this).hasClass('no')){	
    		xieyiava = true;
    		$(this).removeClass('no');
    		$box.find(".error-msg").hide();
    		return;
    	}
    	xieyiava = false;
    	$(this).addClass('no');
    });


	function timereset(data){
	        var theTime = parseInt(data);//秒
	        var theTime1 = 0;//分
	        var theTime2 = 0;//时
	        if(theTime>60){
	            theTime1 = parseInt(theTime/60);
	            theTime = parseInt(theTime%60);
	            if(theTime1>60){
	                theTime2 = parseInt(theTime1/60);
	                theTime1 = parseInt(theTime1%60);
	            }
	        }
	        var result = ""+parseInt(theTime)+"秒";
	        if(theTime1>0){
	            result=""+parseInt(theTime1)+"分"+result;
	        }
	        if(theTime2>0){
	            result=""+parseInt(theTime2)+"时"+result;
	        }
	        return result;
	    }


	// 确定
	var comIPtime = null;
	$box.on("click",".loginBtn",function(){
		if(newuser){
			//new
			var phonum = $.trim($(".js-phone-num").val()),
			yan = $.trim($(".js-yan").val()),
			psdone = $.trim($('.js-pass-one').val()),
			psdtwo = $.trim($('.js-pass-two').val());
		if(phonum == "" || phonum == null){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg1);
			return false;
		}	
		if(yan == "" || yan == null){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg3);
			return false;
		}
		if(psdone == "" || psdone == null || psdtwo == "" || psdtwo == null){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg4);
			return false;
		}else if(psdone.length < 6 || psdtwo.length < 6){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg5);
			return false;
		}else if(psdone !== psdtwo){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg8);
			return false;			
		}else if(!newimgava){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html('亲,请输入正确的验证码');
		    return false;
		}else if(!smsava){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html('亲,请输入正确的手机验证码');
		    return false;
		}else if(!xieyiava){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html('亲,请同意服务协议');
		    return false;
		}
 		// 直接提交
        	var password = psdone, //修改为了密码
			    mobile = $.trim($(".js-phone-num").val()),
			    openid = $("#js-openid").val(),
			    gender = $("#js-gender").val(),
			    userpic = $("#js-userpic").val(),
			    unionid = $('#js-unionid').val(),
			    nickname = $("#js-nickname").val();
			var newdata = {
					mobile:mobile,
	            	openid:openid,
	            	unionid:unionid,
	            	gender:gender,
	            	userpic:userpic,
	            	nickname:nickname,
	            	smsVerifyCode:$(".js-yan").val(),
	            	password:password,
	            	passwordAgain:$(".js-pass-two").val(),
	            	regsource:4,
	            	type:1
				};
			comajax(comgo,newdata,function (data) {
				if(data.errcode == 0){
			    		$box.hide();
            			$two.show();
            			$("#js-bangphone").html(data.data.mobile);
	            	}else{
	            		$box.find(".error-msg").show(mobile);
			    		$box.find(".error-msg span").html(data.msg);
	            	}
			});			
		}else{
			//old			
		var oldphonum = $.trim($(".js-phone-num2").val()),
			oldyan = $.trim($(".js-tuyan2").val()),
			oldpsdone = $.trim($('.js-pass2').val());
		if(oldphonum == "" || oldphonum == null){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg1);
			return false;
		}	
		if(oldyan == "" || oldyan == null){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg3);
			return false;
		}
		if(oldpsdone == "" || oldpsdone == null){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html(commsg.msg4);
			return false;
		}else if(!oldimgava){
			$box.find(".error-msg").show();
		    $box.find(".error-msg span").html('亲,请输入正确的验证码');
		    return false;
		}
 		// 直接提交
        	var openid = $("#js-openid").val(),
			    gender = $("#js-gender").val(),
			    userpic = $("#js-userpic").val(),
			    nickname = $("#js-nickname").val();
			
			var olddata = {
					mobile:$.trim($(".js-phone-num2").val()),
					userpic:$("#js-userpic").val(),
			    	nickname:$("#js-nickname").val(),
	            	openid:openid,
	            	unionid:$('#js-unionid').val(),
	            	password:$.trim($(".js-pass2").val()),
	            	type:2
			};
			comajax(comgo,olddata,function (data) {
				if(data.errcode == 101092){
					clearInterval(comIPtime);
					var time = data.data.time;
					$box.find(".error-msg span").html(data.msg+timereset(time)+'后操作');
					$box.find(".error-msg").show();
					comIPtime = setInterval(function () {
						if(time <= 0){
							clearInterval(comIPtime);
							$box.find(".error-msg").hide();
						}else{
							time --;
							$box.find(".error-msg span").html(data.msg+timereset(time)+'后操作');
						}	
					},1000)
				}else if(data.errcode == 0){
		    		$box.hide();
        			$two.show();
        			oktime($oktmb);
        			$('#js-okzc').hide();
        			$('#js-okbd').css('display','block');
        			$("#js-bangphone").html(data.data.mobile);
	            }else{
            		$box.find(".error-msg").show(mobile);
		    		$box.find(".error-msg span").html(data.msg);
	            }
			});						
		}		       
	});		
	// 成功page的倒计时
    var okwait = 3,
    	$oktmb = $('#js-timedown'); //成功以后的倒计时盒子里面的input
	function oktime(o) {
        if (okwait == 0) {
        	window.location.href = '/';
            okwait = 3;
        } else {		        	
            o.val(okwait +"秒后自动返回-游戏中心首页");
            okwait--;
            setTimeout(function() {
                oktime(o);
            },
            1000)
        }
    };
	
	
	//回车事件
	 $(document).keypress(function(e) {  
    // 回车键事件  
       if(e.which == 13) {
   			$('.loginBtn').click();  
       }  
   });
	
	// 密码强度
	$psone = $('.js-pass-one');
	$psone.on("input",function(){
		var val = $(this).val();
		strong(val);
	})
	// 密码强度
	function strong(v){
		var modes = 0;
		//正则表达式验证符合要求的
		var sValue = v;
		if (sValue.length < 6) {
		    modes = 0;
		}else{
		    if (/\d/.test(sValue)) modes++; //数字
		    if (/[a-z]/.test(sValue)) modes++; //小写
		    if (/[A-Z]/.test(sValue)) modes++; //大写
		    if (/\W/.test(sValue)) modes++; //特殊字符
		}
		// 12位以下的算3级别强度
		if (sValue.length < 12 && modes > 3) {
		    modes = 3;
		};

		if(modes <= 1){
			$(".js-qiangdu").html("弱");
		}else if(modes == 2){
			$(".js-qiangdu").html("中");
		}else if(modes == 3){
			$(".js-qiangdu").html("高");
		}else if(modes == 4){
			$(".js-qiangdu").html("强");
		}
	}
})