define('home.widget.errorpagegame.game', function () {
			var clear = require("home.static.js.index.error404");
			// 定义画布
			var canvas = document.getElementById("canvas");
			var context = canvas.getContext("2d");
			var mask = document.getElementById("mask");
			var scorebox = document.getElementById("score");
			var timingbox = document.getElementById("timing");
			const WIDTH = canvas.width;
			const HEIGHT = canvas.height;
			const START = 0;
			const STARTTING = 1;
			const RUNNING = 2;
			const PAUSED = 3;
			const GAMEOVER = 4;
			const GOODGAME = 5;
			var status = START;
			var score=0;
			var timing=30;

			// 背景
			var bg = new Image();
			bg.src = __uri('images/bg1000.png');
			var SKY = {
				imgs : bg,
				width : 1000,
				height : 300
			}
			function Sky(config){
				this.imgs = config.imgs;
				this.width = config.width;
				this.height = config.height;
				this.x = 0;
				this.y = 0;
				this.paint = function(cxt){
					cxt.drawImage(this.imgs,this.x,this.y,this.width,this.height);
				}
			}
			var sky = new Sky(SKY);

			// LOGO
			var logo=new Image();
			logo.src=__uri("images/bg_logo.png");


			// 状态切换
			mask.onclick=function(){
				var ox = event.offsetX;
				var oy = event.offsetY+14;
				if(status==START&&(ox>452&&ox<550&&oy>108&&oy<146)){
					clear.clear();
					status=RUNNING;
				}else if(status==GAMEOVER&&(ox>445&&ox<553&&oy>128&&oy<158)){
					hero=new Hero(HERO);
					bird=new Bird(BIRD);
					enemies=[];
					score=0;
					timing=30;
					status=RUNNING;
				}else if(status==GOODGAME&&(ox>515&&ox<623&&oy>128&&oy<158)){
					hero=new Hero(HERO);
					bird=new Bird(BIRD);
					enemies=[];
					score=0;
					timing=30;
					status=RUNNING;
				}
			}


			//鸡蛋
			var heros=[[],[],[],[],[]];
			heros[0][0]=new Image();
			heros[0][0].src=__uri("images/lie11.png");
			heros[0][1]=new Image();
			heros[0][1].src=__uri("images/lie12.png");
			heros[0][2]=new Image();
			heros[0][2].src=__uri("images/lie13.png");
			heros[0][3]=new Image();
			heros[0][3].src=__uri("images/lie14.png");
			heros[0][4]=new Image();
			heros[0][4].src=__uri("images/lie15.png");
			heros[1][0]=new Image();
			heros[1][0].src=__uri("images/lie21.png");
			heros[1][1]=new Image();
			heros[1][1].src=__uri("images/lie22.png");
			heros[1][2]=new Image();
			heros[1][2].src=__uri("images/lie23.png");
			heros[1][3]=new Image();
			heros[1][3].src=__uri("images/lie24.png");
			heros[1][4]=new Image();
			heros[1][4].src=__uri("images/lie25.png");
			heros[2][0]=new Image();
			heros[2][0].src=__uri("images/lie31.png");
			heros[2][1]=new Image();
			heros[2][1].src=__uri("images/lie32.png");
			heros[2][2]=new Image();
			heros[2][2].src=__uri("images/lie33.png");
			heros[2][3]=new Image();
			heros[2][3].src=__uri("images/lie34.png");
			heros[2][4]=new Image();
			heros[2][4].src=__uri("images/lie35.png");
			heros[3][0]=new Image();
			heros[3][0].src=__uri("images/ji1.png");
			heros[3][1]=new Image();
			heros[3][1].src=__uri("images/ji2.png");
			heros[3][2]=new Image();
			heros[3][2].src=__uri("images/ji3.png");
			heros[3][3]=new Image();
			heros[3][3].src=__uri("images/ji4.png");
			heros[3][4]=new Image();
			heros[3][4].src=__uri("images/ji5.png");
			heros[4][0]=new Image();
			heros[4][0].src=__uri("images/hun1.png");
			heros[4][1]=new Image();
			heros[4][1].src=__uri("images/hun2.png");
			heros[4][2]=new Image();
			heros[4][2].src=__uri("images/hun3.png");
			heros[4][3]=new Image();
			heros[4][3].src=__uri("images/hun4.png");
			heros[4][4]=new Image();
			heros[4][4].src=__uri("images/hun5.png");
			var HERO={
				imgs:heros,
				width:72,
				height:94,
				count:5
			}
			function Hero(config){
				this.imgs=config.imgs;
				this.width=config.width;
				this.height=config.height;
				this.count=config.count;
				this.i=0;
				this.j=0;
				this.canDown=false;
				this.canUp=false;
				this.x=(WIDTH-this.width)/2;
				this.y=HEIGHT-this.height-40;
				this.speed=0;
				this.paint=function(context){
					context.drawImage(this.imgs[this.i][this.j],this.x,this.y,this.width,this.height);
				}
				this.step=function(){
					this.speed++;
					if(this.canDown){
						if(this.speed%15==0){
							this.j++;
						}
						if(this.j==this.count){
							bird.down();
							status=GAMEOVER;
							this.j=this.count-1;
						}
					}else if(this.canUp){
						if(this.speed%15==0){
							this.j++;
						}
						if(this.j==this.count){
							bird.up();
							status=GOODGAME;
							this.j=this.count-1;
						}
					}else{
						if(this.speed%1000==0){
							this.i++;
						}
						if(this.speed%15==0){
							this.j++;
							this.j=this.j%this.count;
						}
						if(this.i==3){
							this.up();
						}
						if(this.speed%100==0){
							timing--;
						}
						if(timing<0){
							timing=0;
						}
					}
				}
				this.down=function(){
					this.canDown=true;
					this.i=4;
					this.j=0;
				}
				this.up=function(){
					this.canUp=true;
					this.i=3;
					this.j=0;
				}
			}
			var hero=new Hero(HERO);
			


			//游戏结果面板
			var birds=[];
			birds[0]=new Image();
			birds[0].src=__uri("images/panel1.png");
			birds[1]=new Image();
			birds[1].src=__uri("images/panel2.png");
			birds[2]=new Image();
			birds[2].src=__uri("images/panel3.png");
			var BIRD={
				imgs:birds,
				width:300,
				height:150,
				count:birds.length
			}
			function Bird(config){
				this.imgs=config.imgs;
				this.width=config.width;
				this.height=config.height;
				this.count=config.count;
				this.index=0;
				this.canDown=false;
				this.canUp=false;
				this.x=(WIDTH-this.width)/2;
				this.y=HEIGHT-HERO.height-this.height-40;
				this.speed=0;
				this.paint=function(context){
					context.drawImage(this.imgs[this.index],this.x,this.y,this.width,this.height);
				}
				this.step=function(){
					if(this.canDown){
						this.index=1;
					}else if(this.canUp){
						this.index=2;
					}else{

					}
				}
				this.down=function(){
					this.canDown=true;
				}
				this.up=function(){
					this.canUp=true;
				}
			}
			var bird=new Bird(BIRD);



			// 左侧敌人
			var enemies1L=[];
			enemies1L[0]=new Image();
			enemies1L[0].src=__uri("images/k4.png");
			enemies1L[1]=new Image();
			enemies1L[1].src=__uri("images/k5.png");
			enemies1L[2]=new Image();
			enemies1L[2].src=__uri("images/k6.png");
			enemies1L[3]=new Image();
			enemies1L[3].src=__uri("images/enemy1_down1.png");
			enemies1L[4]=new Image();
			enemies1L[4].src=__uri("images/enemy1_down2.png");
			enemies1L[5]=new Image();
			enemies1L[5].src=__uri("images/enemy1_down3.png");
			enemies1L[6]=new Image();
			enemies1L[6].src=__uri("images/enemy1_down4.png");
			var enemies2L=[];
			enemies2L[0]=new Image();
			enemies2L[0].src=__uri("images/x4.png");
			enemies2L[1]=new Image();
			enemies2L[1].src=__uri("images/x5.png");
			enemies2L[2]=new Image();
			enemies2L[2].src=__uri("images/x6.png");
			enemies2L[3]=new Image();
			enemies2L[3].src=__uri("images/enemy2_down1.png");
			enemies2L[4]=new Image();
			enemies2L[4].src=__uri("images/enemy2_down2.png");
			enemies2L[5]=new Image();
			enemies2L[5].src=__uri("images/enemy2_down3.png");
			enemies2L[6]=new Image();
			enemies2L[6].src=__uri("images/enemy2_down4.png");
			var enemies3L=[];
			enemies3L[0]=new Image();
			enemies3L[0].src=__uri("images/g4.png");
			enemies3L[1]=new Image();
			enemies3L[1].src=__uri("images/g5.png");
			enemies3L[2]=new Image();
			enemies3L[2].src=__uri("images/g6.png");
			enemies3L[3]=new Image();
			enemies3L[3].src=__uri("images/enemy3_down1.png");
			enemies3L[4]=new Image();
			enemies3L[4].src=__uri("images/enemy3_down2.png");
			enemies3L[5]=new Image();
			enemies3L[5].src=__uri("images/enemy3_down3.png");
			enemies3L[6]=new Image();
			enemies3L[6].src=__uri("images/enemy3_down4.png");
			enemies3L[7]=new Image();
			enemies3L[7].src=__uri("images/enemy3_down5.png");
			enemies3L[8]=new Image();
			enemies3L[8].src=__uri("images/enemy3_down6.png");
			var ENEMY1L={
				imgs:enemies1L,
				width:38,
				height:40,
				count:enemies1L.length,
				type:1,
				score:1
			}
			var ENEMY2L={
				imgs:enemies2L,
				width:52,
				height:47,
				count:enemies2L.length,
				type:2,
				score:3
			}
			var ENEMY3L={
				imgs:enemies3L,
				width:45,
				height:56,
				count:enemies3L.length,
				type:3,
				score:9
			}
			function EnemyL(config){
				this.imgs=config.imgs;
				this.width=config.width;
				this.height=config.height;
				this.count=config.count;
				this.type=config.type;
				this.score=config.score;
				this.x=0;
				this.y=HEIGHT-this.height-40;
				this.index=0;
				this.canDown=false;
				this.canDelete=false;
				this.paint=function(context){
					context.drawImage(this.imgs[this.index],this.x,this.y,this.width,this.height);
				}
				this.speed=0;
				this.step=function(){
					this.speed++;
					if(this.canDown){
						if(this.speed%10==0){
							this.index++;
						}
						if(this.index==this.count){
							this.canDelete=true;
						}
					}else{
						switch(this.type){
							case 1:
								if(this.speed%15==0){
									this.index=(++this.index)%3;
								}
								this.x+=0.7;
								break;
							case 2:
								if(this.speed%15==0){
									this.index=(++this.index)%3;
								}
								this.x+=1.0;
								break;
							case 3:
								if(this.speed%15==0){
									this.index=(++this.index)%3;
								}
								this.x+=0.4;
								break;
						}
					}
				}
				this.down=function(){
					this.canDown=true;
					score+=this.score;
				}
				this.hit3=function(ox,oy){
					return ox>this.x && 
						   ox<this.x+this.width &&
						   oy>this.y &&
						   oy<this.y+this.height;
				}
				this.hit4=function(compont){
					return compont.x<this.x+this.width &&
						   compont.x+compont.width>this.x;
				}
			}
			// 右侧敌人
			var enemies1R=[];
			enemies1R[0]=new Image();
			enemies1R[0].src=__uri("images/k1.png");
			enemies1R[1]=new Image();
			enemies1R[1].src=__uri("images/k2.png");
			enemies1R[2]=new Image();
			enemies1R[2].src=__uri("images/k3.png");
			enemies1R[3]=new Image();
			enemies1R[3].src=__uri("images/enemy1_down1.png");
			enemies1R[4]=new Image();
			enemies1R[4].src=__uri("images/enemy1_down2.png");
			enemies1R[5]=new Image();
			enemies1R[5].src=__uri("images/enemy1_down3.png");
			enemies1R[6]=new Image();
			enemies1R[6].src=__uri("images/enemy1_down4.png");
			var enemies2R=[];
			enemies2R[0]=new Image();
			enemies2R[0].src=__uri("images/x1.png");
			enemies2R[1]=new Image();
			enemies2R[1].src=__uri("images/x2.png");
			enemies2R[2]=new Image();
			enemies2R[2].src=__uri("images/x3.png");
			enemies2R[3]=new Image();
			enemies2R[3].src=__uri("images/enemy2_down1.png");
			enemies2R[4]=new Image();
			enemies2R[4].src=__uri("images/enemy2_down2.png");
			enemies2R[5]=new Image();
			enemies2R[5].src=__uri("images/enemy2_down3.png");
			enemies2R[6]=new Image();
			enemies2R[6].src=__uri("images/enemy2_down4.png");
			var enemies3R=[];
			enemies3R[0]=new Image();
			enemies3R[0].src=__uri("images/g1.png");
			enemies3R[1]=new Image();
			enemies3R[1].src=__uri("images/g2.png");
			enemies3R[2]=new Image();
			enemies3R[2].src=__uri("images/g3.png");
			enemies3R[3]=new Image();
			enemies3R[3].src=__uri("images/enemy3_down1.png");
			enemies3R[4]=new Image();
			enemies3R[4].src=__uri("images/enemy3_down2.png");
			enemies3R[5]=new Image();
			enemies3R[5].src=__uri("images/enemy3_down3.png");
			enemies3R[6]=new Image();
			enemies3R[6].src=__uri("images/enemy3_down4.png");
			enemies3R[7]=new Image();
			enemies3R[7].src=__uri("images/enemy3_down5.png");
			enemies3R[8]=new Image();
			enemies3R[8].src=__uri("images/enemy3_down6.png");
			var ENEMY1R={
				imgs:enemies1R,
				width:38,
				height:40,
				count:enemies1R.length,
				type:1,
				score:1
			}
			var ENEMY2R={
				imgs:enemies2R,
				width:52,
				height:47,
				count:enemies2R.length,
				type:2,
				score:3
			}
			var ENEMY3R={
				imgs:enemies3R,
				width:45,
				height:56,
				count:enemies3R.length,
				type:3,
				score:9
			}
			function EnemyR(config){
				this.imgs=config.imgs;
				this.width=config.width;
				this.height=config.height;
				this.count=config.count;
				this.type=config.type;
				this.score=config.score;
				this.x=WIDTH-this.width;
				this.y=HEIGHT-this.height-40;
				this.index=0;
				this.canDown=false;
				this.canDelete=false;
				this.paint=function(context){
					context.drawImage(this.imgs[this.index],this.x,this.y,this.width,this.height);
				}
				this.speed=0;
				this.step=function(){
					this.speed++;
					if(this.canDown){
						if(this.speed%10==0){
							this.index++;
						}
						if(this.index==this.count){
							this.canDelete=true;
						}
					}else{
						switch(this.type){
							case 1:
								if(this.speed%15==0){
									this.index=(++this.index)%3;
								}
								this.x-=0.7;
								break;
							case 2:
								if(this.speed%15==0){
									this.index=(++this.index)%3;
								}
								this.x-=1.0;
								break;
							case 3:
								if(this.speed%15==0){
									this.index=(++this.index)%3;
								}
								this.x-=0.4;
								break;
						}
					}
				}
				this.down=function(){
					this.canDown=true;
					score+=this.score;
				}
				this.hit3=function(ox,oy){
					return ox>this.x && 
						   ox<this.x+this.width &&
						   oy>this.y &&
						   oy<this.y+this.height;
				}
				this.hit4=function(compont){
					return compont.x<this.x+this.width &&
						   compont.x+compont.width>this.x;
				}
			}




			var enemies=[];
			function createEnemies(){
				var num=Math.random()*1000;
				if(num<10){
					var enemy=new EnemyL(ENEMY1L);
					enemies.push(enemy);
				}else if(num<20){
					var enemy=new EnemyR(ENEMY1R);
					enemies.push(enemy);
				}else if(num<26){
					var enemy=new EnemyL(ENEMY2L);
					enemies.push(enemy);
				}else if(num<32){
					var enemy=new EnemyR(ENEMY2R);
					enemies.push(enemy);
				}else if(num<36){
					var enemy=new EnemyL(ENEMY3L);
					enemies.push(enemy);
				}else if(num<40){
					var enemy=new EnemyR(ENEMY3R);
					enemies.push(enemy);
				}
			}
			function paintEnemies(){
				for(var i=0;i<enemies.length;i++){
					var enemy=enemies[i];
					enemy.paint(context);
				}
			}
			function stepEnemies(){
				for(var i=0;i<enemies.length;i++){
					var enemy=enemies[i];
					enemy.step();
				}
			}
			function deleteEnemies(){
				for(var i=0;i<enemies.length;i++){
					var enemy=enemies[i];
					if(enemy.canDelete){
						enemies.splice(i,1);
						i--;
					}
				}
			}
			//点击
			function clickHit(ox,oy){
				for(var i=0;i<enemies.length;i++){
					var enemy=enemies[i];
					if(enemy.hit3(ox,oy)){
						enemy.down();
					}
				}
			}
			//消除全部怪物
			function clickHitAll(){
				for(var i=0;i<enemies.length;i++){
					var enemy=enemies[i];
					enemy.down();
				}
			}
			//撞击
			function checkHit(){
				for(var i=0;i<enemies.length;i++){
					var enemy=enemies[i];
					if(enemy.hit4(hero)){
						enemy.canDelete=true;
					}
					if(enemy.hit4(hero)&&!hero.canDown){
						hero.down();
					}
				}
			}
			// 分数
			function scoreput(){
				scorebox.innerText=score;
			}
			// 倒计时
			function timingput(){
				timingbox.innerText=timing;
			}
			






			// 定义游戏的核心控制器
			setInterval(function(){
				sky.paint(context);
				switch(Number(status)){
					case START:
						context.drawImage(logo,0,0,1000,300);
						break;
					case STARTTING:
						break;
					case RUNNING:
						hero.paint(context);
						hero.step();
						bird.paint(context);
						bird.step();
						createEnemies();
						paintEnemies();
						stepEnemies();
						deleteEnemies();
						checkHit()
						scoreput();
						timingput();
						break;
					case PAUSED:
						break;
					case GAMEOVER:
						hero.paint(context);
						bird.paint(context);
						bird.step();
						paintEnemies();
						break;
					case GOODGAME:
						hero.paint(context);
						bird.paint(context);
						bird.step();
						paintEnemies();
						stepEnemies();
						deleteEnemies();
						clickHitAll();
						break;
				}
			},10);


			// 定义鼠标指针
			mask.onmousedown = function(){
				
				this.style.cursor = 'url('+__uri("images/c4.ico")+'),auto';
				var ox = event.offsetX;
				var oy = event.offsetY+14;
				clickHit(ox,oy);
				// clickHitAll();
			}
			mask.onmouseup = function(){
				this.style.cursor = 'url('+__uri("images/c3.ico")+'),auto';
			}
			mask.onmousemove = function(){}



})
