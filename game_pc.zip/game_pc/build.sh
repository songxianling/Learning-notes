rm -rf /d/work/RD/game_pc/template/
echo 'rm template ok...'
rm -rf /d/work/RD/game_pc/web/static/
echo 'rm static ok...'
fis3 release qa -r common
echo 'release common...'
fis3 release qa -r home
echo 'release home...'
rm -rf /d/work/RD/game_pc/test/
#./yii trades/create-game-json
echo 'ok!'
