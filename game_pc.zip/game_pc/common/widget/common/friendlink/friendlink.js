define("common.widget.common.friendlink.friendlink", function() {
	var $par = $("#js-linktext-panel");

	$par.on("click","a",function(){
	    var id = $(this).attr("data-id");
	    $.ajax({
	        url: '/com/friendlink?id='+id,
	        type: 'get',
	        dataType: 'json',
	        async:true,
	        success: function(data) {

	        }
	    }); 
	})
})
