define("common.widget.common.topnav.topnav", function() {
	//载入加密文件
	if(!$.jCryption){
	    require.loadJs('/static/common/static/js/jquery/jquery_jcryption_3_1_0.js');
	}

	var $par = $("#logo-panel"),
		$uls = $par.find(".js-common-topnav-searhgames"),
		$searchBox = $(".js-logo-panel-searchbox");

	// 选择礼包还是游戏
	$searchBox.on("mouseover",".searchleft",function(){
		$uls.show();
	})
	$searchBox.on("mouseout",".searchleft",function(){
		$uls.hide();
	})

	$uls.on("click","li",function(){
		var oldtit = $par.find(".js-common-topnav-games >span").html(),
			oldid = $par.find(".js-common-topnav-games").attr("data-id");
		var id = $(this).attr("data-id"),
			txt = $(this).text();
		$par.find(".js-common-topnav-games >span").text(txt);
		$par.find(".js-common-topnav-games").attr("data-id",id);
		$(this).find("a").html(oldtit);
		$(this).attr("data-id",oldid);
		$uls.hide();
	})

	// 点击搜索
	var searchBtn = $("#js-logo-panel2-searchbtn");

	searchBtn.on("click",function(){
		goHref();
	})

	// enter
	$("#js-logo-panel1-inputbox").find("input").focus(function() {
        // 处理...
    	$("body").keydown(function() {
             if (event.keyCode == "13") {//keyCode=13是回车键
                goHref();
             }
         });
 
    });


	function goHref(){
		var id = $par.find(".js-common-topnav-games").attr("data-id"),
			wd = $.trim($("#js-logo-panel1-inputbox").find("input").val()),
			os = $("#logo-panel1-os").val(),
			sort = $("#logo-panel1-sort").val(),
			categoryid = $("#logo-panel1-Categoryid").val();
		if(wd != "" && wd != null){
			if(id == 2){
				window.location.href = "/gift/search?wd="+wd;
			}else if(id == 1){
				window.location.href = "/game?wd="+wd;
			}
		}
		
	}

	// 登录按钮
	var btn = $("#js-logo-panel1-btn"),
		url = $("#gb-redirectLoginUrl").val();

	var cururl = encodeURIComponent(document.location.href);

	btn.attr("href","/siteauth/auth/login");

	// 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_index_topnav");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gamecenter/index";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    
    
    var navurl = $('#js-navurl').val(),
    	$loginout = $('#js-loginout');
    	
    $loginout.on('click',function () {
    	$.ajax({
				type:"post",
				url:navurl+"/api/user/logout",
				async:true,
				data:{},
				xhrFields:{withCredentials:true},
				success:function (data) {
					window.location.href = "/";		
				}	
			});
    });

});
