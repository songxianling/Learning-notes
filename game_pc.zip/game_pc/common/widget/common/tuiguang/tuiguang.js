define("common.widget.common.tuiguang.tuiguang", function() {

	var $tuiguangBox = $("#js-c-tuiguang-box"),
		$ico1 = $("#js-ico-1");
    $tuiguangBox.on("click",'.js-showbtn1',function(){
        $(this).hide();
        $(".js-showbtn2").show();
        $tuiguangBox.css({"width":"350px"}); 
    })
    $tuiguangBox.on("click",'.js-showbtn2',function(){
        $(this).hide();
        $(".js-showbtn1").show();
        $tuiguangBox.css({"width":"105px"});  
    })

    /*点击复制功能*/
    var $iuput = $("#js-hide-code"),
        $btn = $("#js-ico-2"),
        btnName = "js-ico-2";

    btnCopy($iuput,$btn,btnName);

    function btnCopy(i,btn,b) {
        
        i.click(function(){
            $(this).select();
        });
        btn.each(function(){
            ZeroClipboard.setMoviePath($(this).attr("data-url"));
            var clip = new ZeroClipboard.Client(); // 新建一个对象
            clip.setHandCursor(true ); // 设置鼠标为手型
            clip.setText(""); // 设置要复制的文本。
            clip.setHandCursor(true);
            clip.setCSSEffects(true);
            clip.addEventListener('complete', function(client, text) {
                alert("推广链接复制成功！" );
            } );
            clip.addEventListener('mouseDown', function(client) {
                console.log(client)
                clip.setText(i.val());
            } );
            clip.glue(b);
            $(this).click(function(e){
                e.preventDefault();
                alert("啊哦，好像复制失败了……手动复制一下吧！");
            });
        });
    }

})
