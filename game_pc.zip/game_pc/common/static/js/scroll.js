// 自定义的滚动轴
define("common.static.js.scroll", function() {
    function AddScroll() {
        this.init.apply(this, arguments);
    }
    AddScroll.prototype = {
        init : function(data) {
            this.mainBox = data.mainBox;
            this.contentBox = data.contentBox;
            this._wheelData = data.wheelData || -1;
            this.wheelSpend = data.wheelSpend || 100;
            this.scollConclass = data.scollConclass || "";
            this.scollBgclass = data.scollBgclass || "";
            this.scollTragclass = data.scollTragclass || "";
            this.ratio = 1;
            this.maxTop = 0;
            scollclass = data.scollDivClassName || "";

            // 设置外层容器属性
            this.mainBox.css("position", "relative");
            this.mainBox.css("overflow", "hidden");
            this.mainBox.width("100%");
            this.mainBox.height(data.mainBoxHeight);
            // 需要给contentBox 增加绝对定位属性
            this.contentBox.css("position", "absolute");
            this.contentBox.css("left", "0");
            this.contentBox.css("top", "0");
            // var iscreate = this.mainBox.attr("g_scroll");

            this.scrollDiv = this._createScroll(this.mainBox, scollclass, this.scollConclass);
            this._resizeScorll($(this.scrollDiv), this.mainBox, this.contentBox, this.scollBgclass);
            this._tragScroll($(this.scrollDiv), this.mainBox, this.contentBox, this.scollTragclass);
            this._wheelChange($(this.scrollDiv), this.mainBox, this.contentBox);
            this._clickScroll($(this.scrollDiv), this.mainBox, this.contentBox);
            this.mainBox.attr("g_scroll", "1");
        },
        resetScorll : function(){
            var mythis = this;
            this._resizeScorll($(mythis.scrollDiv), mythis.mainBox, mythis.contentBox, mythis.scollBgclass);
        },
        // 创建滚动条
        _createScroll : function(mainBox, className, cdata) {
            // 判断如果存在了不在重复创建
            var tmp = $(".js-gb-scrollbox", mainBox);
            if (tmp.length > 0) {
                // 重置top
                tmp.css("top",0);
                return tmp[0];
            };
            var _scrollBox = document.createElement('div')
            var _scroll = document.createElement('div');
            var span = document.createElement('i');
            _scrollBox.appendChild(_scroll);
            _scroll.appendChild(span);
            if (className) {
                _scroll.className = className;
            }else{
                _scroll.style.width = cdata.width || "6px";
                _scroll.style.top = cdata.top || "0";
                _scroll.style.position = cdata.position || "absolute";
                _scroll.style.background =  cdata.bcolor || "#aaa";
            }
            $(_scroll).addClass("js-gb-scrollbox");
            $(_scroll).css("border-radius", "5px");
            mainBox.append(_scrollBox);
            return _scroll;
        },
        // 调整滚动条
        _resizeScorll : function(element, mainBox, contentBox, cdata) {
            var $p = element.parent();
            var conHeight = contentBox.outerHeight();
            var _width = mainBox.width();
            var _height = mainBox.height();
            var _scrollWidth = element.outerWidth();
            // var _left = _width - _scrollWidth - 2*2;
            $p.width(_scrollWidth + "px");
            $p.height(_height + "px");
            $p.css("right",  "0px");
            $p.css("position", "absolute");
            var bcolor = cdata.bcolor || "#ddd",
                pad = cdata.pad || "0 2px";
            $p.css("background", bcolor);
            $p.css("padding", pad);
            var _scrollHeight = parseFloat(_height * (_height / conHeight));
            if (_scrollHeight >= mainBox.innerHeight()) {
                $p.hide();
                contentBox.width(mainBox.outerWidth() + "px");
            }else{
                $p.show();
                contentBox.width((mainBox.outerWidth() - _scrollWidth) + "px");
                // 如果_scrollHeight过小设置下限值
                if (_scrollHeight < 20 ) {
                    this.ratio = 20 / _scrollHeight;
                    _scrollHeight = 20;
                };
            }
            this.maxTop = mainBox.innerHeight() - _scrollHeight;
            element.height(parseInt(_scrollHeight) + "px");
        },
        // 拖动滚动条
        _tragScroll : function(element, mainBox, contentBox, cdata) {
            var mainHeight = mainBox.innerHeight(), mythis = this;

            element.mousedown(function(e) {
                var _this = this;
                var _scrollTop = element[0].offsetTop;
                var top = e.clientY;
                //this.onmousemove=scrollGo;
                document.onmousemove = scrollGo;
                document.onmouseup = function(event) {
                    this.onmousemove = null;
                    // 解除事件
                    $(document).unbind("selectstart");
                }
                function scrollGo(event) {
                    var e = event || window.event;
                    var _top = e.clientY;
                    var _t = _top - top + _scrollTop,
                        _tt = 0;
                    if (_t > (mainHeight - parseFloat(element.outerHeight() / mythis.ratio))) {
                        _t = mainHeight - parseFloat(element.outerHeight() / mythis.ratio);
                    }
                    if (_t <= 0) {
                        _t = 0;
                    }
                    if (_t >= mythis.maxTop) {
                        _tt = mythis.maxTop;
                    }else{
                        _tt = _t;
                    }
                    element.css("top", _tt + "px");
                    contentBox.css("top", -_t * (contentBox.outerHeight() / mainBox.outerHeight()) + "px");
                    mythis._wheelData = _t;
                }
                // 防止拖拽到页面选择其他内容
                $(document).on("selectstart", function(){
                    return false;
                });
            });
            element.mouseover(function(){
                var vcolor = cdata.mvcolor || "#46474c";
                $(this).css("background", vcolor);
            });
            element.mouseout(function() {
                var vcolor = cdata.mocolor || "#aaa";
                $(this).css("background", vcolor);
            });
        },
        // 鼠标滚轮滚动，滚动条滚动
        _wheelChange : function(element, mainBox, contentBox) {
            var node = typeof mainBox == "string" ? $(mainBox) : mainBox;
            var flag = 0, rate = 0, wheelFlag = 0, mythis = this;
            if (node) {
                this._mouseWheel(
                        node,
                        function(data) {
                            // 判断是否存在滚动轴
                            if (element.parent().css("display")=="none") {
                                return;
                            };
                            wheelFlag += data;
                            if (mythis._wheelData >= 0) {
                                flag = mythis._wheelData;
                                element.css("top", flag + "px");
                                wheelFlag = mythis._wheelData * 12;
                                mythis._wheelData = -1,
                                _tt = 0;
                            } else {
                                flag = wheelFlag / 12;
                            }
                            if (flag <= 0) {
                                flag = 0;
                                wheelFlag = 0;
                            }
                            if (flag >= (mainBox.outerHeight() - parseFloat(element.outerHeight() / mythis.ratio))) {
                                flag = (mainBox.innerHeight() - parseFloat(element.outerHeight() / mythis.ratio));
                                wheelFlag = (mainBox.innerHeight() - parseFloat(element.outerHeight() / mythis.ratio)) * 12;
                            }

                            if (flag >= mythis.maxTop) {
                                _tt = mythis.maxTop;
                            }else{
                                _tt = flag;
                            }

                            element.css("top", _tt + "px");
                            contentBox.css("top", -flag * (contentBox.outerHeight() / mainBox.outerHeight()) + "px");
                        },element);
            }
        },
        // 点击滚动轴
        _clickScroll : function(element, mainBox, contentBox) {
            var $p = element.parent(), mythis = this;
            $p.click(function(e){
                var t = e.target || e.srcElement;
                var sTop = document.documentElement.scrollTop > 0 ? document.documentElement.scrollTop : document.body.scrollTop;
                var top = $(mainBox).offset().top;
                var _top = e.clientY + sTop - top - element.outerHeight() / 2,
                    mtop = 0;
                if (_top <= 0) {
                    _top = 0;
                }
                if (_top >= (mainBox.innerHeight() - parseFloat(element.outerHeight() / mythis.ratio))) {
                    _top = mainBox.innerHeight() - parseFloat(element.outerHeight() / mythis.ratio);
                }
                mtop = _top;
                if (_top >= mythis.maxTop) {
                    _top = mythis.maxTop;
                    mtop = mainBox.innerHeight() - parseFloat(element.outerHeight() / mythis.ratio);
                }
                if (t != element[0]) {
                    element.css("top", _top + "px");
                    contentBox.css("top", -mtop * (contentBox.outerHeight() / mainBox.outerHeight()) + "px");
                    mythis._wheelData = mtop;
                }
            });
        },
        // 计算滚动
        _mouseWheel : function(obj, handler,element) {
            var node = typeof obj == "string" ? $(obj) : obj,
                mythis = this;
            node.mousewheel(function(event) {
                // console.log(event.deltaX, event.deltaY);
                var data = -event.deltaY * mythis.wheelSpend;
                handler(data);
                if (document.all) {
                    window.event.returnValue = false;
                } else {
                    if (element.parent().css("display")=="none") {
                        return;
                    };
                    event.preventDefault();
                }
            });
        }
    }
    return {justScroll : AddScroll};
});