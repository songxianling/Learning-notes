define('common.static.js.placeholder', function ($) {
    var createPlaceHolder = {
        //检测
        _check : function(){
            return 'placeholder' in document.createElement('input');
        },
        //初始化
        init : function(data){
            if(!this._check()){
                this.creatClew(data);
            }
        },
        //创建提示
        creatClew : function(data){
            var $obj = data.obj,
                h = data.h,
                color = data.color;
            $obj.each(function(index, element) {
                var self = $(this), txt = self.attr('placeholder');
                self.wrap($('<div></div>').css({position:'relative', zoom:'1', border:'none', background:'none', padding:'none', margin:'none',display:'inline-block'}));
                var paddingleft = self.css('margin-left'),
                    ph = self.parent().height,top = self.css('padding-top');
                var holder = $('<span></span>').text(txt).css({position:'absolute', left:0, top:top, height:h+'px', lineHeight:h+'px', paddingLeft:paddingleft, color:color, textAlign:"left", width:"auto",display:'inline'}).appendTo(self.parent());
                
                self.focusin(function(e) {
                    holder.hide();
                }).focusout(function(e) {
                    if(!self.val()){
                        holder.show();
                    }
                });
                holder.click(function(e) {
                    holder.hide();
                    self.focus();
                });
            });
        }
    };
    function init(data){
        createPlaceHolder.init(data);
    }
    //执行
    return{
        init : init
    }
});