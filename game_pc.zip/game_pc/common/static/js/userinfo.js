// 获取游戏数据
define("common.static.js.userinfo", function() {
    //载入加密文件
    if(!$.jCryption){
        require.loadJs('/static/common/static/js/jquery/jquery_jcryption_3_1_0.js');
    }

    var exporter = {},
        event = require("common.static.js.event");

    // 用户信息类
    var userInfoClass = {
        // AES加密url参数
        authPassWord : "",
        // 初始化获取用户信息
        _init : function(fn){
            $.jCryption.authenticate(userInfoClass.authPassWord, "/com/cryption/get-public-key", "/com/cryption/get-hands-hake", function(AESKey) {
                //获取用户登录状态
                $.get("/com/user/get-userinfo", {}, function(data){
                    fn(data);
                }, "text");
            }, function(){});
        },
        // 异步获取用户信息
        asynGetUserInfo : function(sucfn){
            userInfoClass._init(function(data){
                if (sucfn) {
                    sucfn(data);
                };
                exporter.emit('getUserInfo', data);
            });
        }
    };

    // 同步注册事件返回用户信息
    userInfoClass._init(function(data){
        exporter.emit('getUserInfo', data);
    });

    exporter = {
        asynGetUserInfo : userInfoClass.asynGetUserInfo,
        authPassWord : userInfoClass.authPassWord
    };
    event.eventable(exporter);
    return exporter;
});