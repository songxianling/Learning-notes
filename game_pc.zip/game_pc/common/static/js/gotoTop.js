// 滚到顶部事件
define("common.static.js.gotoTop", function() {
    var configDefaults = {
        offset : 300,
        scroll_top_duration : 700
    };

    function gotoTop(options, showfn, hidefn){
        var opts = $.extend({}, configDefaults, options);

        $(window).scroll(function(){
            if ($(this).scrollTop() > opts.offset) {
                if (showfn) {
                    showfn();
                };
            }else{
                if (hidefn) {
                    hidefn();
                };
            }
        });

        opts.obj.on('click', function(){
            $('body, html').animate({
                scrollTop: 0
                }, opts.scroll_top_duration
            );
        });
    }

    return {gotoTop : gotoTop};
});