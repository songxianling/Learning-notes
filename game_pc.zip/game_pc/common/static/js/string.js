String.prototype.Format = function()
{		 
    var str = this;
	for (var i=0; i<arguments.length; i++)
	{				 
		str=str.replace(new RegExp("\\{"+(i)+"\\}","ig"),arguments[i]); 
	}
	return str; 
}