/**
 * file: mod.js
 * ver: 1.0.11
 * update: 2015/05/14
 *
 * https://github.com/fex-team/mod
 */
var require, define;

(function(global) {
    if (require) return; // 避免重复加载而导致已定义模块丢失
    
    //声明全局变量保存数据
    if(!global.lionData){
        global.lionData = {};
    }

    var head = document.getElementsByTagName('head')[0],
        loadingMap = {},
        factoryMap = {},
        modulesMap = {},
        styleMap ={},
        resMap = {},
        pkgMap = {};
        global.lionData.scriptsMap = {};
    function createScript(url, onerror) {
        if (url in global.lionData.scriptsMap) return;
        global.lionData.scriptsMap[url] = true;

        var script = document.createElement('script');
        if (onerror) {
            var tid = setTimeout(onerror, require.timeout);

            script.onerror = function() {
                clearTimeout(tid);
                onerror();
            };

            function onload() {
                clearTimeout(tid);
            }

            if ('onload' in script) {
                script.onload = onload;
            } else {
                script.onreadystatechange = function() {
                    if (this.readyState == 'loaded' || this.readyState == 'complete') {
                        onload();
                    }
                }
            }
        }
        script.type = 'text/javascript';
        script.src = url;
        head.appendChild(script);
        return script;
    }



    function loadScript(id, callback, onerror) {
        var queue = loadingMap[id] || (loadingMap[id] = []);
        queue.push(callback);

        //
        // resource map query
        //
        var res = resMap[id] || resMap[id + '.js'] || {};
        var pkg = res.pkg;
        var url;

        if (pkg) {
            url = pkgMap[pkg].url;
        } else {
            url = res.url || id;
        }

        createScript(url, onerror && function() {
            onerror(id);
        });
    }

    define = function(id, factory) {
        if(typeof(id)=="function")  return;
        id = id.replace(/\.js$/i, '');
        factoryMap[id] = factory;

        var queue = loadingMap[id];
        if (queue) {
            for (var i = 0, n = queue.length; i < n; i++) {
                queue[i]();
            }
            delete loadingMap[id];
        }
    };

    require = function(id) {

        // compatible with require([dep, dep2...]) syntax.
        if (id && id.splice) {
            return require.async.apply(this, arguments);
        }

        id = require.alias(id);

        var mod = modulesMap[id];
        if (mod) {
            return mod.exports;
        }

        //
        // init module
        //
        var factory = factoryMap[id];
        if (!factory) {
            throw '[ModJS] Cannot find module `' + id + '`';
        }

        mod = modulesMap[id] = {
            exports: {}
        };

        //
        // factory: function OR value
        //
        var ret = (typeof factory == 'function') ? factory.apply(mod, [require, mod.exports, mod]) : factory;

        if (ret) {
            mod.exports = ret;
        }
        return mod.exports;
    };

    require.async = function(names, onload, onerror) {
        if (typeof names == 'string') {
            names = [names];
        }
    
        var needMap = {};
        var needNum = 0;

        function findNeed(depArr) {
            for (var i = 0, n = depArr.length; i < n; i++) {
                //
                // skip loading or loaded
                //
                var dep = require.alias(depArr[i]);

                if (dep in factoryMap) {
                    // check whether loaded resource's deps is loaded or not
                    var child = resMap[dep] || resMap[dep + '.js'];
                    if (child && 'deps' in child) {
                        findNeed(child.deps);
                    }
                    continue;
                }

                if (dep in needMap) {
                    continue;
                }

                needMap[dep] = true;
                needNum++;
                loadScript(dep, updateNeed, onerror);

                var child = resMap[dep] || resMap[dep + '.js'];
                if (child && 'deps' in child) {
                    findNeed(child.deps);
                }
            }
        }

        function updateNeed() {
            if (0 == needNum--) {
                var args = [];
                for (var i = 0, n = names.length; i < n; i++) {
                    args[i] = require(names[i]);
                }

                onload && onload.apply(global, args);
            }
        }

        findNeed(names);
        updateNeed();
    };

    require.resourceMap = function(obj) {
        var k, col;

        // merge `res` & `pkg` fields
        col = obj.res;
        for (k in col) {
            if (col.hasOwnProperty(k)) {
                resMap[k] = col[k];
            }
        }

        col = obj.pkg;
        for (k in col) {
            if (col.hasOwnProperty(k)) {
                pkgMap[k] = col[k];
            }
        }
    };

    require.loadJs = function(url) {
        //createScript(url);
        lioncreateScript(url);
    };


    /**
     * 替换解决js载入不同步的问题
     */
    function lioncreateScript(url) {
        if (url in global.lionData.scriptsMap) return;
        global.lionData.scriptsMap[url] = true;

        var xhr = new XMLHttpRequest();
        //xhr.open("GET",url+"?now=" + new Date().getTime(),false); 
        xhr.open("GET",url,false); 
        xhr.setRequestHeader("Cache-Control","no-cache");
        xhr.setRequestHeader('If-Modified-Since','0');
        xhr.send(null);

        if (xhr.readyState==4)
        {
            if(xhr.status==200){
                global.lionData.scriptsMap[url] = xhr.responseText;
                if(window.execScript){
                    window.execScript(xhr.responseText);
                }
                else
                {
                    var s=document.createElement("SCRIPT");
                    s.type="text/javascript";
                    if(global.lionData.scriptsMap[url]){
                        s.innerHTML="eval(lionData.scriptsMap['"+url+"']);";
                    }
                    else {
                        s.src=url;
                    }
                    document.getElementsByTagName("HEAD")[0].appendChild(s);
                    s=null;
                }
            }
            else{ throw new Error(xhr.status +": "+ xhr.statusText);}
        }
    }

    /**
       * 获取浏览器型号和版本号
       * @return Array [description]
       */
      function ianBrowserInfo(){
        var agent = navigator.userAgent.toLowerCase();
        var arr = [];
        var Browser = "";
        var Bversion = "";
        var verinNum = "";
        //IE
        if (agent.indexOf("msie") > 0) {
            if (navigator.appName == 'Microsoft Internet Explorer'){
                var ua = navigator.userAgent;
                var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
                if (re.exec(ua) != null){
                  Browser = "IE";
                  Bversion = parseFloat( RegExp.$1 );
                }
            }
        }
        //firefox
        else if (agent.indexOf("firefox") > 0) {
            var regStr_ff = /firefox\/[\d.]+/gi;
            Browser = "firefox";
            Bversion = "" + agent.match(regStr_ff);
        }
        //Chrome
        else if (agent.indexOf("chrome") > 0) {
            var regStr_chrome = /chrome\/[\d.]+/gi;
            Browser = "chrome";
            Bversion = "" + agent.match(regStr_chrome);
        }
        //Safari
        else if (agent.indexOf("safari") > 0 && agent.indexOf("chrome") < 0) {
            var regStr_saf = /version\/[\d.]+/gi;
            Browser = "safari";
            Bversion = "" + agent.match(regStr_saf);
        }
        //Opera
        else if (agent.indexOf("opera") >= 0) {
            var regStr_opera = /version\/[\d.]+/gi;
            Browser = "opera";
            Bversion = "" + agent.match(regStr_opera);
        } else {
            var browser = navigator.appName;
            if (browser == "Netscape") {
                var ua = navigator.userAgent;
                var re  = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
                if (re.exec(ua) != null){
                  rv = parseFloat( RegExp.$1 );
                }

                Bversion = parseFloat(rv);
                Browser = "IE"
            }
        }
        arr.push(Browser);
        arr.push(Bversion);
        return arr;
      }

    var lionBrowser = ianBrowserInfo();

    require.loadCss = function(cfg) {

        if (cfg.content) {
            var sty = document.createElement('style');
            sty.type = 'text/css';

            if (sty.styleSheet) { // IE
                sty.styleSheet.cssText = cfg.content;
            } else {
                sty.innerHTML = cfg.content;
            }
            head.appendChild(sty);
        } else if (cfg.url) {

            if (cfg.url in styleMap){return;}
            styleMap[cfg.url] = true;

        
            var link = document.createElement('link');
            link.href = cfg.url;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            head.appendChild(link);
        }
    };


    require.alias = function(id) {
        return id.replace(/\.js$/i, '');
    };

    require.timeout = 5000;


    if(lionBrowser[0]=="IE" && lionBrowser[1]<=8){
        require.loadJs('/static/common/static/js/jquery/jquery_1_11_2_min.js');
    }else{
        require.loadJs('/static/common/static/js/jquery/jquery_2_1_3_min.js');
    }

})(this);
