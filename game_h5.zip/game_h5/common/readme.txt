==============windows安装方法
1、先下载node
https://nodejs.org/download/

2、再下载java运行环境
http://www.java.com/zh_CN/download/

3、下载php安装(如果执行:php -v，有错误，执行第3步)
http://windows.php.net/download#php-5.6
	如果已经有安装php

3、第一次安装，一定要初始化server模块
fis3 server install server-env


4、测试阶段，如果要使用test数据，需要用这个命令
fis3 server start --type php --rewrite

5、开发阶段，用以下命令进行实时编译，自测数据
fis3 release -w -r home
fis3 release -w -r common

6、发布阶段，用以下命令
fis3 release qa -r common
fis3 release qa -r home

================其他
~~~~~如果要引用当前模块下的js，做依赖声明引用，一定都要在同一个模块中


================公共js变量

lion

lionData