// 获取游戏数据
define("common.static.js.gamedata", function() {
    var gamedata = {},
        exporter = {},
        events = require("common.static.js.event");
    events.eventable(exporter);

    // 获取游戏列表
    function getGames(succfn, errfn){
        $.ajax({
            url:'/static/common/static/json/gamelist.json',
            type:'get',
            cache:false,
            dataType: 'json',
            success:function( data ) {
                if (succfn) {
                    succfn(data);
                };
            },
            error:function(){ }
        });
    }
    // 获取游戏和商品类型的关系
    function getGame2GoodList(succfn, errfn){
        $.ajax({
            url:'/static/common/static/json/game2goodlist.json',
            type:'get',
            cache:false,
            dataType: 'json',
            success:function( data ) {
                var tempdata = data;
                // 对游戏和商品列表进行正排序
                tempdata.sort(function(x,y){
                    return x.gamefirstletter < y.gamefirstletter ? -1 : 1;
                });
                if (succfn) {
                    succfn(tempdata);
                };
            },
            error:function(){}
        });
    }

    // 获取数据
    getGames(function(gdata){
        gamedata.Games = gdata;
        getGame2GoodList(function(goodlistdata){
            gamedata.Game2GoodsList = goodlistdata;
            exporter.emitOnce('getgamedata', gamedata);
        });
    });
    return exporter;
});