define("common.widget.common.topnav.topnav", function() {
	//载入加密文件
	if(!$.jCryption){
	    require.loadJs('/static/common/static/js/jquery/jquery_jcryption_3_1_0.js');
	}
	// 展开个人中心弹层
	var $btn = $(".js-gb-home-btn"),
		$home = $(".js-gb-home"),
		$mark = $(".js-gb-mark");
	var isclose = true,
		animateok = true;

	function openCommonMenu(){
		isclose = false;
		animateok = false;
		$home.animate({"left":"0"},500,function(){
			animateok = true;
		});
		$mark.show();
		$mark.animate({"opacity":"1"},500);
		$(this).attr("data","2");
	}

	function closeCommonMenu(){
		isclose = true;
		animateok = false;
		$home.animate({"left":"100%"},500,function(){
			animateok = true;
		});
		$mark.animate({"opacity":"0"},500,function(){
			$mark.hide();
		});
	}
	// 点击按钮开关菜单
	$btn.on("click",function(){
		if(animateok){
			if(isclose){
				openCommonMenu();
			}else{
				closeCommonMenu();
			}
		}
	})
	// 点击空白关闭菜单
	$home.on("click",function(){
		closeCommonMenu();
	})
	// 滑动关闭菜单
	var touchstring = {
		onex : 0,
		twox : 0
	};
	document.getElementsByClassName("js-gb-home")[0].addEventListener("touchstart",function(e){
		touchstring.onex=e.touches[0].pageX;
	},false);
	document.getElementsByClassName("js-gb-home")[0].addEventListener("touchmove",function(e){
		// e.preventDefault();
		touchstring.twox=e.touches[0].pageX-touchstring.onex;
	},false);
	document.getElementsByClassName("js-gb-home")[0].addEventListener("touchend",function(e){
		// e.preventDefault();
		if(touchstring.twox>50){
			closeCommonMenu();
		}
	},false);


	//点击搜索
	var $searchBtn = $(".js-gb-search-btn"),
		$searchInput = $(".js-gb-search-input");
	

	
	$searchBtn.on("click",function(){
		var val = $.trim($searchInput.val());
		if(val!="" && val!=null){
			window.location.href="?wd="+val;
		}
	})

	// 登录返回
	var loginBtn = $(".js-use-loginbtn"),
		cururl = encodeURIComponent(document.location.href),
		gologin = $("#gb-redirectLoginUrl").val();

	if(loginBtn.length > 1){
	   loginBtn.find("a").attr("href","/siteauth/auth/login")
	}

	// 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_index_topnav");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gamecenter/index";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })
	
});
