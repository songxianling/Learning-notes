define("common.widget.common.quickmenu.quickmenu", function() {
	var $showfyBtn = $("#js-showfy"),
		$classifyMask = $("#js-classify-mask"),
		$classifyBox = $("#js-classify-box"),
		$gameListBox = $('#js-game-list');

	document.body.addEventListener('touchstart', function () { 
		//...空函数即可
		});

	$classifyBox.parents("div.box").css("overflow-x","hidden");
	var onr = true;
	var animateok = true;
	function openCommonClassify(){
		animateok = false;
		$classifyMask.show();
		$classifyBox.show();
		$classifyMask.animate({opacity:"0.5"},500);
		$classifyBox.animate({left:"0%"},500,function(){
			animateok = true;
		});
	}

	function closeCommonClassify(){
		animateok = false;
		$classifyMask.animate({opacity:"0"},500,function(){
			$classifyMask.hide();
		});
		$classifyBox.animate({left:"100%"},500,function(){
			$classifyBox.hide();
			$gameListBox.html('');
			onr = true;
			animateok = true;
		});
	}

	// 点击按钮开关游戏分类菜单
	$showfyBtn.on("click",function(){
		if(animateok){
			if(onr){
				onr = false;
				$.ajax({
					type:"get",
					url:"/com/bottom/game-category",
					async:true,
					jsonType:'json',
					data:{},
					xhrFields:{withCredentials:true},
					success:function (data) {
						var ahtml = '';
						if(data.data == "" || data.data == null){
							return;
						}
						$.each(data.data, function(index,item) {
							ahtml = '<a class="sc_game_list clearfix item item'+item.categoryid+'" data-sc="gamecenter_gamelist_category" data-sc-ocn="'+item.categoryname+'" href="/game-2-'+item.categoryid+'-2">'+
										'<div class="img"><i></i></div>'+
										'<div class="msg">'+
											'<p>'+item.categoryname+'</p>'+
											'<span>'+item.count+'款</span>'+
										'</div>'+
									'</a>'
							$gameListBox.append(ahtml);
						});
						$gameListBox.css('overflowY','auto');
					}
					
				});
			}
			if($classifyMask.is(":hidden")){
				openCommonClassify();
			}else{
				closeCommonClassify();
			}
		}
	});

	// 滑动关闭游戏分类菜单
	var touchstring = {
		onex : 0,
		twox : 0
	};
	document.getElementById("js-classify-box").addEventListener("touchstart",function(e){
		touchstring.onex=e.touches[0].pageX;
	},false);
	document.getElementById("js-classify-box").addEventListener("touchmove",function(e){
		// e.preventDefault();
		touchstring.twox=e.touches[0].pageX-touchstring.onex;
	},false);
	document.getElementById("js-classify-box").addEventListener("touchend",function(e){
		// e.preventDefault();
		if(touchstring.twox>50){
			closeCommonClassify();
		}
	},false);
	
	
	

    

});
