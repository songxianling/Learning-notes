// 首页友情链接
define("common.widget.common.friendlink.friendlink", function() {

	var $par = $("#js-friendlink-box");


	/* 友情链接统计 */
	$par.find("li").on("click","a",function(){
		var id = $(this).attr("data-id");
		$.ajax({
		    url: '/com/friendlink?id='+id,
		    type: 'get',
		    dataType : 'json',
		    async:true,
		    success: function(data) {

		    }
		}); 
	})

})
