define("common.widget.common.tuiyou.tuiyou", function() {
	var $par = $(".js-gb-box"),
		$all = $(".js-tuiyou-btn"),
		$box = $(".gb-tuiyou-mark");

	$par.delegate(".js-tuiyou-btn","click",function(){
		$box.show();
	})
	$box.on("click",function(){
		$(this).hide();
	})

});
