define('home.widget.gift.giftDetail.js.content',function(require,exports,module) {
	// 显示剩余100%
	var showNum = require("common.static.js.common");
		showNum.gameShow();

	// 领取礼包
	var url = '/gift/default/getexchangecode',
		$btn = $(".js-btn-lingqu"),
		idVal = $(".js-gift-detail-id").val(),
		ok = true,
		msg = "您已经领取过兑换码，请勿重复领取",
		cururl = encodeURIComponent(document.location.href);

	$btn.on("click",function(){

		if(ok){
			showNum.comDialog("正在领取中~");
			ok=false;
			$.ajax({
			    type:'post',
			    url:url,
			    dataType:"json",
			    data:{
			        giftid:idVal
			    },
			    success:function(data){
			    	if(data.errcode==0){
			    		var span = "<span>"+data.data.exchange_code+"</span>";
			    		$(".js-btn-lingqu-box").html("兑换码："+span+"");
			    		window.location.reload();
			    	}else if(data.errcode==100001){
			    		window.location.href=data.data.url+"returnurl="+cururl;
			    	}else{
			    		showNum.comDialog(data.msg);
			    	}
			    }
			});
		}
		
	})

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_gift_giftinfo_left");
    var $scParAd = $(".sc_gift_giftinfo_left_ad");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/giftinfo";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_gift_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/giftinfo";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })	

});
