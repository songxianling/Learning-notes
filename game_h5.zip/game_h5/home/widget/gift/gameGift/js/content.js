define('home.widget.gift.gameGift.js.content',function(require,exports,module) {

	// 加载更多
	var commonClass = require("common.static.js.common"),
		$loadbtn = $("#js-b-game-gift-load-btn"),
		$loadover = $("#js-b-game-gift-load-over"),
		$loadul = $("#js-b-game-gift-load-ul"),
		gameid = $("#js-b-game-gift-load-gameid").val(),
		imghost = $("#js-b-game-gift-load-imghost").val(),
		index = 1,
		load = true;

	commonClass.gameShow();

	$loadbtn.on("click",function(){

		if(load){
			load = false;
			index ++;
			var url = "/libao/ajaxgetdata/"+gameid+"-"+index,
				data = {};
			commonClass.newcommonAjax(url,data,loadfunc);
		}

	});

	function loadfunc(data) {
		// var data = JSON.parse(data);
		var dataArr = data.data.giftList;
		if(data.errcode == 0){
			if(data.data != "" && data.data != null){

				var html = "";

				$.each(dataArr,function(){

					html += "<li class='clearfix'>";
					html += "<div class='img'>";
					html += "<a href='/libao/"+this.spelling+"/"+this.gameid+"-"+this.id+"'>";
					html += "<img src='"+imghost+this.gift_pic+"'>";
					html += "</a>";
					html += "</div>";
					html += "<div class='msg'>";
					html += "<a href='/libao/"+this.spelling+"/"+this.gameid+"-"+this.id+"'>";
					html += "<p class='title'>"+this.gift_name+"</p>";
					html += "</a>";
					html += "<div class='stock gb-js-stock"+index+"' data-num='"+this.total_count_ratio+"'></div>";
					html += "<p class='date'>有效期："+this.start_time+"至"+this.end_time+"</p>";
					html += "</div>";
					html += "</li>";

				});

				$loadul.append(html);
				commonClass.gameShow(index);
				load = true;

				if(data.data.hasmore == 0){
					$loadbtn.hide();
					$loadover.show();
				}

			}
		}
	}

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_gift_list");
    var $scParAd = $(".sc_gift_list_ad");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/list";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parents('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_currentpage = $(this).attr('data-sc-oc')?$(this).attr('data-sc-oc'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gift/default/list";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })	

});
