define("home.widget.gift.common.stock.stock", function() {

	var $out = $(".stock-box .stock-out"),
		$in = $(".stock-box");

	$(function($){
		var $percent,
			percent,
			outWidth = $out.width(),
			inWidth;

		$in.each(function(){
			$percent = $(this).find(".stock-percent");
        	percent = parseInt($percent.text())/100;
			inWidth = outWidth*percent;
			$(this).find(".stock-in").width(inWidth);
		});
	});

});
