define('home.widget.game.gameList.js.content',function(require,exports,module) {
	var $classifyBtn = $("#js-classify");
	var $classifyMask = $("#js-classify-mask");
	var $classifyBox = $("#js-classify-box");

	$classifyBox.parents("div.box").css("overflow-x","hidden");
	var animateok = true;
	function openGamesClassify(){
		animateok = false;
		$classifyMask.show();
		$classifyBox.show();
		$classifyMask.animate({opacity:"0.5"},500);
		$classifyBox.animate({left:"0%"},500,function(){
			animateok = true;
		});
	}

	function closeGamesClassify(){
		animateok = false;
		$classifyMask.animate({opacity:"0"},500,function(){
			$classifyMask.hide();
		});
		$classifyBox.animate({left:"100%"},500,function(){
			$classifyBox.hide();
			animateok = true;
		});
	}

	// 点击按钮开关游戏分类菜单
	$classifyBtn.on("click",function(){
		if(animateok){
			if($classifyMask.is(":hidden")){
				openGamesClassify();
			}else{
				closeGamesClassify();
			}
		}
	});

	// 滑动关闭游戏分类菜单
	var touchstring = {
		onex : 0,
		twox : 0
	};
	document.getElementById("js-classify-box").addEventListener("touchstart",function(e){
		touchstring.onex=e.touches[0].pageX;
	},false);
	document.getElementById("js-classify-box").addEventListener("touchmove",function(e){
		// e.preventDefault();
		touchstring.twox=e.touches[0].pageX-touchstring.onex;
	},false);
	document.getElementById("js-classify-box").addEventListener("touchend",function(e){
		// e.preventDefault();
		if(touchstring.twox>50){
			closeGamesClassify();
		}
	},false);


	// 加载更多
	var commonClass = require("common.static.js.common"),
		$loadbtn = $("#js-b-game-list-load-btn"),
		$loadover = $("#js-b-game-list-load-over"),
		$loadul = $("#js-b-game-list-load-ul"),
		selectedOS = $("#js-b-game-list-load-os").val(),
		selectedCategoryid = $("#js-b-game-list-load-categoryid").val(),
		selectedSort = $("#js-b-game-list-load-sort").val(),
		imghost = $("#js-b-game-list-load-imghost").val(),
		index = 1,
		load = true;

	$loadbtn.on("click",function(){

		if(load){
			load = false;
			index ++;
			var url = "/game/list/api",
				data = {
					currentPage:index,
					os:selectedOS,
					categoryid:selectedCategoryid,
					sort:selectedSort
				};	
			commonClass.newcommonAjax(url,data,loadfunc);
		}

	});

	function loadfunc(data) {
		// var data = JSON.parse(data);
		var dataArr = data.data.games,
			wyId = JSON.parse($("#js-wy-id").val());
		if(data.errcode == 0){
			if(data.data != "" && data.data != null){

				var html = "",
					wyhtml = "";
				
				$.each(dataArr,function(){

					var downloadUrl,
						retrieve;

					if(this.download_url != ""){
						downloadUrl = this.download_url;
					}else{
						downloadUrl = "/com/errors/errmsg?msg=抱歉，没有当前系统可下载的安装包！";
					}
					if(this.quit_game_cashback_ratio != 0){
						retrieve = "";
					}else{
						retrieve = "hide";
					}
					if($.inArray(this.id,wyId)!= -1){
						wyhtml = "<div class='retrieve "+retrieve+"'>"+
							     "<a href='javascript:void(0)' class='js-tuiyou-btn'>"+
								 "<span class='tp'>支持</span>"+
								 "<span class='bm'>回收</span>"+
								 "</a>"+
								 "</div>"
					}else{
						wyhtml = "<div class='retrieve "+retrieve+"'>"+
						         "<a href='javascript:void(0)' class='js-tuiyou-btn'>"+
						         "<span class='tp'>回收价</span>"+
						         "<span class='bm'>"+this.quit_game_cashback_ratio+"%</span>"+
						         "</a>"+
						         "</div>"
					}

					html += "<li class='clearfix'>";
					html += "<div class='img'>";
					html += "<a href='/game/"+this.spelling+"-"+this.id+"'>";
					html += "<img src='"+imghost+this.pic+"'>";
					html += "</a>";
					html += "</div>";
					html += "<div class='msg'>";
					html += "<a href='/game/"+this.spelling+"-"+this.id+"'>";
					html += "<p class='title'>"+this.name+"</p>";
					html += "</a>";
					html += "<p class='type'>类型："+this.categoryname+"</p>";
					html += "<p class='times'>下载次数："+this.download_count+"</p>";
					html += wyhtml;
					html += "<a class='downloadbtn' href='"+downloadUrl+"'>立即下载</a>";
					html += "<span class='size'>大小："+this.size+"M</span>";
					html += "</div>";
					html += "</li>";

				});

				$loadul.append(html);
				load = true;

				if(data.data.hasmore == 0){
					$loadbtn.hide();
					$loadover.show();
				}

			}
		}
	}
	
    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scPar = $(".sc_game_list");

    $scPar.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/gamecenter/game/list";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        if($(this).attr('data-sc-opn')){
            data.opt_platforms_name = $(this).attr('data-sc-opn');
        }
        if($(this).attr('data-sc-ocn')){
            data.opt_category_name = $(this).attr('data-sc-ocn');
        }
        if($(this).attr('data-sc-osn')){
            data.opt_sort_name = $(this).attr('data-sc-osn');
        }

        comAjax.commonAjax(postUrl,data); 
    })

});
