define('home.widget.game.gameDetail.js.content',function(require,exports,module) {

	var $print = $("#js-print-box");
	var $printUl = $print.find("ul");
	var $printLi = $print.find("li");

	var marginRight = parseInt($printLi.css("margin-right"));
	var liWidth = parseInt($printLi.css("width"));
	var ulWidth = (liWidth+marginRight)*$printLi.length+marginRight;

	$printUl.css("width",ulWidth+"px");
	$printUl.css("padding-left",marginRight+"px");

	var $others = $("#js-others-box");
	var $othersUl = $others.find("ul");
	var $othersLi = $others.find("li");

	var oliWidth = parseInt($othersLi.css("width"));
	var oulWidth = oliWidth*$othersLi.length;

	$othersUl.css("width",oulWidth+"px");

    // 点击展开/收起
    var $introduce = $(".js-b-game-detail-introduce");
    var $introCont = $(".content",$introduce);
    var $introBtn = $(".btn",$introduce);
    $introduce.on("click",function(){
        if($introduce.hasClass("close")){
            $introduce.removeClass("close");
            $introBtn.find("span").text("点击收起");
        }else{
            $introduce.addClass("close");
            $introBtn.find("span").text("点击展开");
        }
    });

	//调用lightGallery插件
	$("#lightGallery").lightGallery();


    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scParOs = $(".sc_game_detail_os");
    var $scParPanel = $(".sc_game_detail_panel");
    var $scParNewGift = $(".sc_game_detail_new_gift");
    var $scParRecommend = $(".sc_game_detail_recommend");
    var $scParGameNews = $(".sc_game_detail_game_news");
    var $scParAd = $(".sc_game_detail_ad");

    $scParOs.on("click",function(){
        var postUrl = "click",
            data = {};            

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
		var ua = navigator.userAgent.toLowerCase();	
		if (/iphone|ipad|ipod/.test(ua)) {
			data.clk_name_en = "gamecenter_gamedetail_download_ios";
		} else if (/android/.test(ua)) {
			data.clk_name_en = "gamecenter_gamedetail_download_android";
		}
        data.opt_game_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParPanel.on("click",function(){
        var postUrl = "click",
            data = {};            

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
		data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_game_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParNewGift.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parents('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_gift_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParRecommend.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parents('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_game_name = $(this).attr('data-sc-ogn')?$(this).attr('data-sc-ogn'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParGameNews.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = $(this).parent('li').index()+1;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";
        data.opt_article_name = $(this).attr('data-sc-oan')?$(this).attr('data-sc-oan'):"";

        comAjax.commonAjax(postUrl,data); 
    })
    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/game/detail";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    });
    
    
    // 在微信浏览器点击下载提示层
    var $downLoad = $('#js-downLoad'),
    	$wxLayou = $('#js-wxLayou');
    	
    $downLoad.on('click',function () {
    	var ua = navigator.userAgent;
		var isWeixin = !!/MicroMessenger/i.test(ua);
		if(isWeixin){
			window.event? window.event.returnValue = false : e.preventDefault();
			$wxLayou.show();
		}else{
			$wxLayou.hide();
		}
    });
    
    $wxLayou.on('click',function () {
    	$(this).hide();
    });

});
