;define('home.widget.scoiety.js.qqcom',function  () {
	
});