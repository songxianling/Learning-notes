;define('home.widget.scoiety.js.wx',function  () {	
	
});