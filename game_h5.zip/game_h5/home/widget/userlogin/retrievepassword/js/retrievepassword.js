;define('home.widget.userlogin.retrievepassword.js.retrievepassword',function  () {	
	
	var newusercsrf = $('meta[name="csrf-token"]').attr('content');
	var pwdurl = $('#js-pwdurl').val();
	
	
	// 找回密码的接口变量
	var ptpsdgo = pwdurl+'/api/user/updatepwd', //1
		ptpsdyzp = pwdurl+'/api/user/is-show-username', //验证码手机号
		ptpsdfssms = pwdurl+'/api/sms/pwd-code', //发送验证码（短信or语音）
		ptpsdyzsms = pwdurl+'/api/sms/check-code', //验证验证码
		ptpsdimg = pwdurl+'/api/user/captcha', //图片验证码
		ptpsdyzimg = pwdurl+'/api/user/check-verify-code'; //验证码图片验证码
	
	var $repsdulone = $('#js-retpwd-onebox'), //找回密码第一个ul
		$repsduser = $('#js-retpwd-name'), //输入手机号input
		$repsdcd = $('#js-retpwd-imgc'), // 图片验证码input
		$reicd = $('#js-retrieve-imgcode'),  //放置图片验证码的盒子		
		$renop = $('#js-ret-nopho'), //没有绑定手机号要弹出的盒子		
		$repsdpcd = $('#js-retpwd-phoc'), //找回密码点击获取的手机验证码input
		$repsdnewpsdone = $('#js-retpwdnew-one'), //找回密码点击获取的新密码input
		$repsdnewpsdtwo = $('#js-retpwdnew-two'), //找回密码点击获取的新密码input	
		$repcs = $('#js-retpwd-gc-timer'),  //点了获取验证码要出现的提示info
		$renoyyb = $('#js-retpwd-nogc'), //没有收到验证码出现的语音获取的盒子
		$yygetcd = $('#js-pwd-yuyin-getcode'), //没有收到验证码出现的语音获取的盒子中的input获取按钮
		
		
		$repsdnext = $('#js-retpwd-next'),  //下一步按钮
		$repsderr = $('#js-retpwd-errbox');//错误信息的盒子
		
		
	function ajaximg() {
		$.ajax({
			url:ptpsdimg,
			data : {refresh: 1, _: Math.random() * (1e5 + 1)},
			type:'get',
			dataType :"json",
			xhrFields:{withCredentials:true},
            success : function(data){
            	$reicd.prop("src", '')
                $reicd.prop("src", pwdurl+data.url)
            },
            error:function (data) {
            	console.log('error');
            }
		});
	}  
	ajaximg();
	$('#js-getimgcode').on('click',function () {		
		ajaximg();			
	});	
	
	
	
	//帐号没有绑定手机号中的上一步刷新
	$('#js-retpwd-reload').click(function () {
		location.reload();
	});
		
	// user登录时的信息是否完整complete 
	$repsduser.on('blur',repsdinfoCom);
	$repsdcd.on('blur',repsdinfoCom);
	
	// phone登录时的信息是否完整complete 
	$repsdpcd.on('blur',repsdnewpsdinfoCom);
	$repsdnewpsdone.on('blur',repsdnewpsdinfoCom);
	$repsdnewpsdtwo.on('blur',repsdnewpsdinfoCom);

	/*
	 * ajaxretrieve 找回密码使用的post请求
	 */
	function ajaxretrieve(u,data,callback) {
		$.ajax({
                url:u,
                data : data,
                type : 'post',
                xhrFields:{withCredentials:true},
                dataType :"json",
                success : function(data){
                    callback(data);
                }
            })
	}
	
	
	var errmsg = {
		ms1:'亲,手机号不能为空',
		ms2:'亲,图片验证码不能为空',
		ms3:'亲,请输入手机验证码',
		ms4:'密码不能为空,请重新输入',
		ms5:'密码长度不能小于6位',
		ms6:'您操作太频繁,请稍候再试！',
	}
	
	var imgcodeava = false,  //图片验证码是否可用
		phocodeaca = false,  //手机验证码是否可用
		userisshow = false;  //是否有用户名inp
	/*
	 * repsdinfoCom -> 判断点击登录之前，用户填写信息的完整度
	 */
	function repsdinfoCom () {		
		if($(this).val() == ''){
			if($(this).attr('retrievepasswordtype') == 1){				
				$repsderr.find('.errorinfo').html(errmsg.ms1);					
			}else if($(this).attr('retrievepasswordtype') == 2){				
				$repsderr.find('.errorinfo').html(errmsg.ms2);				
			}
			$repsderr.show();
		}else{
			if($(this).attr('retrievepasswordtype') == 1){
				//这里放手机号用户名不为空的时候需要往后台发送的请求
				var urluser = ptpsdyzp;				
				datauser = {
					mobile:$repsduser.val()
				}
				ajaxretrieve(urluser,datauser,function (data) {
					if(data.errcode == 0){
						if(data.data.isShow){
	            			userisshow = true;
							$('#js-usershow').show();
	            		}else{
	            			$('#js-usershow').hide();
		            		userisshow = false;
	            		}
						$repsderr.find('.errorinfo').html('');
						$repsderr.hide();
					}else{
						$repsderr.find('.errorinfo').html(data.msg);
						$repsderr.show();
						
					}
				});
			}else if($(this).attr('retrievepasswordtype') == 2){
				//这里放图片验证码不为空的时候需要往后台发送的请求
				var urli = ptpsdyzimg;				
				datai = {
					picVerifyCode:$repsdcd.val()
				}
				ajaxretrieve(urli,datai,function (data) {
					if(data.errcode == 0){
						imgcodeava = true;
						$repsderr.hide();	
					}else{
						$repsderr.find('.errorinfo').html(data.msg);
						$repsderr.show();
						imgcodeava = false;
					}
				});
			}else{
				$repsderr.hide();
			}
		}		
	};
	
	/*
	 * retrievepasswordnewpasswordpage -> 找回密码新密码页面的信息完整度
	 */
	function repsdnewpsdinfoCom () {					
		if($(this).val() == ''){
			if($(this).attr('retrievepasswordtype') == 3){					
				$repsderr.find('.errorinfo').html(errmsg.ms3);					
			}else if($(this).attr('retrievepasswordtype') == 4){
				if($(this).val() == ''){
					$repsderr.find('.errorinfo').html(errmsg.ms4);
				}else{					
					$repsderr.find('.errorinfo').html(errmsg.ms4);	
				}		
			}else{				
				$repsderr.find('.errorinfo').html(errmsg.ms4);
				
			}
			
			$repsderr.show();
		}else{
			if($(this).attr('retrievepasswordtype') == 3){
				//这里放手机验证码不为空的时候需要往后台发送的请求
				var urlpc = ptpsdyzsms;
				datapc = {
					mobile:$.trim($repsduser.val()),
					smsVerifyCode:$repsdpcd.val(),
				}
				ajaxretrieve(urlpc,datapc,function (data) {
					if(data.errcode == 0){
						phocodeaca = true;
						$repsderr.hide();
					}else{
						$repsderr.find('.errorinfo').html(data.msg);
						$repsderr.show();
						phocodeaca = false;						
					}
				});				
			}else if($(this).attr('retrievepasswordtype') == 4){
				//这里mima不为空的时候需要往后台发送的请求
				if($repsdnewpsdone.val().length < 6){
					$repsderr.find('.errorinfo').html(errmsg.ms5);						
					$repsderr.show();
				}
				
			}else{
				$repsderr.hide();
			}
		}	
	};
			
	
	var repsdwait=60,//倒计时时间
		timer = null,
		$repsdgetpcd = $('#js-retrievepassword-getcode'); //点击获取的按钮
	// getcode的倒计时
	function time(o) {
        if (repsdwait == 0) {		        			                     
            o.val("点击获取");	
            o.removeClass('no-click');
            $renoyyb.show();
            clearTimeout(timer);
            repsdwait = 60;
        } else {
        	o.addClass('no-click');
            o.val(repsdwait +"s");
            repsdwait--;
            timer = setTimeout(function() {
                time(o);
            },
            1000)
        }
    };
	 //点击获取验证码的按钮操作
    $repsdgetpcd.on('click',function () {
    	if($yygetcd.hasClass('no-click')){
    		$repsderr.show();
			$repsderr.find('.errorinfo').html(errmsg.ms6);
    	}else{
    		var urlpi = ptpsdfssms;
			datapi = {
				mobile:$.trim($repsduser.val()),
				sendType:'sms'
			}
			ajaxretrieve(urlpi,datapi,function (data) {				
				if(data.errcode == 0){				
					$repcs.show();
					$repsderr.hide();
    				time($repsdgetpcd);
				}else{
					$repsderr.show();
					$repsderr.find('.errorinfo').html(data.msg);
				}				
			});
   		
    	}    	
    });    
	
	
	 $yygetcd.on('click',function () {
    	if($repsdgetpcd.hasClass('no-click')){
    		$repsderr.show();
			$repsderr.find('.errorinfo').html(errmsg.ms6);
    	}else{
    		var urlpi = ptpsdfssms;
			datapi = {
				mobile:$.trim($repsduser.val()),
				sendType:'voice'
			}
			ajaxretrieve(urlpi,datapi,function (data) {
				if(data.errcode == 0){
					$repcs.show();
    				time($yygetcd);
				}else{
					$repsderr.show();
					$repsderr.find('.errorinfo').html(data.msg);
				}
				
			});	
    		
    	}    	
    });
	
	
	/*
	 * passwordcommon 两次输入的密码是否相同
	 */
	function passwordcommon () {
		var $onepassword = $repsdnewpsdone.val(), //第一个密码的input
		    $twopassword = $repsdnewpsdtwo.val(); //第二个密码的input
		
			if($onepassword !== $twopassword){
				$repsderr.show();
				$repsderr.find('.errorinfo').html('请输入相同的密码')
			}else{
				$repsderr.hide();
			}
		
		
		
	}
	
	// 判断两次输入的密码属否相同
	$repsdnewpsdtwo.on('blur',passwordcommon);
	
	
	 // 重置成功的倒计时
    var repsdtime = 3,
    	$repsdokb = $('#js-retpwd-okbox'); //成功以后的倒计时盒子
	function repsdoktime(o) {
        if (repsdtime == 0) {
        	//这里缺少跳转用户首页的操作
        	window.location.href = '/';
            repsdtime = 3;
        } else {
            o.val(repsdtime +"秒后自动跳至首页");
            repsdtime--;
            setTimeout(function() {
                repsdoktime(o);
            },
            1000)
        }
    };
    
    
    
    // 点击下一步按钮
	$repsdnext.on('click',function () {
		if($repsduser.val() == ''){
			$repsderr.find('.errorinfo').html(errmsg.ms1);	
			$repsderr.show();
		}else if($repsdcd.val() == ''){
			$repsderr.find('.errorinfo').html(errmsg.ms2);	
			$repsderr.show();
		}else if(!imgcodeava){
			$repsdcd.blur();
		}else if($repsdpcd.val() == ''){
			$repsderr.find('.errorinfo').html(errmsg.ms3);	
			$repsderr.show();
		}else if($repsdnewpsdone.val() == ''){
			$repsderr.find('.errorinfo').html(errmsg.ms4);	
			$repsderr.show();
		}else if($repsdnewpsdtwo.val() == ''){
			$repsderr.find('.errorinfo').html(errmsg.ms4);	
			$repsderr.show();
		}else if($repsdnewpsdtwo.val() !== $repsdnewpsdone.val()){
			$repsderr.find('.errorinfo').html('亲,请输入相同的密码');	
			$repsderr.show();
		}else if(!phocodeaca){
			$repsdpcd.blur();
		}else{
			var urli = ptpsdyzsms;
			datai = {
				mobile:$repsduser.val(),
				smsVerifyCode:$repsdpcd.val()
			}
			ajaxretrieve(urli,datai,function (data) {
				if(data.errcode !== 0){
					$repsderr.find('.errorinfo').html(data.msg);
					$repsderr.show();
				}else{
					if(data.data.mobile == ''){
						$repsdulone.hide();
						$repsdnext.hide();
						$renop.show();
					}else{
						var urlok = ptpsdgo;
							dataok = {
								mobile:$repsduser.val(),
								password:$repsdnewpsdone.val(),
								passwordAgain:$repsdnewpsdtwo.val(),
								smsVerifyCode:$repsdpcd.val()
							};
						if(userisshow){
							dataok.userName = $('#js-repsd-userdb').val();
						}
						ajaxretrieve(urlok,dataok,function (data) {								
							if(data.errcode == 0){
								$repsdnext.addClass('no-click');
								$repsdokb.show();
								repsdoktime($('#js-retpwd-ok'));
							}else{
								$repsdnext.removeClass('no-click');
								$repsderr.find('.errorinfo').html(data.errmsg);
								$repsderr.show();							
							}
						});
					}							
				}
			});					
		}					
	});
	
});