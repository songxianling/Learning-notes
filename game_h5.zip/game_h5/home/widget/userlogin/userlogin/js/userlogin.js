;define('home.widget.userlogin.userlogin.js.userlogin',function  () {	

	var loginurl = $('#js-loginurl').val();
	
	// 登录接口变量
	var $lgimg = loginurl+'/api/user/captcha',
		$lgsms = loginurl+'/api/user/user-send-code',
		$showimg = loginurl+'/api/user/judge-view-code',
		$lgshowdx = loginurl+'/api/user/check-mobile',
		$lggo = loginurl+'/api/user/login';
		
	var $username = $('#js-user-name'), //用户名input
		$userpsd = $('#js-user-password'), //密码input
		$usercd = $('#js-user-code'), //请输入验证码input
		$userpsdb = $('#js-user li').eq(1),
		$usercdb = $('#js-user li').eq(2),  //输入验证码的盒子tab1.默认是隐藏的
		$usericd = $('.js-loginimgcode'),  //放置图片验证码的盒子img
		$usersmsb = $('#js-user li').eq(3),
		$usersmscode = $('#js-user-phonecode'),
		
		$pinfo = $('#js-user-pinfob'),
		
		$loginsure = $('#js-user-sure'),  //登录按钮
		$usererr = $('#js-user-errbox');//错误信息的盒子
	
	function ajaxlogin(u,data,callback) {
		$.ajax({
                url:u,
                data : data,
                type : 'post',
                xhrFields:{withCredentials:true},
                dataType :"json",
                success : function(data){
                    callback(data);
                }
            })
	};
	
	var errmsg = {
		ms1:'请输入用户名',
		ms2:'请输入登录密码',
		ms3:'请输入验证码',
		ms4:'请输入手机验证码',
		ms5:'亲,您不是在常用的地方登录哦,请确保账号安全',
	}
	
	function timereset(data){
        var theTime = parseInt(data);//秒
        var theTime1 = 0;//分
        var theTime2 = 0;//时
        if(theTime>60){
            theTime1 = parseInt(theTime/60);
            theTime = parseInt(theTime%60);
            if(theTime1>60){
                theTime2 = parseInt(theTime1/60);
                theTime1 = parseInt(theTime1%60);
            }
        }
        var result = ""+parseInt(theTime)+"秒";
        if(theTime1>0){
            result=""+parseInt(theTime1)+"分"+result;
        }
        if(theTime2>0){
            result=""+parseInt(theTime2)+"时"+result;
        }
        return result;
    }
	
	/*
	 * lgimgshow  加载图片验证码
	 * ele  ->  jquery  ele
	 */
	function lgimgshow(ele) {
		$.ajax({
			url:$lgimg,
			data : {refresh: 1, _: Math.random() * (1e5 + 1)},
			type:'get',
			xhrFields:{withCredentials:true},
			dataType :"json",
            success : function(data){
            	ele.prop("src", loginurl+data.url)
              }
		});	
	}
	
	
	
	$('.js-checkimgcode').on('click',function () {			
		lgimgshow($usericd);			
	});
	
	var mmORsms = true;
	
	$username.on('blur',function () {
		clearInterval(timer);
		$getphc.val("点击获取");	
        $getphc.removeClass('no-click');
        wait = 60;
		var _this = $(this);
		if(_this.val() !== ""){
			var urla = $lgshowdx,
				dataa = {userName:$.trim(_this.val())};
			ajaxlogin(urla,dataa,function (data) {
				if(data.errcode == 0){
	            	$usererr.hide();
	            	if(data.data.ischeck == 1){
	            		$usererr.find('.errorinfo').html(errmsg.ms5);
						$usererr.show();
//	            		$('#js-smsshow').show();
	            		$userpsdb.hide();
	            		mmORsms = false;
	            		$usersmsb.show();
	            		$pinfo.show();
	            		$pinfo.find('span').html(data.data.mobile);
	            	}else{
	            		$userpsdb.show();
	            		mmORsms = true;
	            		$usersmsb.hide();
	            		$pinfo.hide();
	            	}
	            }else{
	            	$usererr.find('.errorinfo').html(data.msg);
					$usererr.show();
					$pinfo.hide();
					$userpsdb.show();
					$usersmsb.hide();
					mmORsms = true;
	            }
			});	
		}else{
			$usererr.find('.errorinfo').html(errmsg.ms1);
			$usererr.show();
		}
	});
	
	//获取手机验证码
	var $getphc = $('.js-usc'),
		timer,
		wait = 60;
	
	function time(o) {
        if (wait == 0) {		        			                     
            o.val("点击获取");	
            o.removeClass('no-click');
            clearTimeout(timer);
            wait = 60;
        } else {
        	o.addClass('no-click');
            o.val(wait +"s");
            wait--;
            timer = setTimeout(function() {
                time(o);
            },
            1000)
        }
    };
	
	
	$getphc.on('click',function () {	
		var urlphc = $lgsms,
			dataphc = {
				userName:$.trim($username.val())
			};
		ajaxlogin(urlphc,dataphc,function (data) {
			if(data.errcode == 0){
				$usererr.hide();
				time($getphc);
			}else{
				$usererr.find('.errorinfo').html(data.msg);
				$usererr.show();
			}
		});
		
	});
	var hasimgcodebox = false; //是否有图片验证码

	
	 // 刷新页面是否显示验证码
    isShowyan();
    function isShowyan(){
    	$.ajax({
    	    url : $showimg,
    	    type : 'get',
    	    cache : false,
    	    dataType : 'json',
    	    xhrFields:{withCredentials:true},
    	    success:function(data) {
    	        if (data.errcode == 0) {
    	            if (data.data.errorNum > 2) {
    	            	$usercdb.show();
//						$pcdb.show();
						hasimgcodebox = true;
    	            	lgimgshow($usericd);

    	            };
    	        }
    	    }
    	});
    }


	
	var comJs = require('common.static.js.common'),
		ourl = comJs.getRequest().returnurl;
			
	var IPtime = null;		
	// 点击登录按钮
	$loginsure.on('click',function () {														
		if($username.val() == ''){
			$usererr.find('.errorinfo').html(errmsg.ms1);
			$usererr.show();
		}else if($userpsd.val() == '' && mmORsms){
			$usererr.find('.errorinfo').html(errmsg.ms2);
			$usererr.show();
		}else if($usercd.val() == '' && hasimgcodebox){						
			$usererr.find('.errorinfo').html(errmsg.ms3);
			$usererr.show();
		}else if($usersmscode.val() == '' && !mmORsms){						
			$usererr.find('.errorinfo').html(errmsg.ms4);
			$usererr.show();
		}else{
			//这里放置三个都不为空往后台传输的数据
			var urluser = $lggo;			
			datauser = {
				userName:$username.val()
			}
			if(hasimgcodebox){
				datauser.picVerifyCode = $usercd.val()
			}
			
			if(mmORsms){
				datauser.password  = $.trim($userpsd.val()); 
			}else{
				datauser.smsVerifyCode  = $.trim($usersmscode.val());
			}
			
			ajaxlogin(urluser,datauser,function (data) {
				if(data.errcode == 101092){
					clearInterval(IPtime);
					var time = data.data.time;
					$usererr.find('.errorinfo').html(data.msg+timereset(time)+'后登录');
					$usererr.show();
					IPtime = setInterval(function () {
						if(time <= 0){
							clearInterval(IPtime);
							$usererr.hide();
						}else{
							time --;
							$usererr.find('.errorinfo').html(data.msg+timereset(time)+'后登录');
						}	
					},1000);
				}else if(data.errcode){
					//有错误的时候
					$usererr.find('.errorinfo').html(data.msg);
					$usererr.show();					
					isShowyan();
											
				}else{
					//没有错误跳转
					window.location.href = ourl ? ourl : '/';
				}
			});				
		}
	});
	
	//神策统计
	var comAjax = require("common.static.js.common");
	$loginsure.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   
   $('#js-qq-loginbtn').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = loginurl+"/api/qq/login?type=3";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_qq_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   $('#js-wx-loginbtn').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = loginurl+"/api/wechat/login?redirect_type=3";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_wechat_btn";

        comAjax.commonAjax(postUrl,data); 
   });
    $('#sc-newre').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "/siteauth/auth/register";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_register_btn";

        comAjax.commonAjax(postUrl,data); 
   });
    $('#sc-rvpwd').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "/siteauth/auth/retrieve";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_retrieve_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   $('#sc-phoyan').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = "";
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_smscode_btn";

        comAjax.commonAjax(postUrl,data); 
   });
   $('#sc-ad').on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/siteauth/auth/login";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";;
        data.clk_item_index = 0;
        data.clk_name_en = "website_login_ad";

        comAjax.commonAjax(postUrl,data); 
   });
		    

});