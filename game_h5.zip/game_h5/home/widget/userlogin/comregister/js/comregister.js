;define('home.widget.userlogin.comregister.js.comregister',function  () {	
	var qqcsrf = $('meta[name="csrf-token"]').attr('content');
	
	// qqregister 接口变量
	var curl = $('#js-regurl').val(),
		disantype = $('#js-type').val();
	
	
	var comgo = curl+'/api/qq/register',
		comsms = curl+'/api/sms/reg-code',
		comimg = curl+'/api/user/captcha', //图片验证码
		comyzimg = curl+'/api/user/check-verify-code'; //验证码图片验证码
		comyzsms = curl+'/api/sms/check-code'; //验证验证码
	
	if(disantype == 1){
		comgo = curl+'/api/qq/register';
	}else if(disantype == 2){
		//微信注册提交url
		comgo = curl+'/api/wechat/register';
	}
		
	// 获取验证码的倒计时
	var wait=60,
		$newpho = $('.js-newphone'),  //填写手机号的input
		$newpwd1 = $('.js-newpwd1'),  //登录密码input
		$newpwd2 = $('.js-newpwd2'),  //登录密码input2
		$newimgcode = $('.js-newimgcode'),  //图片验证码input
		$newphocode = $('.js-newphocode'),  //手机验证码input		
		$newgp = $('.js-newgetpho'),  //手机验证码的按钮
		$newgpYuyin = $('#js-getphocode-yuyin'), //语音手机验证码的按钮
		$newnocode = $('.no-getphocode'),  //没有收到短信验证码
		$newerrbox = $('.js-newerr'), //错误信息的盒子
		
		
		$oldpho = $('.js-oldpho'),  //old 手机号input
		$oldpwd = $('.js-oldpwd'),  //old 密码input
		$oldimgcode = $('.js-oldimgcode'),  //old 图片验证码input
		$olderrbox = $('.js-olderr'), //错误信息的盒子
		
		$comgi = $('.js-getimg'),  //图片验证码的img
		
		$qqrcdbox = $('#js-reg-gc-timer'), //点击获取验证码按钮出现的提醒box
		$qqrnocode = $('#js-reg-nogc'), //没有收到短信验证码
		
		$qqruser = $('#js-qqregister-pwd1'),  //密码的盒子 
		$qqrsure = $('#js-reg-sure'),  // 确定按钮
		$qqrxyic = $('#js-reg-xieyi-icon'), //协议前的icon
		$qqrokb = $('#js-reg-okbox');  //成功确定以后要弹出的盒子
		
	
	/*
	 * comreajax 注册使用的post请求
	 */
	function comreajax(u,data,callback) {
		$.ajax({
                url:u,
                data : data,
                type : 'post',
                xhrFields:{withCredentials:true},
                dataType :"json",
                success : function(data){
                    callback(data);
                }
            })
	}
	
	
	//sele切换
	var $seleli = $('.selebox li'),
		$selebox = $('.list'),
		newuser = true;
	$seleli.on('click',function () {
		$(this).addClass('sele').siblings().removeClass('sele')
		$selebox.eq($(this).index()).show().siblings().hide();
		$(this).index() == 0?newuser = true:newuser = false;
		$(this).index() == 0?$('.reg-xieyi').show():$('.reg-xieyi').hide();
	});	
	
	// 图形验证码
	VerifyImg($comgi);
	function VerifyImg(obj){
		$.ajax({
			url:comimg,
			data : {refresh: 1, _: Math.random() * (1e5 + 1)},
			type:'get',
			xhrFields:{withCredentials:true},
			dataType :"json",
            success : function(data){
            	obj.prop("src", curl+data.url)             
            }			
		});
	}
	$comgi.on("click",function(){
		VerifyImg($comgi);
	})
	//手机号input的正则判断操作
	var qqPhotoYoN = false;
//  $qqrpinp.on('blur',photoblur);    
    function photoblur () {   	
    	var reg1 = /^1[34578][0-9]{9}$/;
    	if(!reg1.test($newpho.val())){
    		$newerrbox.find('.errorinfo').html('请输入正确的手机号');
    		qqPhotoYoN = false;
    		$newerrbox.show();
//  		return;
    	}else{
    		qqPhotoYoN = true;
    		$newerrbox.hide();
    	}
    }
    
    
    var errmsg = {
    	em1:'亲,手机号不能为空',
    	em2:'亲,图片验证码不能为空',
    	em3:'亲,手机验证码不能为空',
    	em4:'密码不能为空',
    	em5:'密码长度不能小于6位',
    	em6:'两次密码要保持一致',
    	em7:'帐号/手机号不能为空',
    	em8:'请输入登录密码',
    	em9:'请再次输入登录密码',
    	em10:'亲,请同意用户协议',
    	em11:'亲,请输入正确的手机验证码',
    	em12:'亲,请输入正确的图片验证码',
    	
    }
    var $inpAll = $('input'),
    	smsava = false,
    	newimgava = false,
    	oldimgava = false;
    
	$inpAll.on('input',infoCom);
	
	/*
	 * input失去焦点判断
	 */
	function infoCom () {
		var _this = $(this);
		if(_this.attr('cominptype') == 1){
			if(_this.val() == ''){					
				$newerrbox.find('.errorinfo').html(errmsg.em1);				
				$newerrbox.show();			
			}else{
				$newpho.on('blur',photoblur);
			}
		}		
		if(_this.attr('cominptype') == 2){
			if(_this.val() == ''){				
				$newerrbox.find('.errorinfo').html(errmsg.em2);				
				$newerrbox.show();			
			}else{
				// 图片验证码不为空的操作
				var newimgdata = {
					picVerifyCode:$.trim(_this.val())
				};
				comreajax(comyzimg,newimgdata,function (data) {
					if(data.errcode == 0){
						$newerrbox.hide();
						newimgava = true;
					}else{
						$newerrbox.find('.errorinfo').html(data.msg);
						$newerrbox.show();
						newimgava = false;
					}
				});
			}
		}	
		if(_this.attr('cominptype') == 3){
			if(_this.val() == ''){				
				$newerrbox.find('.errorinfo').html(errmsg.em3);				
				$newerrbox.show();			
			}else{
				// 手机验证码不为空的操作
				var newsdata = {
					mobile:$.trim($newpho.val()),
					smsVerifyCode:$.trim(_this.val())
				};
				comreajax(comyzsms,newsdata,function (data) {
					if(data.errcode == 0){
						$newerrbox.hide();
						smsava = true;
					}else{
						$newerrbox.find('.errorinfo').html(data.msg);
						$newerrbox.show();
						smsava = false;
					}
				});
			}
		}		
		if(_this.attr('cominptype') == 4){
			if(_this.val() == ''){					
				$newerrbox.find('.errorinfo').html(errmsg.em4);				
				$newerrbox.show();			
			}else if(_this.val().length < 6){
				$newerrbox.show();
				$newerrbox.find('.errorinfo').html(errmsg.em5);
			}else if(_this.val() != $(".js-newpwd2").val()){
				$newerrbox.show();
				$newerrbox.find('.errorinfo').html(errmsg.em6);
			}else{
				$newerrbox.hide();
				$newerrbox.find('.errorinfo').html("");
			}
		}			
		if(_this.attr('cominptype') == 5){
			if(_this.val() == ''){
				
				$newerrbox.find('.errorinfo').html(errmsg.em4);				
				$newerrbox.show();			
			}else if(_this.val().length < 6){
				$newerrbox.show();
				$newerrbox.find('.errorinfo').html(errmsg.em5);
			}else if(_this.val() != $(".js-newpwd1").val()){
				$newerrbox.show();
				$newerrbox.find('.errorinfo').html(errmsg.em6);
			}else{
				$newerrbox.hide();
				$newerrbox.find('.errorinfo').html("");
			}
		}		
		if(_this.attr('cominptype') == 6){
			if(_this.val() == ''){				
				$newerrbox.find('.errorinfo').html(errmsg.em7);				
				$newerrbox.show();			
			}else{
				// 帐号/手机号不为空的ajax
				
				$newerrbox.hide();
				$newerrbox.find('.errorinfo').html("");
			}
		}
		
		
		
		if(_this.attr('cominptype') == 7){
			if(_this.val() == ''){				
				$newerrbox.find('.errorinfo').html(errmsg.em4);				
				$newerrbox.show();			
			}else if(_this.val().length < 6){
				$newerrbox.show();
				$newerrbox.find('.errorinfo').html(errmsg.em5);
			}else{
				$newerrbox.hide();
				$newerrbox.find('.errorinfo').html("");
			}
		}
		
		
		if(_this.attr('cominptype') == 8){
			if(_this.val() == ''){				
				$newerrbox.find('.errorinfo').html(errmsg.em2);				
				$newerrbox.show();			
			}else{
				// old 图片验证码不为空的操作
				var oldidata = {
					picVerifyCode:$.trim(_this.val())
				};
				comreajax(comyzimg,oldidata,function (data) {
					if(data.errcode == 0){
						$newerrbox.hide();
						oldimgava = true;
					}else{
						$newerrbox.find('.errorinfo').html(data.msg);
						$newerrbox.show();
						oldimgava = false;
					}
				});
			}
		}
		
	};
	
			
		
//	//用户昵称的判断限制
//	var qqrusava = false;
//	$qqruser.on('blur',function () {		
//		var usreg = /^[0-9a-zA-Z\u4e00-\u9fa5_]{4,20}$/;
//		if(!usreg.test($(this).val())){
//			$newerrbox.find('.errorinfo').html('4-20个字符之间(数字、字母、汉字、下划线和圆点)');
//  		$newerrbox.show();
//  		qqrusava = false;
//		}else{			
//			qqrusava = true;
//			$newerrbox.hide();
//		}
//	});	

			
	// getcode的倒计时
	function time(o) {
        if (wait == 0) {		        			                     
            o.val("点击获取");	
            o.removeClass('no-click');
            $qqrnocode.show();
            wait = 60;
        } else {
        	o.addClass('no-click');
            o.val(wait +"s");
            wait--;
            setTimeout(function() {
                time(o);
            },
            1000)
        }
    };
		    
    // 成功page的倒计时
    var qqrokwait = 3,
    	$qqroktmb = $('#js-qqregister-ok'); //成功以后的倒计时盒子里面的input
	function qqroktime(o) {
        if (qqrokwait == 0) {
        	window.location.href = '/';
            qqrokwait = 3;
        } else {		        	
            o.val(qqrokwait +"秒后自动跳至首页");
            qqrokwait--;
            setTimeout(function() {
                qqroktime(o);
            },
            1000)
        }
    };
		    
		    
    //点击获取验证码的按钮操作
    $newgp.on('click',function () {
    	if(!$newgpYuyin.hasClass('no-click')){
    		
	    	if(qqPhotoYoN){
	    		if(!newimgava){
	    			$newerrbox.show();
					$newerrbox.find('.errorinfo').html('请输入正确的图片验证码');
					return;
	    		}
	    		var _data = {
					mobile:$newpho.val(),
					sendType:'sms'
				}
				comreajax(comsms,_data,function (data) {
					if(data.errcode == 0){				
						$qqrcdbox.show();
	    				time($newgp);
					}else{
						$qqrcdbox.hide();
						$newerrbox.show();
						$newerrbox.find('.errorinfo').html(data.msg);
					}				
				});
	    	}else{
	    		
	    		$newpho.blur();
	    	} 
	    }else{
    		$newerrbox.show();
			$newerrbox.find('.errorinfo').html('您的操作频繁,请稍后再试');
    	}
    });
    
    //点击获取语音验证码的按钮操作
    $newgpYuyin.on('click',function () {
    	if(!$newgp.hasClass('no-click')){
    		if(qqPhotoYoN){    		
				dataqqry = {
					mobile:$newpho.val(),
					sendType:'voice'
				}
				comreajax(comsms,dataqqry,function (data) {
					if(data.errcode == 0){				
						$qqrcdbox.show();
	    				time($newgpYuyin);
					}else{
						$newerrbox.show();
						$newerrbox.find('.errorinfo').html(data.msg);
					}				
				});
	    	}else{
	    		$newpho.blur();
	    	} 	
    	}else{
    		$newerrbox.show();
			$newerrbox.find('.errorinfo').html('您的操作频繁,请稍后再试');
    	}
	    	   	
    });	              
    
    // 协议同意操作
    $qqrxyic.on('click',function () {
    	if($(this).hasClass('no')){		    		
    		$(this).removeClass('no');
    		$newerrbox.hide();
    		return;
    	}
    	$(this).addClass('no');
    });
    
    
    function timereset(data){
        var theTime = parseInt(data);//秒
        var theTime1 = 0;//分
        var theTime2 = 0;//时
        if(theTime>60){
            theTime1 = parseInt(theTime/60);
            theTime = parseInt(theTime%60);
            if(theTime1>60){
                theTime2 = parseInt(theTime1/60);
                theTime1 = parseInt(theTime1%60);
            }
        }
        var result = ""+parseInt(theTime)+"秒";
        if(theTime1>0){
            result=""+parseInt(theTime1)+"分"+result;
        }
        if(theTime2>0){
            result=""+parseInt(theTime2)+"时"+result;
        }
        return result;
    }
    
    
    //点击确定的操作    
    var comIPtime = null;
    $qqrsure.on('click',function () {
    	if(newuser){
    		// 新用户
    		if(!qqPhotoYoN){
    			$newpho.blur();
    		}else if($newpwd1.val() ==''){
	    		$newerrbox.find('.errorinfo').html(errmsg.em8);
	    		$newerrbox.show();
	    	}else if($newpwd2.val() == ''){
	    		$newerrbox.find('.errorinfo').html(errmsg.em9);
	    		$newerrbox.show();
	    	}else if($qqrxyic.hasClass('no')){
	    		$newerrbox.find('.errorinfo').html(errmsg.em10);
	    		$newerrbox.show();
	    	}else if(!smsava){
	    		$newerrbox.find('.errorinfo').html(errmsg.em11);
	    		$newerrbox.show();
	    	}else if(!newimgava){
	    		$newerrbox.find('.errorinfo').html(errmsg.em12);
	    		$newerrbox.show();
	    	}else{
	    		//这时候可以确定提交了
				dataok = {
					mobile:$newpho.val(),
					openid:$('#js-qqr-openid').val(),
					nickname:$('#js-qqr-nickname').val(),
					userpic:$('#js-qqr-userpic').val(),
					gender:$('#js-qqr-gender').val(),
					unionid:$('#js-unionid').val(),
					smsVerifyCode:$newphocode.val(),
					password:$('#js-qqregister-pwd1').val(),
					passwordAgain:$('#js-qqregister-pwd2').val(),
					regsource:5,
					type:1
				}
				comreajax(comgo,dataok,function (data) {
					if(data.errcode == 0){
						$qqrsure.addClass('no-click');
						$newerrbox.hide();
						$qqrokb.show();
						qqroktime($qqroktmb);
					}else{
						$qqrsure.removeClass('no-click');
						$newerrbox.show();
						$newerrbox.find('.errorinfo').html(data.msg);
					}				
				});
	    	}
    	}else{
    		//已有淘手游帐号
    		if($oldpho.val() ==''){
	    		$olderrbox.find('.errorinfo').html('请输入帐号/手机号');
	    		$olderrbox.show();
	    	}else if($oldpwd.val() == ''){
	    		$olderrbox.find('.errorinfo').html('请输入登录密码');
	    		$olderrbox.show();
	    	}else if($oldimgcode.val() == ''){
	    		$olderrbox.find('.errorinfo').html('请输入图片验证码');
	    		$olderrbox.show();
	    	}else if(!oldimgava){
	    		$olderrbox.find('.errorinfo').html('亲,请输入正确的图片验证码');
	    		$olderrbox.show();
	    	}else{
	    		//这时候可以确定提交了
				olddataok = {
					mobile:$oldpho.val(),
					openid:$('#js-qqr-openid').val(),
					userpic:$("#js-userpic").val(),
			    	nickname:$("#js-nickname").val(),
			    	unionid:$('#js-unionid').val(),
					password:$oldpwd.val(),
					type:2
				}
				comreajax(comgo,olddataok,function (data) {
					if(data.errcode == 101092){
						clearInterval(comIPtime);
						var time = data.data.time;
						$olderrbox.find('.errorinfo').html(data.msg+timereset(time)+'后操作');
						$olderrbox.show();
						comIPtime = setInterval(function () {
							if(time <= 0){
								clearInterval(comIPtime);
								$olderrbox.hide();
							}else{
								time --;
								$olderrbox.find('.errorinfo').html(data.msg+timereset(time)+'后操作');
							}	
						},1000)
					}else if(data.errcode == 0){
						$qqrsure.addClass('no-click');
						$olderrbox.hide();
						$('#js-zcok').hide();
						$('#js-bdok').show();
						$qqrokb.show();
						qqroktime($qqroktmb);
					}else{
						$qqrsure.removeClass('no-click');
						$olderrbox.show();
						$olderrbox.find('.errorinfo').html(data.msg);
					}				
				});
	    	}
    	}   	
    });
});