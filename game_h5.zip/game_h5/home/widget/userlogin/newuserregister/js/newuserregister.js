;define('home.widget.userlogin.newuserregister.js.newuserregister',function  () {
	var newusercsrf = $('meta[name="csrf-token"]').attr('content');
	
	var newurl = $('#js-newurl').val();
	
	
	// 新用户接口变量
	var portgo = newurl+'/api/user/register', //总接口
		portyzp = newurl+'/api/sms/check-mobile', //验证码手机号
		portfssms = newurl+'/api/sms/reg-code', //发送验证码（短信or语音）
		portyzsms = newurl+'/api/sms/check-code', //验证验证码
		portimg = newurl+'/api/user/captcha', //图片验证码
		portyzimg = newurl+'/api/user/check-verify-code'; //验证码图片验证码
	
	
	
	
	
	var $imgcodebox = $('#js-newuserrigister-imgbox');	// 要放置新图片的盒子	
	function ajaximgnew () {
		$.ajax({
			url:portimg,
			data : {refresh: 1, _: Math.random() * (1e5 + 1)},
			type:'get',
			dataType :"json",
			xhrFields:{withCredentials:true},
            success : function(data){
            	$imgcodebox.prop("src", '');
                $imgcodebox.prop("src", newurl+data.url);
            },
            error:function (data) {
            	console.log('error');
            }
		});
	}
	ajaximgnew ();
	$('#js-imgcode-eee').on('click',function () {		
		ajaximgnew();		
	});
		
	
	/*
	 * ajaxinfoava  信息是否可用
	 */
	function ajaxinfoava(u,data,callback){
            $.ajax({
                url:u,
                data : data,
                type : 'post',
                xhrFields:{withCredentials:true},
                dataType :"json",
                success : function(data){
                    callback(data);
                }
            })
        }
	
	
	
	
	var $newrpi = $('#js-newreg-phoinp'), //手机号input
		$newrpicd = $('#js-newreg-pcinp'), //手机验证码input	
		$newrpiccd = $('#js-newreg-icinp'), //图片验证码input	
		
		$newrpsdone = $('#js-newreg-psd-one'), //新密码one
		$newrpsdtwo = $('#js-newreg-psd-two'), //新密码two
		
		$newrnext = $('#js-newreg-next'),  //下一步按钮
		$newrerr = $('#js-newreg-errbox');//错误信息的盒子
		
	
	//手机号input的正则判断操作
	var photoYoN = 0;
    $newrpi.on('blur',newpava);	
    
    function newpava () {    	
    	var reg1 = /^1[34578][0-9]{9}$/;
    	if(!reg1.test($newrpi.val())){   		
    		$newrerr.find('.errorinfo').html('请输入正确的手机号');
    		$newrerr.show();
    		photoYoN = 0;   		
    		return;
    	}else{
    		photoYoN = 1;
    		$newrerr.hide();
    	}
    }
    
		
	var imgcodeava = 0,
		newphoava = false; //手机号是否存在可用，点击获取验证码之前的操作
		
		
	// 第一个UL的信息是否完整complete 
	$newrpi.on('blur',newrinfoCom);
	$newrpiccd.on('blur',newrinfoCom);
	$newrpicd.on('blur',newrinfoCom);
	
	
	// 第二个UL的信息是否完整complete 
	$newrpsdone.on('blur',newrpsdinfoCom);
	$newrpsdtwo.on('blur',newrpsdinfoCom);
	
	
	var errmsg = {
		ms1:'手机号不能为空',
		ms2:'图片验证码不能为空',
		ms3:'手机验证码不能为空',
		ms4:'用户名不能为空',
		ms5:'密码不能为空',
		ms6:'请输入相同的密码',
		ms7:'密码长度不能少于6位！',
	}
	
	
	// 这里存放的变量是为了判断input规则的
	var photoC = 0;
		photocode = 0;
	
	/*
	 * newrinfoCom -> 判断点击登录之前，用户填写信息的完整度
	 */
	function newrinfoCom () {		
		if($(this).val() == ''){
			if($(this).attr('newtype') == 1){
				$newrerr.find('.errorinfo').html(errmsg.ms1);	
			}else if($(this).attr('newtype') == 2){				
				$newrerr.find('.errorinfo').html(errmsg.ms2);				
			}else{
				$newrerr.find('.errorinfo').html(errmsg.ms3);				
			}
			$newrerr.show();
		}else{
			if($(this).attr('newtype') == 1){				
				//这里放手机号不为空的时候需要往后台发送的请求
				if(photoYoN == 1){
					var urlone = portyzp,
					dataone = {
						mobile:$(this).val()*1
					}					
					ajaxinfoava(urlone,dataone,function(data) {
						if(data.errcode == 0){
							newphoava = true;
							photoC = 1;
							$newrerr.hide();
						}else{
							var msg = data.msg;
							$newrerr.find('.errorinfo').html(msg);
							$newrerr.show();
							newphoava = false;
							photoC = 0;
							
						}
					})	
				}					
				$newrpi.on('blur',newpava);			
			}else if($(this).attr('newtype') == 2){
				//这里放图片验证码不为空的时候需要往后台发送的请求
				
				var urltwo = portyzimg,
					datatwo = {						
						picVerifyCode:$.trim($(this).val())
					}
					
				ajaxinfoava(urltwo,datatwo,function(data) {
					if(data.errcode == 0){						
						$newrerr.hide();
						imgcodeava = 1;
					}else{
						imgcodeava = 0;
						$newrerr.find('.errorinfo').html(data.msg);
						$newrerr.show();
						
					}
				})
			
			}else if($(this).attr('newtype') == 3){
				//这里放手机验证码不为空的时候需要往后台发送的请求
				
				var urlthree = portyzsms,
					datathree = {
						mobile:$newrpi.val()*1,
						smsVerifyCode:$(this).val()
					}
					
				ajaxinfoava(urlthree,datathree,function(data) {
					if(data.errcode == 0){
						photocode = 1;
						$newrerr.hide();						
					}else{
						photocode = 0;
						var msg = data.msg;
						$newrerr.find('.errorinfo').html(msg);
						$newrerr.show();
					}
				})
			
			}else{
				
				$newrerr.hide();
			}

		}		
	};
	
	var userC = 0;
	
	/*
	 * newuserrigisternewpasswordpage -> 找回密码新密码页面的信息完整度
	 */
	function newrpsdinfoCom () {					
			if($(this).val() == ''){
				if($(this).attr('newtype') == 4){
					$newrerr.find('.errorinfo').html(errmsg.ms4);				
				}else if($(this).attr('newtype') == 5){
					$newrerr.find('.errorinfo').html(errmsg.ms5);				
				}else{
					$newrerr.find('.errorinfo').html(errmsg.ms6);				
				}
				$newrerr.show();			
			}else{				
				if($(this).attr('newtype') == 5){
					if($(this).val().length <6){						
						$newrerr.find('.errorinfo').html(errmsg.ms7);
						$newrerr.show();
					}
				}
				
			}	
	};
			
	
	
	var newrwait=60,  //倒计时时间
		timer,
		$newrgetcdt = $('#js-newreg-gc-timer'), //点了获取验证码出现的10分钟remind
		$newrnocdb = $('#js-newreg-nogc'),  //点了获取60s结束后显示的盒子
		$newrgetpcd = $('#js-newreg-gc'), //点击获取的按钮
		$yuyincd = $('#js-yuyin-getcode');  //语音点击获取的按钮
	// getcode的倒计时
	function time(o) {
        if (newrwait == 0) {		        			                     
            o.val("点击获取");	
            o.removeClass('no-click');
            $newrnocdb.show();
			clearTimeout(timer);
            newrwait = 60;
        } else {
        	o.addClass('no-click');
            o.val(newrwait +"s");
            newrwait--;
            timer = setTimeout(function() {
                time(o);
            },
            1000)
        }
    };
    
    
    var dxoryy = 0;
    
    
	 //点击获取验证码的按钮操作
    $newrgetpcd.on('click',function () {
    	if(!$yuyincd.hasClass('no-click')){    		
    		if($newrpi.val() == ''){
	    		$newrerr.show();
				$newrerr.find('.errorinfo').html(errmsg.ms1);
	    	}else if($newrpiccd.val() == ''){
	    		$newrerr.show();
				$newrerr.find('.errorinfo').html(errmsg.ms2);
	    	}else if(photoYoN !== 1 ){    		
	    		$newrpi.blur();
	    	}else if(imgcodeava !== 1){
	    		$newrpiccd.blur();
	    	}else if(!newphoava){
	    		$newrpi.blur();
	    	}else{
	    				
	    		$.ajax({
	    			type:"post",
	    			url:portfssms,
	    			async:true,
	    			xhrFields:{withCredentials:true},
	    			data:{
	    				mobile:$newrpi.val()*1,
	    				sendType:'sms'
	    			},
	    			dataType :"json",
	    			success:function (data) {
	    				if(data.errcode == 0){
	    					$newrgetcdt.show();   
	    					$newrerr.hide();
	    					time($newrgetpcd);	
	    				}else{
	    					$newrgetcdt.hide();
	    					$newrerr.show();
							$newrerr.find('.errorinfo').html(data.msg);
	    				}
	    			}
	    		});  		
	    								
	    	}
    	}else{
    		$newrerr.show();
			$newrerr.find('.errorinfo').html('请求操作频繁,请稍后再试');
    	}
    		
    }); 
    
   
    
    $yuyincd.on('click',function () {
    	if(!$newrgetpcd.hasClass('no-click')){
    		if($newrpi.val() == ''){
	    		$newrerr.show();
				$newrerr.find('.errorinfo').html(errmsg.ms1);
	    	}else if($newrpiccd.val() == ''){
	    		$newrerr.show();
				$newrerr.find('.errorinfo').html(errmsg.ms2);
	    	}else if(photoYoN !== 1 ){    		
	    		$newrpi.blur();
	    	}else if(imgcodeava !== 1){
	    		$newrpiccd.blur();
	    	}else{   		
	    		$newrgetcdt.show();
	    		
	    		$.ajax({
	    			type:"post",
	    			url:portfssms,
	    			async:true,
	    			xhrFields:{withCredentials:true},
	    			data:{
	    				mobile:$newrpi.val()*1,
						sendType:'voice'
	    			},
	    			dataType :"json",
	    			success:function (data) {
	    				if(data.errcode == 0){
	    					dxoryy =1;
	    					time($yuyincd);
	    					$newrerr.hide();
							
	    				}else{
	    					$newrerr.find('.errorinfo').html(data.msg);
							$newrerr.show();
	    				}
	    			}
	    		});  		
	  									
	    	}
    	}else{
    		$newrerr.show();
			$newrerr.find('.errorinfo').html('请求操作频繁,请稍后再试');
    	}

    });
  
	/*
	 * psdcommom 两次输入的密码是否相同
	 */
	function psdcommom () {
		var $onepassword = $newrpsdone.val(), //第一个密码的input
		    $twopassword = $newrpsdtwo.val(); //第二个密码的input
		
			if($onepassword !== $twopassword){
				$newrerr.show();
				$newrerr.find('.errorinfo').html(errmsg.ms6)
			}else{
				$newrerr.hide();
			}	
	}
	
	// 判断两次输入的密码属否相同
	$newrpsdone.on('blur',psdcommom);
	$newrpsdtwo.on('blur',psdcommom);
	
	
	 // 跳转的倒计时
    var newrtt = 3,
    	$newrokb = $('#js-newuserrigister-ok'); //成功以后的倒计时盒子里面的input
	function newrokt(o) {
        if (newrtt == 0) {        	
        	window.location.href = '/';
            newrtt = 3;
        } else {        
            o.val(newrtt+"秒后自动跳至首页");
            newrtt--;
            setTimeout(function() {
                newrokt(o);
            },
            1000)
        }
    };

    //用户昵称的判断限制
//  var newusername =0;
//	$newruser.on('blur',function () {
//		var usernamereg = /^[0-9a-zA-Z\u4e00-\u9fa5_]{4,20}$/;
//		if(!usernamereg.test($(this).val())){
//			$newrerr.find('.errorinfo').html('4-20个字符之间(数字、字母、汉字、下划线和圆点)');
//  		$newrerr.show();
//		}else{
//			newusername = 1;
//			$newrerr.hide();
//		}
//	});
	
	// 协议同意操作
	var $newregxieyi = $('#js-newreg-xieyi-icon');
    $newregxieyi.on('click',function () {
    	if($(this).hasClass('no')){		    		
    		$(this).removeClass('no');
    		$newrerr.hide();
    		return;
    	}
    	$(this).addClass('no');
    });
	
    // 点击下一步按钮
	$newrnext.on('click',function () {
		if(photoYoN == 1){
				if($newregxieyi.hasClass('no')){
					$newrerr.find('.errorinfo').html('亲,请同意用户协议');
			    	$newrerr.show();
				}else if($newrpi.val() == '' ){
					$newrerr.find('.errorinfo').html(errmsg.ms1);
			    	$newrerr.show();
				}else if($newrpiccd.val() == ''){
					$newrerr.find('.errorinfo').html(errmsg.ms2);
			    	$newrerr.show();
				}else if($newrpicd.val() == ''){
					$newrerr.find('.errorinfo').html(errmsg.ms3);
			    	$newrerr.show();
				}else if($newrpsdone.val() == ''){
					$newrerr.find('.errorinfo').html(errmsg.ms5);
			    	$newrerr.show();
				}else if($newrpsdtwo.val() == ''){
					$newrerr.find('.errorinfo').html(errmsg.ms6);
			    	$newrerr.show();
				}else if(photoC !== 1){
					$newrpi.blur();
				}else if(imgcodeava !== 1){
					$newrpiccd.blur();
				}else if(photocode !== 1){
					$newrpicd.blur();
				}else if($newrpsdone.val() !== $newrpsdtwo.val()){
					$newrerr.find('.errorinfo').html(errmsg.ms6);
			    	$newrerr.show();
				}else if($newrpsdtwo.val().length<6 || $newrpsdone.val().length<6){
					$newrerr.find('.errorinfo').html(errmsg.ms7);
			    	$newrerr.show();
				}else{
					
					// 这里放给后台传输的数据	判断手机号和验证码是否匹配					
					var urlsy = portyzsms ,
					datasy = {
						mobile:$newrpi.val()*1,
						smsVerifyCode:$newrpicd.val()
					}
					
					ajaxinfoava(urlsy,datasy,function(data) {
						if(data.errcode == 0){
							// 这里放input都不为空,且都合法的操作
							var urlgoto = portgo ,
								datagoto = {
									mobile:$newrpi.val()*1,
									password:$newrpsdone.val(),
									passwordAgain:$newrpsdtwo.val(),
									smsVerifyCode:$newrpicd.val(),
									source:5						
								}
							
								ajaxinfoava(urlgoto,datagoto,function(data) {
										if(data.errcode == 0){
											//成功可以跳转了
											$newrnext.addClass('no-click');//成功了就不可重复点击了，防止网速不好的情况
											$('#js-newuserrigister-ok-box').show();
											newrokt($newrokb);
											$newrerr.hide();
										}else{
											$newrnext.removeClass('no-click');//失败了移除不可点击的属性
											$newrerr.find('.errorinfo').html(data.msg);
											$newrerr.show();
										}
		
								});	
						}else{
							photocode = 0;
							var msg = data.msg;
							$newrerr.find('.errorinfo').html(msg);
							$newrerr.show();
						}
					});										
				}				
		}else{
			$newrpi.blur();
		}
	});
	
});