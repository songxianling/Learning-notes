;define('home.widget.userlogin.comlogin.js.comlogin',function  () {		
		    // 成功page的倒计时
		    var comloginokwait = 3,
		    	$comlogintimebox = $('#js-comlogin-ok'); //成功以后的倒计时盒子
			function comloginoktime(o) {
		        if (comloginokwait == 0) {
		        	//这里跳转首页的操作
		        	window.location.href = '/';
		            comloginokwait = 3;
		        } else {		        	
		            o.val(comloginokwait +"秒后自动跳至首页");
		            comloginokwait--;
		            setTimeout(function() {
		                comloginoktime(o);
		            },
		            1000)
		        }
		    };
		   comloginoktime($comlogintimebox);//倒计时操作
});