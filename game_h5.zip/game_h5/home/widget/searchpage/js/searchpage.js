define('home.widget.searchpage.js.searchpage',function() {

	// 显示剩余100%
	var showNum = require("common.static.js.common");
		showNum.gameShow();

	// 搜索游戏加载更多
	var $loadBtn = $(".js-searchpage-loadbtn");

	var type = $("#js-search-type").val(),
		imghost = $("#js-search-imghost").val(),
		wd = $("#js-search-wd").val(),
		index = 1,
		loadOk = true,
		giftindex = 1;

	$loadBtn.on("click",function(){
		if(type=="game"){
			gameShowli();
		}else{
			giftShowli();
		}
	})
	// 渲染game
	function gameShowli(){

		if(loadOk){
			index++;
		var url = "/game/search/api",
			data={
				currentPage:index,
				wd:wd
			}
			showNum.newcommonAjax(url,data,showGameli);
			loadOk = false;
		}
		
	}
	function showGameli(data){
		var dataArr = data.data,
			wyId = JSON.parse($("#js-wy-id").val());
		if(dataArr.games!="" && dataArr.games!=null){
			var html = "",
				wyhtml = "";
			for(var i=0;i<dataArr.games.length;i++){
				var downloadUrl = dataArr.games[i].download_url,
					hide = "";
				if(downloadUrl=="" || downloadUrl==null){
					downloadUrl = "/com/errors/errmsg?msg=抱歉，没有当前系统可下载的安装包！";
				}
				if(dataArr.games[i].quit_game_cashback_ratio=="0.00"){
					hide = "hide";
				}
				if($.inArray(dataArr.games[i].id,wyId)!= -1){
					wyhtml='<div class="retrieve js-tuiyou-btn'+hide+'">'+
								'<span class="tp">支持</span>'+
						    	'<span class="bm">回收</span>'+
						   '</div>'
				}else{
					wyhtml='<div class="retrieve js-tuiyou-btn '+hide+'">'+
								'<span class="tp">回收价</span>'+
						    	'<span class="bm">'+dataArr.games[i].quit_game_cashback_ratio+'%</span>'+
							'</div>'
				}

				html+='<li>'+
						'<div class="img">'+
							'<a href="/game/'+dataArr.games[i].spelling+'-'+dataArr.games[i].id+'"><img src="'+imghost+''+dataArr.games[i].pic+'"></a>'+
						'</div>'+
						'<div class="msg">'+
							'<p class="title">'+dataArr.games[i].name+'</p>'+
							'<p class="type">类型：'+dataArr.games[i].categoryname+'</p>'+
							'<p class="times">下载次数：'+dataArr.games[i].download_count+'</p>'+
							''+wyhtml+''+
							'<a class="downloadbtn" href="'+downloadUrl+'">立即下载</a>'+
							'<span class="size">大小：'+dataArr.games[i].size+'M</span>'+
						'</div>'+
					'</li>'
			}

			$(".js-gift-uls").append(html);

			if(dataArr.hasmore){
				loadOk = true;
			}else{
				$loadBtn.html("没有更多数据可加载！");
			}
			

		}
	}

	// 渲染礼包
	function giftShowli(){
		if(loadOk){
			giftindex++;
		var url = "/gift/search/api",
			data={
				currentPage:giftindex,
				wd:wd
			}
			showNum.newcommonAjax(url,data,showGiftli);
			loadOk = false;
		}
	}
	function showGiftli(data){
		var dataArr = data.data;
		if(dataArr.gifts!="" && dataArr.gifts!=null){
			var html="";
			for(var i=0;i<dataArr.gifts.length;i++){
				html+='<li class="clearfix">'+
							'<div class="img">'+
								'<a href="/libao/'+dataArr.gifts[i].spelling+'-'+dataArr.gifts[i].gameid+'-'+dataArr.gifts[i].id+'"><img src="'+imghost+''+dataArr.gifts[i].gift_pic+'"></a>'+
							'</div>'+
							'<div class="msg">'+
								'<a href="/libao/'+dataArr.gifts[i].spelling+'-'+dataArr.gifts[i].gameid+'-'+dataArr.gifts[i].id+'"><p class="title">'+dataArr.gifts[i].gift_name+'</p></a>'+
								'<div class="stock gb-js-stock'+giftindex+'" data-num="'+dataArr.gifts[i].total_count_ratio+'"></div>'+
								'<a class="btn" href="/libao/'+dataArr.gifts[i].spelling+'-'+dataArr.gifts[i].gameid+'-'+dataArr.gifts[i].id+'">领取</a>'+
								'<p class="date">有效期：'+dataArr.gifts[i].start_time+'至'+dataArr.gifts[i].end_time+'</p>'+
							'</div>'+
						'</li>'
			}
			$(".js-search-gift").append(html);
			showNum.gameShow(giftindex);
			if(dataArr.hasmore){
				loadOk = true;
			}else{
				$loadBtn.html("没有更多数据可加载！");
			}
		}
	}

});
