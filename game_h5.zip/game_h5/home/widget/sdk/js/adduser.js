define('home.widget.sdk.js.adduser',function() {
	var $par = $(".js-b-sdk-extract-box"),
		$tap = $par.find(".js-tap"),
		$zhifubao = $(".js-zhifubao-zhanghu"),
		$yinhangka = $(".js-yinhangka-zhanghu"),
		$errorMsg = $(".js-sdk-msgbox"),
		$zhiname = $(".js-zhifubao-name"),
		$zhinum = $(".js-zhifubao-num"),
		$yhkUsername = $(".js-yinhangka-username"),
		$yhkName = $(".js-yinhangka-name"),
		$yhkNum = $(".js-yinhangka-num"),
		$yhkAddress = $(".js-yinhangka-address"),
		$sunbtn = $(".js-sdk-btnbox");

	var	index = 0,
		msg = {
			msg1:"支付宝用户名输入为空",
			msg2:"支付宝用户名格式错误",
			msg3:"支付宝账号输入为空",
			msg4:"银行卡真实姓名为空",
			msg5:"银行卡真实姓名格式有误",
			msg6:"银行名称为空",
			msg7:"银行名称格式有误",
			msg8:"银行账号为空",
			msg9:"银行开户行所在地为空",
			msg10:"支付宝账号格式有误"
		},
		url="/usercenter/bank/savebank";

	var commonClass = require("common.static.js.common");

	init();

	$tap.on("click","li",function(){
		$(this).addClass("cur").siblings().removeClass("cur");
		index = $(this).index();
		init();
	})

	function init(){
		$errorMsg.hide();
		if(index==0){
			$zhifubao.show();
			$yinhangka.hide();
			zhifubaoFun();
		}else{
			$zhifubao.hide();
			$yinhangka.show();
			yinhangkaFun();
		}
	}

	// 新增支付宝
	function zhifubaoFun(){

		$sunbtn.on("click",".ok",function(){
			var name = $zhiname.val(),
				num = $zhinum.val(),
				data = {
					'banktype' : '1',
					'bankno' : num,
					'bankname' : '',
					'realname' : name,
					'address' : ''  
				}
			if(index==0){
				if(name == "" || name == null){
					$errorMsg.show();
					$errorMsg.html(msg.msg1);
					$zhiname.focus();
					return false;
				}else if(!commonClass.wordValid(name)){
					$errorMsg.show();
					$errorMsg.html(msg.msg2);
					$zhiname.focus();
					return false;
				}
				if(num=="" || num==null){
					$errorMsg.show();
					$errorMsg.html(msg.msg3);
					$zhinum.focus();
					return false;
				}else if(/[\u4E00-\u9FFF]/g.test(num)){
					$errorMsg.show();
					$errorMsg.html(msg.msg10);
					$zhinum.focus();
					return false;
				}
				commonClass.newcommonAjax(url,data,callzhiFun);
				
				$errorMsg.hide();

			}
			
		})	
		
	}

	function callzhiFun(data){
		console.log(data);
	}

	// 银行卡绑定
	function yinhangkaFun(){
		$sunbtn.on("click",".ok",function(){
			if(index==1){

			var subname = $yhkUsername.val(),
				subyhname = $yhkName.val(),
				subyhnum = $yhkNum.val(),
				subyhaddress = $yhkAddress.val();

				if(subname == "" || subname == null){
					$errorMsg.show();
					$errorMsg.html(msg.msg4);
					$yhkUsername.focus();
					return false;
				}else if(!commonClass.wordValid(subname)){
					$errorMsg.show();
					$errorMsg.html(msg.msg5);
					$yhkUsername.focus();
					return false;
				}
				if(subyhname == "" || subyhname == null){
					$errorMsg.show();
					$errorMsg.html(msg.msg6);
					$yhkName.focus();
					return false;
				}else if(!commonClass.wordValid(subyhname)){
					$errorMsg.show();
					$errorMsg.html(msg.msg7);
					$yhkName.focus();
					return false;
				}
				if(subyhnum == "" || subyhnum == null){
					$errorMsg.show();
					$errorMsg.html(msg.msg8);
					$yhkNum.focus();
					return false;
				}
				if(subyhaddress == "" || subyhaddress == null){
					$errorMsg.show();
					$errorMsg.html(msg.msg9);
					$yhkAddress.focus();
					return false;
				}
				var data = {
					'banktype' : '2',
					'bankno' : subyhnum,
					'bankname' : subyhname,
					'realname' : subname,
					'address' : subyhaddress
				}
				console.log(data);
				commonClass.newcommonAjax(url,data,callyinFun);

				$errorMsg.hide();


			}
		})
	}
	function callyinFun(data){

	}
})
