define('home.widget.sdk.js.extract',function() {

	var $tapbox = $(".js-extract-tap"),
		$zhanghu = $(".js-extract-xinxi"),
		$taoshou = $(".js-extract-taoshou"),
		$num = $(".js-extract-num"),
		$mony = $("#js-b-sdk-money").val(),
		$msg = $(".js-extract-msg"),
		$sub = $(".js-extract-subbtn"),
		$duanxin = $("#js-extract-duanxin-btn"),
		$yanzheng = $(".js-extract-yanzheng");


	var val="",data,yanzhengNum="",
		url = "/usercenter/extraction/save",
		curindex = 2,
		getD = true,
		msg1 = "提现金额超出可提现额度！";

	var comonAjax = require("common.static.js.common");

	$tapbox.on("click","li",function(){
		var _this = $(this),
		    index = _this.index();
		_this.addClass("cur").siblings().removeClass("cur");
		if(index==1){
			$zhanghu.show();
			$taoshou.hide();
			curindex =1;
		}else{
			curindex =2
		}
	})
	// 用户输入提现金额
	$num.on("input",function(){
		val = $(this).val();
		if(val > $mony){
			$msg.html(msg1);
			return false;
		}

	})

	// 短信验证码
	$duanxin.on("clcik",function(){
		if(getD){
		   getD = false;
		var getDuanxin = "/com/verify/sms-vcode-user",
			duanxin ={position : 2};
		comonAjax.newcommonAjax(getDuanxin,duanxin,duanxinFun);
		}
	})
	function duanxinFun(data){
		if(data.errcode == 0){
			var timeNum = 60;
			setInterval(function(){
				timeNum--;
				if(timeNum==0){
				  getD = true;
				  $duanxin.html("获取短信验证码");
				}else{
				  $duanxin.html(timeNum+"秒后重试");
				}
				
			},1000)
		}else{
			alert(data.msg);
			getD = true;
		}
		
	}



	$sub.on("click",function(){

		yanzhengNum = $yanzheng.val();
		data = {
			banktype:curindex,
			price : val,
			verifycode : yanzhengNum
		}
		if(val == "" || val == null){
			return false;
		}else if(!/^[1-9][0-9]*$/g.test(val)){
			return false;	
		}else if(yanzhengNum == "" || yanzhengNum == null){
			return false;
		}
		comonAjax.newcommonAjax(url,data,callFun)
	})

	function callFun(data){
		console.log(data);
	}
	




 })