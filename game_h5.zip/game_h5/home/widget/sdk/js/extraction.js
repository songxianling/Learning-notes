define('home.widget.sdk.js.extraction',function() {

	var comAjax = require("common.static.js.common");

	var index = 1,
		ifmore = true;

	var $moreBtn = $(".js-b-sdk-more"),
		$uls = $(".js-extraction-uls");

	$moreBtn.on("click",function(){
		var url = "",
			data = {};

		if(ifmore){
			comAjax.newcommonAjax(url,data,showData);
		}
	})
	function showData(data){
		var html = "";
		if(data.errcode == 0){
			for(var i=0;i<data.data.length;i++){
				var paytype = data.data[i].banktype == "1" ? "支付宝" : "银行卡";
				var orderSta = data.data[i].auditingstates == "1" ? '<span class="dai">待审核</span>' : '<span class="nopass">未通过</span>';
				html+='<li>'+
						'<div class="top">'+
							'<p class="p1">'+
								'<img src="home:widget/sdk/img/tixian.png" alt="">'+
							'</p>'+
							'<p class="p2">'+
								'<span>'+data.data[i].price+'<i>(手续费:'+data.data[i].taxprice+'元)</i></span>'+
								'<span class="r05">账户类型：'+paytype+'</span>'+
							'</p>'+
							'<p class="p3">'+
								'<span>'+data.data[i].addtime+'</span>'+
								'<span class="r05">流水号：'+data.data[i].bizno+'</span>'+
							'</p>'+
							'<p class="p4">'+orderSta+'</p>'+
						'</div>'+
						'<div class="bottom">备注：'+data.data[i].auditnote+'</div>'+
					'</li>';
			}
			$uls.append(html);
		}
	}
})