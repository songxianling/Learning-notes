define('home.widget.index.js.mp4ad', function () {

        var $videoBox = $("#video-box");
        var $closeBtn = $("#close-btn");

        $closeBtn.on("click",function(){
            document.getElementById('video1').pause();
            $videoBox.hide();
        });

        var commC =  require("common.static.js.common");

        if(!commC.getCookie("mp4ad")){
            $videoBox.show();
            // commC.setCookie("mp4ad","1",1);
        }else{
            $videoBox.hide();
        }

})