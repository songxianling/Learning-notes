define('home.widget.index.js.indexad', function () {



})