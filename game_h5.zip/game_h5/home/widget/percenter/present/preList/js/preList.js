;define('home.widget.percenter.preList.js.preList',function  () {
	var commonClass = require("common.static.js.common"),
		index = 1,
		load = true,
		gameuserid = $('#js-presentList-userID').val(),
		imghost = $('#js-imghost').val();		
	$('#js-presentList-jz-move').on('click', function() {		
		console.log(1);
		if(load){
			index ++;
			var url = "/usercenter/extraction/list?currentPage="+index,
			data = {};			
			commonClass.newcommonAjax(url,data,zjMove);			
		}				
	});
		var presentListEl = $("#js-presentList-List");
		function zjMove (data) {			
			console.log(data);
			if(data.errcode == 0){
				var dataAry = data.data.dataProvider,
				hasMore = data.data.hasmore,
				timeGsh;
			if(dataAry != "" && dataAry !=null){
			var html = "";							
				for (var i=0;i<dataAry.length;i++) {
					timeGsh = (dataAry[i].addtime).slice(0,10);
					html='<li class="clearfix">'+
						 '<a href="/usercenter/extraction/detail?id='+dataAry[i].id+'" class="clearfix">'+
							'<span>'+timeGsh+'</span>'+
							'<span>提现</span>'+
							'<span></span>'+
							'<span>'+dataAry[i].price+'</span>'+
							'</a>'+
						'</li>';
					presentListEl.append(html);	
				}
				if(hasMore == 0){
					load = false;
					$('#js-presentList-jz-move').html('全部数据已加载完成！');					
				}
			}
			}else{
				//加载失败
			}
			
		}
});