;define('home.widget.percenter.preDetail.js.preDetail',function  () {
	var commonClass = require("common.static.js.common"),
		index = 1,
		load = true,
		imghost = $('#js-imghost').val();		
	$('#p-mygifts-jz-move').on('click', function() {		
		
		if(load){
			index ++;
			var url = "/user/my-gift/ajaxgift",
			data = {
				pagenumber:index
			};			
			commonClass.newcommonAjax(url,data,zjMove);			
		}				
	});
		var el = $("#List");
		function zjMove (data) {
			var dataAry = data.data.list,
				hasMore = data.data.hasmore;
			if(dataAry != "" && dataAry !=null){
			var html = "";							
				for (var i=0;i<dataAry.length;i++) {					
					html='<li class="gifts-box clearfix">'+
							'<a href="/libao/'+dataAry[i].spelling+'-'+dataAry[i].gameId+'-'+dataAry[i].id+'">'+
							'<div class="top clearfix" id="top">'+
								'<img src="'+imghost+''+dataAry[i].icon_pic+'" alt="" />'+
								'<div class="right-box clearfix">'+
									'<p>'+dataAry[i].name+'</p>'+
									'<p>'+
										'<span class="time-to">有效期：</span>'+
										'<span class="time-box">'+
											'<span>'+dataAry[i].start_time+'     至</span>'+
											'<span>'+dataAry[i].end_time+'</span>'+
										'</span>'+
									'</p>'+
								'</div>'+
							'</div>'+
							'</a>'+
							'<p class="cashing-num">兑换码：<span>'+dataAry[i].code+'</span></p>'+
							'<p class="ling-time">领取时间：'+dataAry[i].received_time+'</p>'+
						'</li>';
					el.append(html);	
				}
				if(hasMore == 0){
					load = false;
					$('#p-mygifts-jz-move').html('全部数据已加载完成！');
					
				}
			}
		}
});