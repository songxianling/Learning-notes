;define('home.widget.percenter.prePage.js.prePage',function  () {
	var tsyORyhk = 0;
	$('.radio').on('click',function () {
		$errorInfoBox.hide();
		tsyORyhk = $(this).index();
		if(tsyORyhk == "1"){
			$(".js-msg").show();
		}else{
			$(".js-msg").hide();
		}
		$(this).find('i').addClass('radio-inner').parent().parent().siblings().find('i').removeClass('radio-inner');
		$('.tab-con-box .tab-con').eq($(this).index()).show().siblings().hide();
		$('.tx-inp').val('');
	});
	
	// 获取验证码的倒计时
			var wait=60;
			function time(o) {
		        if (wait == 0) {		        			                     
		            o.val("获取短信验证码");	
		            $('.get-code').removeClass('no-click');
		            wait = 60;
		        } else {
		        	$('.get-code').addClass('no-click');
		            o.val(wait +"s");
		            wait--;
		            setTimeout(function() {
		                time(o);
		            },
		            1000)
		        }
		    };
		    var commonClass = require("common.static.js.common");
			$('.get-code').click(function(){
				var url = '/com/verify/sms-vcode-user?position=2';
				data = {};			
				commonClass.newcommonAjax(url,data,time($('.get-code')));					
			});
			
		
		//提现金额为整数
		var maxNum =  $('#js-tuiyoujine').val()*1,//提现金额的上限
			$errorInfoBox = $('#js-error-info'), //错误信息的盒子
			$txInp1 = $('.js-tx-inp-1'), //提现金额的input
			$dxInp = $('.dx-inp'), //短信的input
			$tj = $('#js-tj'), //提交的按钮
			$tsyTxInp = $('#js-tx-inp-tsy'), //淘手游提现input
			$tsyDxInp = $('#js-dx-inp-tsy'), //淘手游短信input
			$yhkTxInp = $('#js-tx-inp-yhk'), //银行卡提现input
			$yhkDxInp = $('#js-dx-inp-yhk'), //银行卡短信input
			jineText = '*请输入正确的提现金额*',
			duanxinText = '请输入短信验证码';
			
		
		//判断提现金额是否大于10
		if(maxNum < 10){
			$('.get-code').addClass('no-click');
			$('.js-jine-mannum').html('余额不足10元,不能申请提现哦！')
		}
		
			
		$txInp1.on('blur',function () {
			var reg = /^[0-9]+$/;//为正整数的正则
			var inpVal = $(this).val()*1;
			if(!reg.test(inpVal) || inpVal<10 || inpVal > maxNum){				
				$errorInfoBox.show();
				$(this).val('');
				return;
			}
			$errorInfoBox.hide();
		});
		
		$dxInp.on('blur',function () {
			if($txInp.val() != ''){
				$errorInfoBox.hide();
			} 
		});
	
	
	//提交操作
	$tj.on('click',function () {
			
			var banktype,
			price,
			vfcCode;
		if(tsyORyhk == 0){			
			banktype = 2;
			price = $tsyTxInp.val();
			vfcCode = $tsyDxInp.val();
			if($tsyTxInp.val()==''){
				$errorInfoBox.html(jineText);
				$errorInfoBox.show();
			}else if($tsyDxInp.val()==''){
				$errorInfoBox.html(duanxinText);
				$errorInfoBox.show();
			}else{
				$(this).addClass('no-click');	
				$.ajax({
					type:"post",
					url:"/usercenter/extraction/save",
					async:true,
					dataType: "json", 
					data:{
						'banktype' 	: banktype,
						'price'		: price,
						'verifycode': vfcCode,
						
					},
					success:function (data) {
						if(data.errcode == 0){
							window.location.href = "/user/home/index";
						}else{
							$tj.removeClass('no-click');
							var msgInfo = data.msg;
							$errorInfoBox.html(msgInfo);
							$errorInfoBox.show();
						}
						
					}					
				});
			}									
		}else if(tsyORyhk == 1){			
			banktype = 1;
			price = $yhkTxInp.val(),
			vfcCode = $yhkDxInp.val();
			if($yhkTxInp.val()==''){
				$errorInfoBox.html(jineText);
				$errorInfoBox.show();
			}else if($yhkDxInp.val()==''){
				$errorInfoBox.html(duanxinText);
				$errorInfoBox.show();
			}else{
				$(this).addClass('no-click');	
				$.ajax({
					type:"post",
					url:"/usercenter/extraction/save",
					async:true,
					dataType: "json", 
					data:{
						'banktype' 	: banktype,
						'price'		: price,
						'verifycode': vfcCode,
					},
					success:function (data) {
						if(data.errcode == 0){							
							window.location.href = "/user/home/index";
						}else{
							$tj.removeClass('no-click');
							var msgInfo = data.msg;
							$errorInfoBox.html(msgInfo);
							$errorInfoBox.show();
						}
					}
				});
			}
		}	
		
									
	});
	// ↑ 提交操作结束

});