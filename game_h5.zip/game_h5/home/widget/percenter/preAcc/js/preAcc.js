;define('home.widget.percenter.preAcc.js.preAcc',function  () {
	var zfbORyhk = 0,
		$accErr = $('#js-error-info'), //错误信息盒子
		$zfbrealname = $('#js-zfb-name'),  //支付宝姓名input
		$zfbaccounts = $('#js-zfb-account'),  //支付宝帐号input
		
		$yhkrealname = $('#js-yhk-name'),  //银行卡真实姓名input
		$yhkname = $('#js-yhk-yhnm'),      //银行卡名称input
		$yhkaccounts = $('#js-yhk-account'),  //银行卡帐号input
		$yhkaddress = $('#js-yhk-kh');  //银行卡开户地址input
	$('.js-sele').on('click',function () {
		$accErr.hide();
		zfbORyhk = $(this).index();
		if($(this).index()==0){
			$('#js-sele-x').css('left','0');
		}else{
			$('#js-sele-x').css('left','50%');
		}
		$('.con').eq($(this).index()).show().siblings().hide();			
	});
	var $banktype = $('#js-preAcc-banktype').val(),   //绑定类型		
		$bankno_m = $('#js-preAcc-bankno').val(),     //网银帐号
		$bankname_m = $('#js-preAcc-bankname').val(), //银行卡名称
		$realname_m = $('#js-preAcc-realname').val(), //真实姓名
		$address_m = $('#js-preAcc-address').val();   //开户行地址
	if($banktype == 1){		
		$zfbrealname.val($realname_m);
		$zfbaccounts.val($bankno_m);
	}else{		
		$('.js-sele').eq(1).click();
		$yhkrealname.val($realname_m);
		$yhkname.val($bankname_m);
		$yhkaccounts.val($bankno_m);
		$yhkaddress.val($address_m);
	}
	
	
	
	//支付宝page中的input有没有内容判断
	var $accZfbInp = $('.zfb-inp'), //支付宝页面的input
		$accYhkInp = $('.yhk-inp'); //银行卡页面的input
	$accZfbInp.on('blur',function () {
		if($(this).val() !=''){
			$accErr.hide();
			return;
		}
		$accErr.show();
	});
	$zfbaccounts.on('blur',function () {
		var reg2 = /[\u4E00-\u9FA5\uF900-\uFA2D]/;
		if(reg2.test($(this).val())){
			$accErr.html(errmsg.ms2);
			$accErr.show();
			return;
		}
	});
	
	//银行卡page中的input有没有内容判断
	$accYhkInp.on('blur',function () {		
		if($(this).val() !=''){
			$accErr.hide();
			return;
		}
		$accErr.show();
	});
	$('#js-yhk-account').on('blur',function () {		
		var reg =/^(\d{16}|\d{19})$/,
			yhInp = $(this).val();				
		if(!reg.test(yhInp)){
			$accErr.html(errmsg.ms4);
			$accErr.show();
		}else{
			$accErr.hide();
		}
	});
	
	var errmsg = {
		ms1:'*请输入正确的姓名信息*',
		ms2:'*请输入正确的支付宝信息*',
		ms3:'*请输入正确的银行名称信息*',
		ms4:'*请输入正确的银行帐号信息*',
		ms5:'*请输入正确的银行开户行信息*'
	}
	//保存提交操作
	//提交操作
	$('#js-bc').on('click',function () {
		var banktype, //'网银类型：1支付宝 2 银行卡'
			bankno,   //'网银账号'
			bankname, //'银行卡名称'
			realname, //'真实姓名'
			address;  //'开户行地址'
		if(zfbORyhk == 0){				
			//zfb
			banktype = 1;
			bankno = $zfbaccounts.val();
			realname = $zfbrealname.val();
			if($('#js-zfb-name').val() == ''){				
				$accErr.html(errmsg.ms1);
				$accErr.show();
			}else if(bankno == '' || /[\u4E00-\u9FA5\uF900-\uFA2D]/.test(bankno)){
				$accErr.html(errmsg.ms2);
				$accErr.show();
			}else{
				$.ajax({
					type:"post",
					url:"/usercenter/bank/savebank",
					async:true,
					dataType: "json", 
					data:{
						'banktype' 	: banktype ,
				    	'bankno' 	: bankno ,
				    	'bankname' 	: '',
				    	'realname' 	: realname,
				    	'address' 	: '',  
					},
					success:function (data) {
						if(data.errcode == 0){
							window.location.href = "/user/home/index";
						}else{
							$accErr.html(data.msg);
							$accErr.show();
						}
					}
				});
			}									
		}else if(zfbORyhk == 1){			
			banktype = 2;
			bankno = $('#js-yhk-account').val();
			bankname = $('#js-yhk-yhnm').val();
			realname = $('#js-yhk-name').val();
			address = $('#js-yhk-kh').val();
			if(realname == ''){
				$accErr.html(errmsg.ms1);
				$accErr.show();
			}else if(bankname == '' ){
				$accErr.html(errmsg.ms3);
				$accErr.show();
			}else if(bankno == '' ){
				$accErr.html(errmsg.ms4);
				$accErr.show();				
			}else if(address == ''){
				$accErr.html(errmsg.ms5);
				$accErr.show();
			}else{
				$.ajax({
					type:"post",
					url:"/usercenter/bank/savebank",
					async:true,
					dataType: "json", 
					data:{
						'banktype' 	: banktype,
						'bankno'	: bankno,
						'bankname' 	: bankname ,
				    	'realname' 	: realname ,
				    	'address' 	: address , 
					},
					success:function (data) {
						if(data.errcode == 0){
							window.location.href = "/user/home/index";
						}else{
							$accErr.html(data.msg);
							$accErr.show();
						}
						
					}
				});
			}
		}								
	});
	//保存提交操作结束
	
	
});