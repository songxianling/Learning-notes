;define('home.widget.percenter.mygame.js.mygame',function  () {
	var $chongzhijilu = $('.js-layou-showhide'),//充值记录的点击按钮
		$rechargepar = $('#js-czjl-box'),//充值记录中要被放数据的UL
		$outerBox = $('.js-layou-box'),//充值记录的最外大盒子
		czIndex = 1;
	$chongzhijilu.on('click',function () {
		$outerBox.show();
	});
	$('#js-layou-close').on('click',function () {
		$outerBox.hide();
	});	
	// 点击我的游戏列表页面中的充值记录的按钮操作
	var gameuserid;//这个ID是充值记录的id
	$chongzhijilu.on('click',function () {
		gameuserid = $(this).attr('data-czID');	
		$rechargepar.html('');
		chongzhiAjax(czIndex,gameuserid);
	});
	
	//充值记录页面中的加载更多操作
	$('#js-czjl-box').on('click','#chongzhi-jz-move',function(){
		czIndex++;
		chongzhiAjax(czIndex,gameuserid);
	});	
	
	/**
	 * chongzhiAjax -> 充值记录渲染ajax的操作封装
	 * @param {Number} czIndex ->  页数
	 */
	function chongzhiAjax (czIndex,gameuserid) {
		var ynLoad = true;			
		if(ynLoad){
			$.ajax({
				type:"get",
				url:"/usercenter/mygame/get-recharge-list?gameuserid="+gameuserid+'&currentPage='+czIndex,
				async:true,
				dataType: "json", 
				data:{},
				success:function (data) {				
					loadMore(data);
				}
			});		
		}
	};
	
	/**
	 * loadMore   ->  初次渲染充值记录的函数,也可作为加载更多的方法
	 * @param {Object} data -> 得到的数据
	 */
	function loadMore(data){
			if(data.errcode == 0){
				var dataAry = data.data.tradelogList,
					hasMore = data.data.hasmore;					
				if(dataAry != "" && dataAry !=null){					
					var html = "",
						paytype = "";
					for (var i=0;i<dataAry.length;i++) {
						
						if (dataAry[i].paytype == 0){
							paytype = "余额支付";
						}else if(dataAry[i].paytype == 1 || dataAry[i].paytype == 2 || dataAry[i].paytype == 3 || dataAry[i].paytype == 4 || dataAry[i].paytype == 10 || dataAry[i].paytype == 12 || dataAry[i].paytype == 16){
							paytype = "支付宝";
						}else if(dataAry[i].paytype == 5 || dataAry[i].paytype == 6 || dataAry[i].paytype == 14 || dataAry[i].paytype == 18){
							paytype = "银联";
						}else if(dataAry[i].paytype == 7 || dataAry[i].paytype == 8 || dataAry[i].paytype == 9 || dataAry[i].paytype == 11 || dataAry[i].paytype == 15){
							paytype = "财付通";
						}else if(dataAry[i].paytype == 13 || dataAry[i].paytype == 17){
							 paytype = "微信";
						}
						
						
						
						html = '<li data-click="false">'+
				                '<p>'+
				                	'<span class="czicon"></span>'+
				                    '<span>'+dataAry[i].total_fee+'元</span>'+
				                    '<span class="jt"></span>'+
				                    '<span>'+dataAry[i].addtime+'</span>'+			                    
				                '</p>'+
				                '<div class="content">'+
				                    '<p class="clearfix"><span>消费项目：</span><span>'+dataAry[i].goods_name+'</span></p>'+
				                    '<p class="clearfix"><span>支付方式：</span><span>'+paytype+'</span></p>'+
				                '</div>'+
				            	'</li>';
				            
//					          $rechargepar.append(html); 
          				if(czIndex == 1){
          					//第一次的时候是html          				          					
          					if(hasMore == 1){
          						//这时候证明这个充值记录有更多的数据,要让加载更多的按钮出现
          						var jzHtml = '';
          						jzHtml = '<div class="jz-move" id="chongzhi-jz-move">'+			
										 '<i></i>点击加载更多'+
										 '</div>';				
          					}
          					$rechargepar.append(html);
							$rechargepar.append(jzHtml);
						}else{
							// 现在就是加载更多了
							$rechargepar.append(html);			
						}	
					}
					if(hasMore == 0){
						ynLoad = false;
						//这个地方等测试的时候再调试
						$('#chongzhi-jz-move').html("全部数据已加载完成！");
					}
				}else{
					
					var noHtml = "<p class='noChongzhijl'>您暂时没有充值记录~~~</p>";
					$rechargepar.append(noHtml);
				}
			}else{
				//加载失败								
			}																	
		};
	
	
	//我的游戏页面的加载更多
	
	var commonClass = require("common.static.js.common"),
		mygameIndex = 1, //我的游戏页面中的请求地址后传参
		$mygameJzMore = $('#mygame-jz-move'), //我的游戏页面中的加载更多按钮
		mygameLoad = true; //是否能点击
	 	imghost = $('#js-imghost').val(), //图片
		$el = $("#List");
		
	$mygameJzMore.on('click',function () {
		if(mygameLoad){
			mygameIndex++;
			var url = '/usercenter/mygame/ajaxgetdata?currentPage='+mygameIndex;
			data = {};			
			commonClass.newcommonAjax(url,data,zjMove);
		}
	});
		
	/**
	 * zjMove {Function} 加载更多执行的函数
	 * @param {Object} data
	 */
	var $mygameEl = $('#js-mygame-List'); //游戏列表list外面的UL盒子
	function zjMove (data) {
		if(data.errcode == 0){
			var dataAry = data.data.userGameList,
				hasMore = data.data.hasmore,
				timeGsh;//格式化时间字符串
			if(dataAry != "" && dataAry !=null){				
			var html = "";							
				for (var i=0;i<dataAry.length;i++) {
					timeGsh = (dataAry[i].addtime).slice(0,10);
					var yOntuiyou = ''; // 是否退游
					if(dataAry[i].is_quit_game == 0){
						yOntuiyou = '<p class="tuibtn2" data-pre="'+dataAry[i].totalRecharge+'" data-id="'+dataAry[i].gameuserid+'" data-cry="'+dataAry[i].appid+'">退游返现</p> '
					}else{
						yOntuiyou = '<p class="hui">已退游</p>'
					}
					html='<ul>'+			
	            			'<li class="top">'+
	                			'<div><img src="'+imghost+''+dataAry[i].gamepic+'" alt=""></div>'+
	                			'<div><p>'+dataAry[i].gamename+'</p><p>注册时间：'+timeGsh+'</p></div>'+
				                '<div>'+
				                    '<p class="js-layou-showhide js-layou-showhide-2" data-czID="'+dataAry[i].gameuserid+'">充值记录</p>'+                  
				                    ''+yOntuiyou+''+
				                '</div>'+
				            '</li>'+
				            '<li class="tit">'+
				                '<div><p>累计充值</p><p>'+dataAry[i].totalRecharge+'元</p></div>'+
				                '<div><p>返现比例</p><p>'+dataAry[i].quit_game_cashback_ratio+'%</p></div>'+
				                '<div><p>返现金额</p><p>'+dataAry[i].cashback+'元</p></div>'+
				            '</li></ul>';
					$mygameEl.append(html);	
				}
			if(hasMore == 0){
				mygameLoad = false;
				$mygameJzMore.html("全部数据已加载完成！");
				}
			}
		}else{
			
		}		
	}
	 	
	//这个地方是为了处理我的游戏列表加载更多以后出现的list中的充值记录的操作
	$mygameEl.on('click','.js-layou-showhide-2',function () {
		$outerBox.show();
		gameuserid = $(this).attr('data-czID');	
		$rechargepar.html('');
		chongzhiAjax(czIndex,gameuserid);
	});
	
	
	//li点击展开收起
	$rechargepar.off("click").on("click","li",function(){
				var _this = $(this);
				if(_this.attr("data-click") == "true"){
					_this.find(".content").hide();
					 _this.attr("data-click","false");
					 _this.find(".jt").removeClass("reta");
				}else{
				    _this.find(".content").show();
				    _this.attr("data-click","true");
				    _this.find(".jt").addClass('reta');
				}
			})
	
	
	//弹出框操作、
	var $markLayou =  $('#js-mygame-mark'), //点了退游返现弹出的大盒子
		$cancelLayou = $('#js-cancel'), //弹出层中的取消按钮
		cryid;
	$mygameEl.on('click','.tuibtn2',function () {
		
		if($(this).attr("data-pre") == "0" || $(this).attr("data-pre") == "0.00"){
			$(".js-mygame-mark2").show();
			$(".js-mygame-btns").on("click",function(){
				$(".js-mygame-mark2").hide();
			})
		}else{
			gameuserid = $(this).attr('data-id');
			$markLayou.show();
			cryid = $(this).attr('data-cry');
		}
	});
	
	
	
	$markLayou.on('click',function (event) {			
		$(this).hide();
	});
	$cancelLayou.on('click',function (event) {			
		$markLayou.hide();
	});
	
	$('#mark-con').on('click',function (event) {
		event.stopPropagation();
	});
	//弹出框的获取验证码倒计时
	var wait=60,
		textCode = "获取短信验证码",
		$errorInfoBox = $('#js-error-info'),
		$getCode = $('#js-get-code'), // 获取验证码的按钮
		$markOn = $('#js-markOn'); //确定按钮
		function time(o) {
	        if (wait == 0) {		        			                     
	            o.val(textCode);	
	            $getCode.removeClass('no-click');
	            wait = 60;
	        } else {
	        	$getCode.addClass('no-click');
	            o.val(wait +"s");
	            wait--;
	            setTimeout(function() {
	                time(o);
	            },
	            1000)
	        }
	    }
		$getCode.click(function(){						
			var url2 = '/com/verify/sms-vcode-user?position=1';
			data = {};			
			commonClass.newcommonAjax(url2,data,time($getCode));
		});
		
		var sdkAgent = $('#js-agent').val();
		
		$markOn.click(function () {
			var vfcCode = $('#js-vfcCode').val();				
			$.ajax({
					type:"post",
					url:"/usercenter/mygame/quit",
					async:true,
					dataType: "json", 
					data:{
						'gameuserid' : gameuserid,
						'verifycode' : vfcCode,
					},
					success:function (data) {
						if(data.errcode == 0){
							if(sdkAgent == 'TaoshouyouSDK'){
								window.sdk.clickOnSDK(cryid);
							}else{
								window.location.href = "/user/home/index";	
							}
							$markLayou.hide();
						}else{
							var msgInfo = data.msg;
							$errorInfoBox.html(msgInfo);
							$errorInfoBox.show();
						}
						
					}					
				});
		});
		//返现金额提醒
		$('.js-fanxtix').on('click',function (event) {
			event.stopPropagation();
			$(this).find('span').toggle();
		});
		$('#js-mygame-List').on('click',function () {
			$('.js-fanxtix').find('span').hide();
		});
		
		
	
});