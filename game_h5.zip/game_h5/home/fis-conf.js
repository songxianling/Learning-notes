require('fis3-smarty')(fis);
fis.set('namespace', 'home');


/*以下为开发环境配置*/
// 启用 fis-spriter-csssprites 插件
fis.match('::package', {
  spriter: fis.plugin('csssprites')
})

// 对 CSS 进行图片合并
fis.match('*.css', {
  // 给匹配到的文件分配属性 `useSprite`
  useSprite: true
});

fis.match('/page/**.tpl', {
  extras: {
    isPage: true
  }
});


// 开发模式，不压缩不hash
fis.match('/widget/{*,**/*}.{js,css}', {
  useHash:false,
  optimizer: null
});
fis.match('/static/{*,**/*,**/*/*,**/*/*/*}.{js,css}', {
  useHash:false,
  optimizer: null
});
fis.match('/static/img/noparse/*.*', {
    useHash: false
});
fis.match('{/widget/{*.{js,css},**/*.{js,css}},static/js/**.js}', {
    isMod: true
});


// fis.match('{/widget/{*.{js,css},**/*.{js,css}},static/js/**.js}', {
//   isMod: true
// });

// // 针对页面的分别打包
// // 首页模块
// fis.match('{widget/index/**.css,static/css/index/*.css}', {
//   packTo: 'static/pkg/index.css'
// });
// fis.match('{static/jslib/lazyload/lazyload.js,static/jslib/tabsyetii/yetii.js,widget/index/**.js}', {
//   packTo: 'static/pkg/index.js',
// });
// // user模块
// fis.match('{widget/user/**.css,static/css/user/**.css}', {
//   packTo: 'static/pkg/user.css'
// });
// fis.match('{widget/user/**.js,static/js/user/**.js}', {
//   packTo: 'static/pkg/user.js',
// });
// // game列表模块
// fis.match('{widget/game/**.css,static/css/game/**.css}', {
//   packTo: 'static/pkg/game.css'
// });
// fis.match('widget/game/**.js', {
//   packTo: 'static/pkg/game.js'
// });


//--------------------------------------以下为QA Rlease的配置
fis.media('qa').match('*', {
  url:'/static/${namespace}$0',
  release: 'web/${static}/${namespace}/$0' 
});
fis.media('qa').match('${namespace}-map.json', {
  release: '/config/fis/$0'
});
fis.media('qa').match('/{plugin,smarty.conf,domain.conf,**.php}', {
  release: '$0'
});
fis.media('qa').match('*.tpl', {
  preprocessor: fis.plugin('extlang'),
  postprocessor: fis.plugin('require-async'),
  optimizer: [
    fis.plugin('smarty-xss'),
    fis.plugin('html-compress')
  ],
  useMap: true,
  release: '/${template}/${namespace}/$0'
});
fis.media('qa').match('/(widget/**.tpl)', {
  url: '${namespace}/$1',
  useMap: true,
});
fis.media('qa').match('*.{js,css,less}', {
  useHash: true
});
fis.media('qa').match('*.js', {
  optimizer: fis.plugin('uglify-js')
});
fis.media('qa').match('::image', {
  useHash: true
});
fis.media('qa').match('*.{tpl,js}', {
  useSameNameRequire: true
});
fis.media('qa').match('/page/**.tpl', {
  extras: {
    isPage: true
  }
});



fis.media('qa').match('{/widget/{*.{js,css},**/*.{js,css}},static/js/**.js}', {
  isMod: true
});
// 针对页面的分别打包
// 首页模块
fis.media('qa').match('{widget/index/**.css,static/css/index/*.css}', {
  packTo: 'static/pkg/index.css'
});
fis.media('qa').match('{static/jslib/tabsyetii/yetii.js,widget/index/**.js}', {
  packTo: 'static/pkg/index.js',
});
// 文章列表
fis.media('qa').match('{widget/article/**.css,static/css/article/**.css}', {
  packTo: 'static/pkg/articleList.css'
});
fis.media('qa').match('{widget/article/**.js,static/js/article/**.js}', {
  packTo: 'static/pkg/article.js',
});
// 搜索页面
fis.media('qa').match('{widget/searchpage/**.css,static/css/searchpage/**.css}', {
  packTo: 'static/pkg/searchpage.css'
});
fis.media('qa').match('{widget/searchpage/**.js,static/js/searchpage/**.js}', {
  packTo: 'static/pkg/searchpage.js',
});
// 错误页面
fis.media('qa').match('{widget/errorpage/**.css,static/css/errorpage/**.css}', {
  packTo: 'static/pkg/errorpage.css'
});
fis.media('qa').match('{widget/errorpage/**.js,static/js/errorpage/**.js}', {
  packTo: 'static/pkg/errorpage.js',
});
//game
fis.media('qa').match('{widget/game/**.css,static/css/game/**.css}', {
  packTo: 'static/pkg/game.css'
});
fis.media('qa').match('{widget/game/**.js,static/js/game/**.js}', {
  packTo: 'static/pkg/game.js',
});
//gift
fis.media('qa').match('{widget/gift/**.css,static/css/gift/**.css}', {
  packTo: 'static/pkg/gift.css'
});
fis.media('qa').match('{widget/gift/**.js,static/js/gift/**.js}', {
  packTo: 'static/pkg/gift.js',
});
//percenter
fis.media('qa').match('{widget/percenter/**.css,static/css/percenter/**.css}', {
  packTo: 'static/pkg/mygifts.css'
});
fis.media('qa').match('{widget/percenter/**.js,static/js/percenter/**.js}', {
  packTo: 'static/pkg/mygifts.js',
});
//sdk
fis.media('qa').match('{widget/sdk/**.css,static/css/sdk/**.css}', {
  packTo: 'static/pkg/sdk.css'
});
fis.media('qa').match('{widget/sdk/**.js,static/js/sdk/**.js}', {
  packTo: 'static/pkg/sdk.js',
});
//help
fis.media('qa').match('{widget/help/**.css,static/css/help/**.css}', {
  packTo: 'static/pkg/help.css'
});
fis.media('qa').match('{widget/help/**.js,static/js/help/**.js}', {
  packTo: 'static/pkg/help.js',
});





// // user模块
// fis.media('qa').match('{widget/user/**.css,static/css/user/**.css}', {
//   packTo: 'static/pkg/user.css'
// });
// fis.media('qa').match('{widget/user/**.js,static/js/user/**.js}', {
//   packTo: 'static/pkg/user.js',
// });
// // game列表模块
// fis.media('qa').match('{widget/game/**.css,static/css/game/**.css}', {
//   packTo: 'static/pkg/game.css'
// });
// fis.media('qa').match('widget/game/**.js', {
//   packTo: 'static/pkg/game.js'
// });
// // 列表&&详情页模块
// fis.media('qa').match('{widget/trade/**.css,static/css/trade/**.css}', {
//   packTo: 'static/pkg/trade.css'
// });
// fis.media('qa').match('{widget/trade/**.js,static/js/trade/**.js}', {
//   packTo: 'static/pkg/trade.js'
// });
// // accountpsw模块
// fis.media('qa').match('{widget/accountpsw/**.css,static/css/accountpsw/**.css}', {
//   packTo: 'static/pkg/accountpsw.css'
// });
// fis.media('qa').match('{widget/accountpsw/**.js,static/js/accountpsw/**.js}', {
//   packTo: 'static/pkg/accountpsw.js'
// });
// // help
// fis.media('qa').match('{widget/help/**.css,static/css/help/**.css}', {
//   packTo: 'static/pkg/help.css'
// });
// fis.media('qa').match('{widget/help/**.js,static/js/help/**.js}', {
//   packTo: 'static/pkg/help.js'
// });
// // download
// fis.media('qa').match('{widget/download/**.css,static/css/download/**.css}', {
//   packTo: 'static/pkg/download.css'
// });
// fis.media('qa').match('{widget/download/**.js,static/js/download/**.js}', {
//   packTo: 'static/pkg/download.js'
// });
// // complain
// fis.media('qa').match('{widget/complain/**.css,static/css/complain/**.css}', {
//   packTo: 'static/pkg/complain.css'
// });
// fis.media('qa').match('{widget/complain/**.js,static/js/complain/**.js}', {
//   packTo: 'static/pkg/complain.js'
// });

//flash不hash
fis.media('qa').match('/static/jslib/webuploader/dist/Uploader.swf', {
    useHash:false
});
fis.media('qa').match('/static/jslib/ZeroClipboard/ZeroClipboard.swf', {
    useHash:false
});
//wdatatimepicker不hash
fis.media('qa').match('/static/jslib/My97DatePicker/{*.{js,css},**/*.{js,css}}', {
    useHash:false
});
fis.media('qa').match('/static/img/noparse/*.*', {
    useHash: false
});


fis.media('qa').match('*', {
  deploy: fis.plugin('http-push', {
   exclude : /.*\.(?:svn|cvs|tar|rar|psd|bak).*/,
    receiver: 'http://127.0.0.1/receiver.php',
    to: 'D:\\work\\RD\\game_h5' // 注意这个是指的是测试机器的路径，而非本地机器
  })
})
