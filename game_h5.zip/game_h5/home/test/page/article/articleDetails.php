<?php




//$recommandgamelist = require(__DIR__ . '/index_recommandlist.php');
//$tradehighqualitylistModel = require(__DIR__ . '/index_tradehighqualitylist.php');
//$tradelistModel = require(__DIR__ . '/index_newposttradelist.php');
//$helper = require(__DIR__ . '/index_helper.php');
//$noticelistModel = require(__DIR__ . '/index_noticelistModel.php');
$fis_data = array(
    'ImageServerHost' => 'http://img.taoshouyou.com',
    // 'ImageServerHost' => 'http://192.168.0.10:8088',
    
    'title' => '淘手游-最具影响力的手游交易第一平台',
    'lang' => 'en-US',
    'CsrfParam' => "_csrf",
    'CsrfToken' => "eVQ1OTgzSEZAHXdqbWV4DSA5WXEBZiw1OxV0T1AGKX8KGH8IUH58MA==",
    'description' => '淘手游—国内最安全、最权威、服务最完善的手游交易第一平台：提供最具性价比的游戏账号、装备、金币，手游代充等自由买卖、担保寄售交易、安全快捷！淘手游手游交易平台。',
    'metakeyword' => '淘手游,淘手游交易平台,淘手游官网,淘手游手游交易平台,手游交易,手游交易平台,手游交易网,手机游戏交易,手机游戏交易平台',
    // 'imgHost' => 'http://img.taoshouyou.com',
    'imgHost' => 'http://192.168.0.10:8088',
    
    'user' => [
        "isGuest"=>true,    //用户是否匿名访问，在YII中用Yii::$app->user->isGuest获取 
        'username' => '张三',
        'mobile' => '',
        'pic' => '/img/2015-08-03/8/a7ad78745af1057747880b7816e5bfc2.png', //用户头像
    ],
    'bottomAd'=> [ //全局右下角浮动提示
        'title'=> "天天裁决游戏下载", //广告位标题
        'picurl'=> "http://img-test.taoshouyou.com/img/2016-08-30/19/581db75da5c91c804ac7143669037901.gif", //广告位图片地址
        'href'=> "http://9.taoshouyou.com/download/games/6/tiantiancaijue-1_0_0_0" //广告位跳转地址

    ],
    'banner'=>array( //轮播图
        array(
                'picurl' => "/img/2016-08-31/12/8d69dd4d62e71154f12e82e9f44e4433-pc-l.jpg", //轮播图页面地址
                'href'=> "http://www.taoshouyou.com" //轮播图跳转地址   
            ),

    ),
    "ControllerUniqueId" => "indexpage/indexs",  //Controller的唯一id
    //个人信息
    'userInfo' => array(
    	'id' => 445055,
        'username' => '幽影冥狐',
        'realyname' => '是对的撒',
        'certtype' => 1,
        'certno' => '112233445566789',
        'certapproved' => 2,
        'certapprovetime' => 2,
        'certpic' => '/img/2016-04-18/4/d1ddb4dc172d14cb3028dfaf3fe4ed48-pc-l.gif',
        'check_remarks' => null,
        'password' => '63b6aede2da3ea47b227a6cfb860e8a2',
        'passwordlev' => null,
        'authkey' => 'ccdfb8',
        'email' => '123456@1.com',
        'mobile' => '13911037319',
        'ischeckmobile' => 1,
        'sex' => 2,
        'nickname' => '幽影',
        'pic' => '/img/2016-08-15/8/9fdf527c73f1430b64701f4a6f1a2f43-pc-l.jpg',
        'account_weibo' => null,
        'account_qq' => '12222222',
        'qq_openid' => null,
        'usergroupids' => null,
        'buyercredit' => null,
        'sellercredit' => null,
        'newpm' => 0,
        'Islocked' => 0,
        'Islockeddate' => null,
        'lastloginip' => '127.0.0.1',
        'lastlogindate' => '2016-09-08 15:23:52',
        'lastpasswordchangeddate' => null,
        'failedpasswordattemptcount' => 0,
        'failedpasswordattemptwindowstart' => null,
        'failedpasswordanswerattemptcount' => 0,
        'failedpasswordanswerattemptwindowstart' => null,
        'comment' => null,
        'regip' => '123.116.32.142',
        'isdel' => 0,
        'regsource' => 0,
        'addtime' => '2015-11-17 10:00:27',					
	),
	//我的游戏
	'articleList' => array(
    	array(
			'id' => '12',
            'gameid' => '6',
            'pic' => '/img/2016-06-15/2/fe2700f1ad18c83e2481e2d2eeb01e8c.jpg',
            'type' => '2',
            'author' => '淘手游',
            'isdownload' => '0',
            'islist' => '1',
            'iscontent' => '1',
            'title' => '《天天裁决》之夺宝奇兵攻略',
            'introduction' => '',
            'publisher_id' => '658497',
            'publisher_name' => '木小鱼',
            'addtime' => '2016-06-15 19:27:53',
            'gamename' => '天天裁决',
            'typename' => '攻略',
		),
		array(
			 'id' => '11',
            'gameid' => '6',
            'pic' => '/img/2016-06-15/14/abdf6c4c1114c7ea431f7ca28b302c43.jpg',
            'type' => '2',
            'author' => '淘手游',
            'isdownload' => '0',
            'islist' => '0',
            'iscontent' => '1',
            'title' => '《天天裁决》秦陵地宫副本攻略',
            'introduction' => '文章导读',
            'publisher_id' => '658497',
            'publisher_name' => '木小鱼',
            'addtime' => '2016-06-15 19:24:24',
            'gamename' => '天天裁决',
            'typename' => '攻略',
		),			
	),
	//列表信息
	'gameInfo' => array(
		'id' => '6',
    	'name' => '天天裁决',
    	'spelling' => 'tiantiancaijue',
	),
	//全部游戏
	'totalCount' => 100,
	//广告位
	'ad' => array(
		'id' => '60',
	    'title' => '天天裁决游戏下载',
	    'picurl' => 'http://192.168.0.10:8088/img/2016-09-08/12/8d69dd4d62e71154f12e82e9f44e4433.jpg',
	    'href' => 'http://bj-test-game.taoshouyou.com:8096/',
	    'isshow' => '1',
	    'position' => '11',
	    'type' => '2',
	    'addtime' => '2016-09-08 15:34:31',		
	),
	//咨询详情
	'articleResult' => array(
		'id' => '8',
        'gameid' => '6',
        'pic' => '/img/2016-06-15/30/73a47789962713b15c8b8f9ac5ea0040.jpg',
        'type' => '2',
        'author' => '淘手游',
        'isdownload' => '0',
        'islist' => '0',
        'iscontent' => '0',
        'title' => '《天天裁决》职业攻击伤害属性攻略',
        'introduction' => '《天天裁决》即将开启不删档内测，',
        'content' => '<p style=\"text-indent:28px\"><a name=\"OLE_LINK1\" href=\"http://\"></a><span style=\";font-family:微软雅黑;font-size:14px\"><a name=\"OLE_LINK2\" href=\"http://\"></a><a name=\"OLE_LINK3\" href=\"http://\"></a></span></p><p style=\";text-indent: 28px;padding: 0;text-align: justify;line-height: 200%\"><a name=\"OLE_LINK3\" href=\"http://\"></a><a href=\"http://sdk.taoshouyou.com/adminarticle/index/http:\"><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">《天天裁决》</span></a><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">即将开启不删档内测，今天提前来分享关注三职业攻击伤害的属性攻略。</span></p><p style=\";text-indent: 28px;padding: 0;text-align: justify;line-height: 200%\"><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">小伙伴使用职业属性有物理攻防，魔法攻防，道术攻击，致命，闪避，暴击，幸运以及诅咒。这些属性或者来自人物本身，或者来自装备，来自</span><a href=\"http://wwwnanbus.com/lhcj/tag_1590/\" title=\"宝石\"><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">宝石</span></a><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">或者其他功能，这里我不做过多分析，我们暂时只说属性对战斗的影响。</span></p><p style=\";text-indent: 28px;padding: 0;text-align: justify;line-height: 200%\"><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">&nbsp;</span></p><p style=\";text-indent: 28px;padding: 0;text-align: justify;line-height: 200%\"><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">对于玩家的基础属性，物理攻击，魔法攻击，道术攻击，这三项分别会对三个职业的技能进行加成。这意味着提升这三种属性的值越高，技能打出的伤害也就越高，它是玩家的基础属性，重要性不言而喻。然后是物理防御和魔法防御，这很好理解，他们分别对应魔法攻击和物理攻击，同等情况下，防御越高受到的伤害越少。</span></p><p style=\"text-indent:28px\"><span style=\";font-family:微软雅黑;font-size:14px\"><br/></span></p><p style=\"text-align: center;\"><img src=\"http://img.taoshouyou.com/img/2016-06-15/30/3aa2ca2b8929e80f36b004d8027d5ece.png\" _src=\"http://img.taoshouyou.com/img/2016-06-15/30/3aa2ca2b8929e80f36b004d8027d5ece.png\"/></p><p style=\"text-align: center;\"><br/></p><p style=\"text-indent:28px\"><span style=\";font-family:微软雅黑;font-size:14px\"></span></p><p style=\"margin-right:0;margin-left:0;text-indent:28px;text-autospace:ideograph-numeric;text-align:justify;text-justify:inter-ideograph;line-height:200%\"><span style=\"font-family: 微软雅黑;line-height: 200%;letter-spacing: 0;font-size: 14px\">对于一些系数加成的属性，即使值很小，但是对伤害的加成是很大的。命中对应闪避，很好理解，命中是自己能打到别人的几率，闪避是自己能躲避的几率。想想这种情况，如果自己闪避高到躲避掉一切技能，而命中高到能打中所有人，那自己在游戏中将是无敌的存在。</span></p><p style=\"text-align: center;\"><br/></p><p style=\"text-align: center;\"><img src=\"http://img.taoshouyou.com/img/2016-06-15/18/068cde672dbfe790f404cbb51d3e0dde.png\" _src=\"http://img.taoshouyou.com/img/2016-06-15/18/068cde672dbfe790f404cbb51d3e0dde.png\"/></p>', 
        'publisher_id' => '658497',
        'publisher_name' => '木小鱼',
        'addtime' => '2016-06-15 19:13:06',
        'typename' => '攻略',		
	),
	
    'bannerlist' => array(
        array(
            'id' => '1',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 1
        ),
        array(
            'id' => '3',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 2
        ),array(
            'id' => '2',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 3
        ),array(
            'id' => '4',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 4
        )
        ,array(
            'id' => '5',
            'name' => '图片55',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=6',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 5
        ),
    ),
    
);
// var_dump($fis_data["recommandgamelist"]);