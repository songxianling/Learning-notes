<?php




//$recommandgamelist = require(__DIR__ . '/index_recommandlist.php');
//$tradehighqualitylistModel = require(__DIR__ . '/index_tradehighqualitylist.php');
//$tradelistModel = require(__DIR__ . '/index_newposttradelist.php');
//$helper = require(__DIR__ . '/index_helper.php');
//$noticelistModel = require(__DIR__ . '/index_noticelistModel.php');
$fis_data = array(
    'ImageServerHost' => 'http://img.taoshouyou.com',
    // 'ImageServerHost' => 'http://192.168.0.10:8088',
    
    'title' => '淘手游-最具影响力的手游交易第一平台',
    'lang' => 'en-US',
    'CsrfParam' => "_csrf",
    'CsrfToken' => "eVQ1OTgzSEZAHXdqbWV4DSA5WXEBZiw1OxV0T1AGKX8KGH8IUH58MA==",
    'description' => '淘手游—国内最安全、最权威、服务最完善的手游交易第一平台：提供最具性价比的游戏账号、装备、金币，手游代充等自由买卖、担保寄售交易、安全快捷！淘手游手游交易平台。',
    'metakeyword' => '淘手游,淘手游交易平台,淘手游官网,淘手游手游交易平台,手游交易,手游交易平台,手游交易网,手机游戏交易,手机游戏交易平台',
    // 'imgHost' => 'http://img.taoshouyou.com',
    'imgHost' => 'http://192.168.0.10:8088',
    
    'user' => [
        "isGuest"=>true,    //用户是否匿名访问，在YII中用Yii::$app->user->isGuest获取 
        'username' => '张三',
        'mobile' => '',
        'pic' => '/img/2015-08-03/8/a7ad78745af1057747880b7816e5bfc2.png', //用户头像
    ],
    'bottomAd'=> [ //全局右下角浮动提示
        'title'=> "天天裁决游戏下载", //广告位标题
        'picurl'=> "http://img-test.taoshouyou.com/img/2016-08-30/19/581db75da5c91c804ac7143669037901.gif", //广告位图片地址
        'href'=> "http://9.taoshouyou.com/download/games/6/tiantiancaijue-1_0_0_0" //广告位跳转地址

    ],
    'banner'=>array( //轮播图
        array(
                'picurl' => "/img/2016-08-31/12/8d69dd4d62e71154f12e82e9f44e4433-pc-l.jpg", //轮播图页面地址
                'href'=> "http://www.taoshouyou.com" //轮播图跳转地址   
            ),

    ),
    "ControllerUniqueId" => "indexpage/indexs",  //Controller的唯一id
    //个人信息
    'userInfo' => array(
    	'id' => 445055,
        'username' => '幽影冥狐',
        'realyname' => '是对的撒',
        'certtype' => 1,
        'certno' => '112233445566789',
        'certapproved' => 2,
        'certapprovetime' => 2,
        'certpic' => '/img/2016-04-18/4/d1ddb4dc172d14cb3028dfaf3fe4ed48-pc-l.gif',
        'check_remarks' => null,
        'password' => '63b6aede2da3ea47b227a6cfb860e8a2',
        'passwordlev' => null,
        'authkey' => 'ccdfb8',
        'email' => '123456@1.com',
        'mobile' => '13911037319',
        'ischeckmobile' => 1,
        'sex' => 2,
        'nickname' => '幽影',
        'pic' => '/img/2016-08-15/8/9fdf527c73f1430b64701f4a6f1a2f43-pc-l.jpg',
        'account_weibo' => null,
        'account_qq' => '12222222',
        'qq_openid' => null,
        'usergroupids' => null,
        'buyercredit' => null,
        'sellercredit' => null,
        'newpm' => 0,
        'Islocked' => 0,
        'Islockeddate' => null,
        'lastloginip' => '127.0.0.1',
        'lastlogindate' => '2016-09-08 15:23:52',
        'lastpasswordchangeddate' => null,
        'failedpasswordattemptcount' => 0,
        'failedpasswordattemptwindowstart' => null,
        'failedpasswordanswerattemptcount' => 0,
        'failedpasswordanswerattemptwindowstart' => null,
        'comment' => null,
        'regip' => '123.116.32.142',
        'isdel' => 0,
        'regsource' => 0,
        'addtime' => '2015-11-17 10:00:27',					
	),
	//我的游戏
	'articleList' => array(
    	array(
			'id' => '12',
            'gameid' => '6',
            'pic' => '/img/2016-06-15/2/fe2700f1ad18c83e2481e2d2eeb01e8c.jpg',
            'type' => '2',
            'author' => '淘手游',
            'isdownload' => '0',
            'islist' => '1',
            'iscontent' => '1',
            'title' => '《天天裁决》之夺宝奇兵攻略',
            'introduction' => '',
            'publisher_id' => '658497',
            'publisher_name' => '木小鱼',
            'addtime' => '2016-06-15 19:27:53',
            'gamename' => '天天裁决',
            'typename' => '攻略',
		),
		array(
			'id' => '11',//攻略ID
            'gameid' => '6',
            'pic' => '/img/2016-06-15/14/abdf6c4c1114c7ea431f7ca28b302c43.jpg',
            'type' => '2',
            'author' => '淘手游',
            'isdownload' => '0',
            'islist' => '0',
            'iscontent' => '1',
            'title' => '《天天裁决》秦陵地宫副本攻略',
            'introduction' => '文章导读',
            'publisher_id' => '658497',
            'publisher_name' => '木小鱼',
            'addtime' => '2016-06-15 19:24:24',
            'gamename' => '天天裁决',
            'typename' => '攻略',
		),			
	),
	//列表信息
	'gameInfo' => array(
		'id' => '6',
    	'name' => '天天裁决',
    	'spelling' => 'tiantiancaijue',
	),
	//全部游戏
	'totalCount' => 100,
	//广告位
	'ad' => array(
		'id' => '60',
	    'title' => '天天裁决游戏下载',
	    'picurl' => 'http://192.168.0.10:8088/img/2016-09-08/12/8d69dd4d62e71154f12e82e9f44e4433.jpg',
	    'href' => 'http://bj-test-game.taoshouyou.com:8096/',
	    'isshow' => '1',
	    'position' => '11',
	    'type' => '2',
	    'addtime' => '2016-09-08 15:34:31',		
	),
	
    'bannerlist' => array(
        array(
            'id' => '1',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 1
        ),
        array(
            'id' => '3',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 2
        ),array(
            'id' => '2',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 3
        ),array(
            'id' => '4',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 4
        )
        ,array(
            'id' => '5',
            'name' => '图片55',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=6',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 5
        ),
    ),
    
);
// var_dump($fis_data["recommandgamelist"]);