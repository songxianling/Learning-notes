<?php
//性价比推荐--测试数据
return array(
	array(
		"id"=>"1", 
		"tradeid"=>"173478", 
		"tradename"=>" 霸气江湖 安卓91 23区 白金号甩卖", 
		"tradeprice"=>"220.000", 
		"adduserid"=>"1", 
		"addusername"=>"lion", 
		"isshow"=>"1", 
		"isdel"=>"0", 
		"sort"=>"0", 
		"addtime"=>"2015-07-02 19:13:21", 
		'pic' => '/img/2016-06-15/31/3fdf7a0cf7a1579b5f0914de6f2b0d56-pc-l.jpg',
		'picurl' => '/img/2016-07-26/15/ca9ed113077f9a0db01cbaabbfeee5c8-pc-l.jpg',
		"isfixedprice"=>"0",
		"trades" => array(
			"goodsid" => 1,
			"discount" => NULL,
			"price" => "220.00"
			)
	),
	array(
		"id"=>"1",
		"tradeid"=>"173478",
		"tradename"=>" 霸气江湖 安卓91 23区 白金号甩卖",
		"tradeprice"=>"220000",
		"adduserid"=>"1",
		"addusername"=>"lion",
		"isshow"=>"1",
		"isdel"=>"0",
		"sort"=>"0",
		"addtime"=>"2015-07-02 19:13:21",
		'pic' => '/img/2016-06-15/31/3fdf7a0cf7a1579b5f0914de6f2b0d56-pc-l.jpg',
		'picurl' => '/img/2016-07-26/16/cc5a9a11a7dc387d77d3adbb56ea1df7-pc-l.jpg',
		"isfixedprice"=>"1",
		"trades" => array(
			"goodsid" => 1,
			"discount" => NULL,
			"price" => "220000.00"
		)
	),
	array(
		"id"=>"1",
		"tradeid"=>"173478",
		"tradename"=>" 霸气江湖 安卓91 23区 白金号甩卖",
		"tradeprice"=>"100",
		"adduserid"=>"1",
		"addusername"=>"lion",
		"isshow"=>"1",
		"isdel"=>"0",
		"sort"=>"0",
		"addtime"=>"2015-07-02 19:13:21",
		'pic' => '/img/2016-06-15/31/3fdf7a0cf7a1579b5f0914de6f2b0d56-pc-l.jpg',
		'picurl' => '/img/2016-07-26/15/ca9ed113077f9a0db01cbaabbfeee5c8-pc-l.jpg',
		"isfixedprice"=>"1",
		"trades" => array(
			"goodsid" => 1,
			"discount" => NULL,
			"price" => "100."
		)
	),
	array(
		"id"=>"1",
		"tradeid"=>"173478",
		"tradename"=>" 霸气江湖 安卓91 23区 白金号甩卖",
		"tradeprice"=>"2323",
		"adduserid"=>"1",
		"addusername"=>"lion",
		"isshow"=>"1",
		"isdel"=>"0",
		"sort"=>"0",
		"addtime"=>"2015-07-02 19:13:21",
		'pic' => '/img/2016-06-15/31/3fdf7a0cf7a1579b5f0914de6f2b0d56-pc-l.jpg',
		'picurl' => '/img/2016-07-26/16/cc5a9a11a7dc387d77d3adbb56ea1df7-pc-l.jpg',
		"isfixedprice"=>"1",
		"trades" => array(
			"goodsid" => 1,
			"discount" => NULL,
			"price" => "2323.00"
		)
	),
	array(
		"id"=>"1",
		"tradeid"=>"173478",
		"tradename"=>" 霸气江湖 安卓91 23区 白金号甩卖",
		"tradeprice"=>"23230",
		"adduserid"=>"1",
		"addusername"=>"lion",
		"isshow"=>"1",
		"isdel"=>"0",
		"sort"=>"0",
		"addtime"=>"2015-07-02 19:13:21",
		'pic' => '/img/2016-06-15/31/3fdf7a0cf7a1579b5f0914de6f2b0d56-pc-l.jpg',
		'picurl' => '/img/2016-07-26/15/ca9ed113077f9a0db01cbaabbfeee5c8-pc-l.jpg',
		"isfixedprice"=>"1",
		"trades" => array(
			"goodsid" => 1,
			"discount" => NULL,
			"price" => "23230.00"
		)
	),
	array(
		"id"=>"1",
		"tradeid"=>"173478",
		"tradename"=>" 霸气江湖 安卓91 23区 白金号甩卖",
		"tradeprice"=>"23230",
		"adduserid"=>"1",
		"addusername"=>"lion",
		"isshow"=>"1",
		"isdel"=>"0",
		"sort"=>"0",
		"addtime"=>"2015-07-02 19:13:21",
		'pic' => '/img/2016-06-15/31/3fdf7a0cf7a1579b5f0914de6f2b0d56-pc-l.jpg',
		'picurl' => '/img/2016-07-26/16/cc5a9a11a7dc387d77d3adbb56ea1df7-pc-l.jpg',
		"isfixedprice"=>"1",
		"trades" => array(
			"goodsid" => 1,
			"discount" => NULL,
			"price" => "0.10"
		)
	),
);