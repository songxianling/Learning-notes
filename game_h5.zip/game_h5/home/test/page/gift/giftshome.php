<?php




//$recommandgamelist = require(__DIR__ . '/index_recommandlist.php');
//$tradehighqualitylistModel = require(__DIR__ . '/index_tradehighqualitylist.php');
//$tradelistModel = require(__DIR__ . '/index_newposttradelist.php');
//$helper = require(__DIR__ . '/index_helper.php');
//$noticelistModel = require(__DIR__ . '/index_noticelistModel.php');
$fis_data = array(
    'ImageServerHost' => 'http://img.taoshouyou.com',
    // 'ImageServerHost' => 'http://192.168.0.10:8088',
    
    'title' => '淘手游-最具影响力的手游交易第一平台',
    'lang' => 'en-US',
    'CsrfParam' => "_csrf",
    'CsrfToken' => "eVQ1OTgzSEZAHXdqbWV4DSA5WXEBZiw1OxV0T1AGKX8KGH8IUH58MA==",
    'description' => '淘手游—国内最安全、最权威、服务最完善的手游交易第一平台：提供最具性价比的游戏账号、装备、金币，手游代充等自由买卖、担保寄售交易、安全快捷！淘手游手游交易平台。',
    'metakeyword' => '淘手游,淘手游交易平台,淘手游官网,淘手游手游交易平台,手游交易,手游交易平台,手游交易网,手机游戏交易,手机游戏交易平台',
    // 'imgHost' => 'http://img.taoshouyou.com',
    'imgHost' => 'http://192.168.0.10:8088',
    
    'user' => [
        "isGuest"=>true,    //用户是否匿名访问，在YII中用Yii::$app->user->isGuest获取 
        'username' => '张三',
        'mobile' => '',
        'pic' => '/img/2015-08-03/8/a7ad78745af1057747880b7816e5bfc2.png', //用户头像
    ],
    'bottomAd'=> [ //全局右下角浮动提示
        'title'=> "天天裁决游戏下载", //广告位标题
        'picurl'=> "http://img-test.taoshouyou.com/img/2016-08-30/19/581db75da5c91c804ac7143669037901.gif", //广告位图片地址
        'href'=> "http://9.taoshouyou.com/download/games/6/tiantiancaijue-1_0_0_0" //广告位跳转地址

    ],
    'banner'=>array( //轮播图
        array(
                'picurl' => "/img/2016-08-31/12/8d69dd4d62e71154f12e82e9f44e4433-pc-l.jpg", //轮播图页面地址
                'href'=> "http://www.taoshouyou.com" //轮播图跳转地址   
            ),

    ),
    "ControllerUniqueId" => "indexpage/indexs",  //Controller的唯一id
    //推荐礼包2条数据 推荐-独家礼包
    'giftSortList' => array(
    	array(
    		'id' => '2',
			'gameid' => '游戏ID',
		    'gift_name' => '礼包名称',
		  	'gamepic' =>  '游戏图标',
		  	'spelling' => '游戏拼音',
		    'os' => '系统(1：ios 2:android 3：其他)',
		    'total_count_ratio' => "库存量（%）",
		),
		array(
			'id' => '2',
			'gameid' => '游戏ID',
		    'gift_name' => '礼包名称',
		  	'gamepic' =>  '游戏图标',
		  	'spelling' => '游戏拼音',
		    'os' => '系统(1：ios 2:android 3：其他)',
		    'total_count_ratio' => "库存量（%）",
		),		
	),
	//热门推荐游戏
	'hotGames' => array(
    	array(
    		'id' => "32",
            'name' => "士大夫士大夫",
            'spelling' => "shidafu", //游戏全拼
            'pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif", //游戏图片icon 
            'categoryid' => "14",
            'recommend_pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif",
            'quit_game_cashback_ratio' => "0.00",
            'has_android' => "1",
            'has_ios' => "1",
            'comment' => "12344",
            'download_count' => 1000,
            'android_qrpic' => "/game/qr/android/32",
            'android_download_url' => "http://www.taoshouyou.com", //android 下载地址
            'ios_qrpic' => "/game/qr/ios/32",
            'ios_download_url' => "http://www.taoshouyou.com", //ios 下载地址
            'categoryname' => "棋牌桌球",
		),	
		array(
    		'id' => "32",
            'name' => "士大夫士大夫",
            'spelling' => "shidafu", //游戏全拼
            'pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif", //游戏图片icon 
            'categoryid' => "14",
            'recommend_pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif",
            'quit_game_cashback_ratio' => "0.00",
            'has_android' => "1",
            'has_ios' => "1",
            'comment' => "12344",
            'download_count' => 1000,
            'android_qrpic' => "/game/qr/android/32",
            'android_download_url' => "http://www.taoshouyou.com", //android 下载地址
            'ios_qrpic' => "/game/qr/ios/32",
            'ios_download_url' => "http://www.taoshouyou.com", //ios 下载地址
            'categoryname' => "棋牌桌球",
		),	
		array(
    		'id' => "32",
            'name' => "士大夫士大夫",
            'spelling' => "shidafu", //游戏全拼
            'pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif", //游戏图片icon 
            'categoryid' => "14",
            'recommend_pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif",
            'quit_game_cashback_ratio' => "0.00",
            'has_android' => "1",
            'has_ios' => "1",
            'comment' => "12344",
            'download_count' => 1000,
            'android_qrpic' => "/game/qr/android/32",
            'android_download_url' => "http://www.taoshouyou.com", //android 下载地址
            'ios_qrpic' => "/game/qr/ios/32",
            'ios_download_url' => "http://www.taoshouyou.com", //ios 下载地址
            'categoryname' => "棋牌桌球",
		),	
		array(
    		'id' => "32",
            'name' => "士大夫士大夫",
            'spelling' => "shidafu", //游戏全拼
            'pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif", //游戏图片icon 
            'categoryid' => "14",
            'recommend_pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif",
            'quit_game_cashback_ratio' => "0.00",
            'has_android' => "1",
            'has_ios' => "1",
            'comment' => "12344",
            'download_count' => 1000,
            'android_qrpic' => "/game/qr/android/32",
            'android_download_url' => "http://www.taoshouyou.com", //android 下载地址
            'ios_qrpic' => "/game/qr/ios/32",
            'ios_download_url' => "http://www.taoshouyou.com", //ios 下载地址
            'categoryname' => "棋牌桌球",
		),	
		array(
    		'id' => "32",
            'name' => "士大夫士大夫",
            'spelling' => "shidafu", //游戏全拼
            'pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif", //游戏图片icon 
            'categoryid' => "14",
            'recommend_pic' => "/img/2016-08-31/11/fa65adc847112a682867000b9b3586a1-pc-l.gif",
            'quit_game_cashback_ratio' => "0.00",
            'has_android' => "1",
            'has_ios' => "1",
            'comment' => "12344",
            'download_count' => 1000,
            'android_qrpic' => "/game/qr/android/32",
            'android_download_url' => "http://www.taoshouyou.com", //android 下载地址
            'ios_qrpic' => "/game/qr/ios/32",
            'ios_download_url' => "http://www.taoshouyou.com", //ios 下载地址
            'categoryname' => "棋牌桌球",
		),			
	),
	// 广告位信息
    "pageAd" => array(
		  "picurl" => "图片地址",
	       "href" => "跳转地址",
		),
	// 礼包列表(6条数据)(推荐-首页)
	'giftList' => array(
		array(
			'id' => '2',
	    	'gameid' => '游戏ID',
	      	'gamename' => '游戏名称',
	      	'spelling' => '游戏拼音',
	      	'gamepic' => '游戏图标',
	        'gift_name' => '礼包名称',
	        'start_time' => '开始时间',
	        'end_time' => '结束时间',
	        'os' => '系统(1：ios 2:android 3：其他)',
	        'description' => '礼包描述',
	        'manual' => '使用说明',
	        'total_count_ratio' => '23',
	        ),
	        array(
	        'id' => '2',
	    	'gameid' => '游戏ID',
	      	'gamename' => '游戏名称',
	      	'spelling' => '游戏拼音',
	      	'gamepic' => '游戏图标',
	        'gift_name' => '礼包名称',
	        'start_time' => '开始时间',
	        'end_time' => '结束时间',
	        'os' => '系统(1：ios 2:android 3：其他)',
	        'description' => '礼包描述',
	        'manual' => '使用说明',
	        'total_count_ratio' => '23',
	        ),
	        array(
	        'id' => '2',
	    	'gameid' => '游戏ID',
	      	'gamename' => '游戏名称',
	      	'spelling' => '游戏拼音',
	      	'gamepic' => '游戏图标',
	        'gift_name' => '礼包名称',
	        'start_time' => '开始时间',
	        'end_time' => '结束时间',
	        'os' => '系统(1：ios 2:android 3：其他)',
	        'description' => '礼包描述',
	        'manual' => '使用说明',
	        'total_count_ratio' => '23',
	        ),
	        array(
	        'id' => '2',
	    	'gameid' => '游戏ID',
	      	'gamename' => '游戏名称',
	      	'spelling' => '游戏拼音',
	      	'gamepic' => '游戏图标',
	        'gift_name' => '礼包名称',
	        'start_time' => '开始时间',
	        'end_time' => '结束时间',
	        'os' => '系统(1：ios 2:android 3：其他)',
	        'description' => '礼包描述',
	        'manual' => '使用说明',
	        'total_count_ratio' => '23',
	        ),
	        array(
	        'id' => '2',
	    	'gameid' => '游戏ID',
	      	'gamename' => '游戏名称',
	      	'spelling' => '游戏拼音',
	      	'gamepic' => '游戏图标',
	        'gift_name' => '礼包名称',
	        'start_time' => '开始时间',
	        'end_time' => '结束时间',
	        'os' => '系统(1：ios 2:android 3：其他)',
	        'description' => '礼包描述',
	        'manual' => '使用说明',
	        'total_count_ratio' => '23',
	        ),
	        array(
	        'id' => '2',
	    	'gameid' => '游戏ID',
	      	'gamename' => '游戏名称',
	      	'spelling' => '游戏拼音',
	      	'gamepic' => '游戏图标',
	        'gift_name' => '礼包名称',
	        'start_time' => '开始时间',
	        'end_time' => '结束时间',
	        'os' => '系统(1：ios 2:android 3：其他)',
	        'description' => '礼包描述',
	        'manual' => '使用说明',
	        'total_count_ratio' => '23',
	        ),						
	),
    'bannerlist' => array(
        array(
            'id' => '1',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 1
        ),
        array(
            'id' => '3',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 2
        ),array(
            'id' => '2',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 3
        ),array(
            'id' => '4',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 4
        )
        ,array(
            'id' => '5',
            'name' => '图片55',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=6',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 5
        ),
    ),
    
);
// var_dump($fis_data["recommandgamelist"]);