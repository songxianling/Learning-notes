<?php





$fis_data = array(
    'ImageServerHost' => 'http://img.taoshouyou.com',
    // 'ImageServerHost' => 'http://192.168.0.10:8088',
    
    'game2goodsIndex' => $game2goodsIndex,
    'title' => '淘手游-最具影响力的手游交易第一平台',
    'lang' => 'en-US',
    'CsrfParam' => "_csrf",
    'CsrfToken' => "eVQ1OTgzSEZAHXdqbWV4DSA5WXEBZiw1OxV0T1AGKX8KGH8IUH58MA==",
    'description' => '淘手游—国内最安全、最权威、服务最完善的手游交易第一平台：提供最具性价比的游戏账号、装备、金币，手游代充等自由买卖、担保寄售交易、安全快捷！淘手游手游交易平台。',
    'metakeyword' => '淘手游,淘手游交易平台,淘手游官网,淘手游手游交易平台,手游交易,手游交易平台,手游交易网,手机游戏交易,手机游戏交易平台',
    // 'imgHost' => 'http://img.taoshouyou.com',
    'imgHost' => 'http://192.168.0.10:8088',
    'user' => [
        "isGuest"=>true,    //用户是否匿名访问，在YII中用Yii::$app->user->isGuest获取 
        'username' => '张三',
        'mobile' => '',
        'pic' => '/img/2015-08-03/8/a7ad78745af1057747880b7816e5bfc2.png', //用户头像
    ],
    "ControllerUniqueId" => "indexpage/indexs",  //Controller的唯一id
    'bannerlist' => array(
        array(
            'id' => '1',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 1
        ),
        array(
            'id' => '3',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 2
        ),array(
            'id' => '2',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 3
        ),array(
            'id' => '4',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 4
        )
        ,array(
            'id' => '5',
            'name' => '图片55',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=6',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 5
        ),
    ),
    'giftInfo' => array(
        'gameid' => '5',
        'gift_name' => '梦幻西游新手礼包标题名称梦幻西游新手礼包标题名称梦幻西游新手礼包标题名称',
        'start_time' => '2016-08-04 00 : 00 : 00',
        'end_time' => '2016-12-31 23 : 59 : 59',
        'os' => '1',
        'pic' => 'img/2344.png',
        'description' => '200绑定元宝，金钥匙*1，大方无隅（7天），大烟花*1、精钢*3',
        'manual' => '游戏右上角-领奖-激活-输入兑奖码-邮箱领取',
        'total_count_ratio' => '95.1',
        'related_gifts' => array(
            array(
                'gameid' => '5',
                'gift_name' => '游戏礼包名游戏礼包名游戏礼包名',
                'total_count_ratio' => '88'
            ),
            array(
                'gameid' => '5',
                'gift_name' => '游戏礼包名游戏礼包名游戏礼包名',
                'total_count_ratio' => '88'
            ),
            array(
                'gameid' => '5',
                'gift_name' => '游戏礼包名游戏礼包名游戏礼包名',
                'total_count_ratio' => '88'
            ),
            array(
                'gameid' => '5',
                'gift_name' => '游戏礼包名游戏礼包名游戏礼包名',
                'total_count_ratio' => '88'
            ),
            array(
                'gameid' => '5',
                'gift_name' => '游戏礼包名游戏礼包名游戏礼包名',
                'total_count_ratio' => '88'
            ),
            array(
                'gameid' => '5',
                'gift_name' => '游戏礼包名游戏礼包名游戏礼包名',
                'total_count_ratio' => '88'
            )
        ),
    ),
    'pageAd' => array(
        'picurl' => '图片地址',
        'href' => '跳转地址'
    ),
    'gameInfo' => array(
        'id' => '5',
        'name' => '梦幻西游',
        'spelling' => '2016-08-04 00 : 00 : 00',
        'pic' => '2016-12-31 23 : 59 : 59',
        'os' => '1',
        'qrCode' => '200绑定元宝，金钥匙*1，大方无隅（7天），大烟花*1、精钢*3',
        'downloadurl' => '游戏右上角-领奖-激活-输入兑奖码-邮箱领取',
        'categoryid' => '角色扮演',
        'categoryname' => '角色扮演',
        'fake_download_count' => '72637283',
        'comment' => '2016国民手游，网易手游史诗级巨作，新门派化生寺隆重登场，人人都玩，无处不在！'
    ),
    'topiclist' => array(
        array(
            'id' => '1',
            'title' => '1D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-08-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),
        array(
            'id' => '2',
            'title' => '2D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),array(
            'id' => '3',
            'title' => '3D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),array(
            'id' => '4',
            'title' => '4D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),
    ),
    "recommendShopsList" => [
        0 => [
            'onlineTradeNum' => 0,
            'shopname' => '赵科平的店',
            'recommendedindex' => '3',
            'shoppic' => null,
            'id' => '406'
        ],
        1 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        2 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        3 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        4 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
    ],
    "tradelogcountModel" => "1000",  //安全成交笔数
    "tradeloglistModel" => array(    //右侧最新成交数量
        array(
            "tradeid" => 198607,
            "tradename" => "飒飒的"
        ),array(
            "tradeid" => 198605,
            "tradename" => "用途图一图一"
        ),array(
            "tradeid" => 198605,
            "tradename" => "123123"
        ),array(
            "tradeid" => 198605,
            "tradename" => "432423"
        ),
    ),
    "initiallist" => ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"],
    'recommandgamelist' => $recommandgamelist,
    'tradehighqualitylistModel' =>$tradehighqualitylistModel,
    'tradelistModel' =>$tradelistModel,
    'helpModel' => $helper,
    'complaintModel' => array(array("id"=>"3", "title"=>"111111111111111", ),array("id"=>"2", "title"=>"1111111111", ),array("id"=>"1", "title"=>"111"),array("id"=>"4", "title"=>"111"),array("id"=>"5", "title"=>"111"),array("id"=>"6", "title"=>"111") ),
    'noticelistModel' => $noticelistModel,
    'friendLink' => array(
        array(
            'id' => '1',
            'name' => '手游交易',
            'url' => 'http://www.taoshouyou.com'
        ),
        array(
            'id' => '3',
            'name' => '手机游戏专区',
            'url' => 'http://www.gao7.com/zq/'
        ),array(
            'id' => '2',
            'name' => '苹果角色扮演游戏下载',
            'url' => 'http://app.tongbu.com/iphone-jiaoseyouxi/苹果角色扮演游戏下载'
        )
    ),
    'pageadlist' => array(
        'isshow' => 1,
        'href' => 'http://www.baidu.com',
        'title' => '所得税地方',
        'picurl' => '/img/2016-05-05/23/72711197f7a22d345f7df4409cc277c0-pc-l.jpg',
    ),
    'pageadlistfloat' => array(
        'isshow' => 1,
        'href' => 'http://www.baidu.com',
        'title' => '所得税地方',
        'picurl' => '/img/2016-05-05/23/72711197f7a22d345f7df4409cc277c0-pc-l.jpg',
    ),
);
// var_dump($fis_data["recommandgamelist"]);