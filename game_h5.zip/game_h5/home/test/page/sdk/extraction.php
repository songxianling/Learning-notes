<?php





$fis_data = array(
    'ImageServerHost' => 'http://img.taoshouyou.com',
    // 'ImageServerHost' => 'http://192.168.0.10:8088',
    
    'game2goodsIndex' => $game2goodsIndex,
    'title' => '淘手游-最具影响力的手游交易第一平台',
    'lang' => 'en-US',
    'CsrfParam' => "_csrf",
    'CsrfToken' => "eVQ1OTgzSEZAHXdqbWV4DSA5WXEBZiw1OxV0T1AGKX8KGH8IUH58MA==",
    'description' => '淘手游—国内最安全、最权威、服务最完善的手游交易第一平台：提供最具性价比的游戏账号、装备、金币，手游代充等自由买卖、担保寄售交易、安全快捷！淘手游手游交易平台。',
    'metakeyword' => '淘手游,淘手游交易平台,淘手游官网,淘手游手游交易平台,手游交易,手游交易平台,手游交易网,手机游戏交易,手机游戏交易平台',
    // 'imgHost' => 'http://img.taoshouyou.com',
    'imgHost' => 'http://192.168.0.10:8088',
    'user' => [
        "isGuest"=>true,    //用户是否匿名访问，在YII中用Yii::$app->user->isGuest获取 
        'username' => '张三',
        'mobile' => '',
        'pic' => '/img/2015-08-03/8/a7ad78745af1057747880b7816e5bfc2.png', //用户头像
    ],
    "ControllerUniqueId" => "indexpage/indexs",  //Controller的唯一id
    'bannerlist' => array(
        array(
            'id' => '1',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 1
        ),
        array(
            'id' => '3',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 2
        ),array(
            'id' => '2',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 3
        ),array(
            'id' => '4',
            'name' => '图片33',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 4
        )
        ,array(
            'id' => '5',
            'name' => '图片55',
            'url' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=6',
            'src' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'sort' => 5
        ),
    ),
    'gameInfo' => array(
        'id' => '1',
           'name' => '梦幻西游',
           'size' => '2322.98',
           'comment' => '2016国民手游，网易手游诗史级巨作，新门派化生寺隆重登场，无处不在。',
           'categoryid' => 'http://img.taoshouyou.com/focus/pc/wakuang.png?t=5g',
           'quit_game_cashback_ratio' => '15.00',
           'has_android' => '1',
           'has_ios' => '1',
           'os' => '1',
           'pic' => '',
           'spelling' => '',
           'addtime' => '20016-06-27',
           'vendor_name' => '淘手游',
           'ischarge' => '1',
           'render_engine' => '2',
           'support_system' => 'Android 4.0以上',
           'score' => '9.7',
           'comment' => '2016国民手游，网易手游史诗级巨作，新门派化生寺 隆重登场，人人都玩，无处不在！人人都玩，无处不 在！',
           'extra_info' => '<span>梦幻西游游戏官方群：1234567775</span><span>官方游戏QQ客服：39102832</span>',
           'gamepic' => array(
               0 => '/img/2016-07-25/12/4e25b54a5a16a7ee4fdde76d3c92e190-pc-l.jpg',
               1 => '/img/2016-07-25/24/8583d8149a55a2ee9d4daf7f6197bd4d-pc-l.jpg',
               2 => '/img/2016-07-25/9/c074810108ecd2a7d6a634f299148de0-pc-l.jpg',
               3 => '/img/2016-07-25/22/4eb8f9babf2364ed6ebcc08e22735b85-pc-l.jpg',
               4 => '/img/2016-07-25/4/30b5346ee826896bfe2a38708e4514df-pc-l.jpg'
           ),
           'introduce' => '<p>梦幻西游安卓版中不论是场景还是整个的画面的设计都是具有玄幻色彩的，这里的整个的作品气息都笼罩在了古典之中，而再加上Q萌的角色，这样的配置会骚乱你的心哦，休闲时间挑战本作，展开西游新的梦哦。该作只要是你进入了，就能被其中的仙气的画面相融合，而那些视觉上的特色也是精致的哦。</p><p>【游戏特色】</p><p>-人人都玩，无处不在</p><p>《梦幻西游》手游自问世以来，新增注册用户突破1亿，并凭不竭魅力，源源不断的吸引新玩家，用事实证明国民手游的卓越品质。而在未来，它还将不断改写历史，为每一个玩家延续自己的西游剑侠情缘！</p>',
           'download_count' => '24444',
           'android_qrpic' => '12345.html',
           'android_download_url' => '12345.html',
           'ios_qrpic' => '24325435.jpg',
           'ios_download_url' => 'img.img.jpg',
           'categoryname' => '角色扮演'
    ),
    'pageAd' => array(
        'picurl' => '1',
        'href' => '图片33'
    ),
    'giftList' => array(
        array(
            'gameid' => '1',
            'gift_name' => '梦幻西游-新手礼包大放送大大大',
            'start_time' => '2016-08-04 00:00:00',
            'end_time' => '2016-12-31 23:59:59',
            'os' => '1',
            'description' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'manual' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'total_count_ratio' => '85.1'
        ),
        array(
            'gameid' => '1',
            'gift_name' => '暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明',
            'start_time' => '2016-08-04 00 : 00 : 00',
            'end_time' => '2016-12-31 23 : 59 : 59',
            'os' => '1',
            'description' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'manual' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'total_count_ratio' => '95.1'
        ),
        array(
            'gameid' => '1',
            'gift_name' => '暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明',
            'start_time' => '2016-08-04 00 : 00 : 00',
            'end_time' => '2016-12-31 23 : 59 : 59',
            'os' => '1',
            'description' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'manual' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'total_count_ratio' => '65.1'
        ),
        array(
            'gameid' => '1',
            'gift_name' => '暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明',
            'start_time' => '2016-08-04 00 : 00 : 00',
            'end_time' => '2016-12-31 23 : 59 : 59',
            'os' => '1',
            'description' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'manual' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'total_count_ratio' => '75.1'
        ),
        array(
            'gameid' => '1',
            'gift_name' => '暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明暗黑黎明',
            'start_time' => '2016-08-04 00 : 00 : 00',
            'end_time' => '2016-12-31 23 : 59 : 59',
            'os' => '1',
            'description' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'manual' => '/img/2016-04-20/27/2d186c7beae345c2534141dffd1f4e40.jpg',
            'total_count_ratio' => '95.1'
        )
    ),
    'topiclist' => array(
        array(
            'id' => '1',
            'title' => '1D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-08-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),
        array(
            'id' => '2',
            'title' => '2D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),array(
            'id' => '3',
            'title' => '3D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),array(
            'id' => '4',
            'title' => '4D手游首充号2折起',
            'src' => '/img/2016-05-12/9/3d10ba7a23c6323b26d1d8b8bf9f6bd0-pc-l.jpg',
            'url' => 'http://taoshouyou.com',
            'endtime' => '2015-07-30 11:59:59',
            'price' => '1000',
            'sort' => 2
        ),
    ),
    "recommendShopsList" => [
        0 => [
            'onlineTradeNum' => 0,
            'shopname' => '赵科平的店',
            'recommendedindex' => '3',
            'shoppic' => null,
            'id' => '406'
        ],
        1 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        2 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        3 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
        4 => [
            'onlineTradeNum' => 0,
            'shopname' => '钻石店铺',
            'recommendedindex' => '5',
            'shoppic' => '/img/2016-04-10/14/1fab082a95118273432140c96e1e867e-pc-l.jpg',
            'id' => '438'
        ],
    ],
    "tradelogcountModel" => "1000",  //安全成交笔数
    "tradeloglistModel" => array(    //右侧最新成交数量
        array(
            "tradeid" => 198607,
            "tradename" => "飒飒的"
        ),array(
            "tradeid" => 198605,
            "tradename" => "用途图一图一"
        ),array(
            "tradeid" => 198605,
            "tradename" => "123123"
        ),array(
            "tradeid" => 198605,
            "tradename" => "432423"
        ),
    ),
    "initiallist" => ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"],
    'recommandgamelist' => $recommandgamelist,
    'tradehighqualitylistModel' =>$tradehighqualitylistModel,
    'tradelistModel' =>$tradelistModel,
    'helpModel' => $helper,
    'complaintModel' => array(array("id"=>"3", "title"=>"111111111111111", ),array("id"=>"2", "title"=>"1111111111", ),array("id"=>"1", "title"=>"111"),array("id"=>"4", "title"=>"111"),array("id"=>"5", "title"=>"111"),array("id"=>"6", "title"=>"111") ),
    'noticelistModel' => $noticelistModel,
    'friendLink' => array(
        array(
            'id' => '1',
            'name' => '手游交易',
            'url' => 'http://www.taoshouyou.com'
        ),
        array(
            'id' => '3',
            'name' => '手机游戏专区',
            'url' => 'http://www.gao7.com/zq/'
        ),array(
            'id' => '2',
            'name' => '苹果角色扮演游戏下载',
            'url' => 'http://app.tongbu.com/iphone-jiaoseyouxi/苹果角色扮演游戏下载'
        )
    ),
    'pageadlist' => array(
        'isshow' => 1,
        'href' => 'http://www.baidu.com',
        'title' => '所得税地方',
        'picurl' => '/img/2016-05-05/23/72711197f7a22d345f7df4409cc277c0-pc-l.jpg',
    ),
    'pageadlistfloat' => array(
        'isshow' => 1,
        'href' => 'http://www.baidu.com',
        'title' => '所得税地方',
        'picurl' => '/img/2016-05-05/23/72711197f7a22d345f7df4409cc277c0-pc-l.jpg',
    ),
    's_sdk_userextraction' => array(
        array(
            'bizno' => 1,
            'price' => '20.00',
            'banktype' => 1,
            'addtime' => '2016-04-22   23:13:33',
            'auditnote' => '备注备注吧',
            'auditingstates' => 1,
            'taxprice' => "0.5",
        ),
        array(
            'bizno' => 1,
            'price' => '20.00',
            'banktype' => 1,
            'addtime' => '2016-04-22   23:13:33',
            'auditnote' => '备注备注吧',
            'auditingstates' => 1,
            'taxprice' => "0.5",
        ),
        array(
            'bizno' => 1,
            'price' => '20.00',
            'banktype' => 1,
            'addtime' => '2016-04-22   23:13:33',
            'auditnote' => '备注备注吧',
            'auditingstates' => 1,
            'taxprice' => "0.5",
        ),
        array(
            'bizno' => 1,
            'price' => '20.00',
            'banktype' => 1,
            'addtime' => '2016-04-22   23:13:33',
            'auditnote' => '备注备注吧',
            'auditingstates' => 1,
            'taxprice' => "0.5",
        ),
        
    )

);
// var_dump($fis_data["recommandgamelist"]);