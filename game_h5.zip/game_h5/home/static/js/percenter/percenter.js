;define('home.static.js.percenter.percenter', function() {
		var $accQuestion = $('#js-question'), //个人中心中的 问号按钮
			$accPercentermark = $('#percenter-mark'), //点问号要出来的盒子
			$accmarkClose = $('#mark-close'); //弹出盒子中的关闭
		$accQuestion.on('click',function () {			
			$accPercentermark.show();
		});
		$accPercentermark.on('click',function (event) {			
			$(this).hide();
		});
		$accmarkClose.on('click',function (event) {			
			$accPercentermark.hide();
		});
		
		$('#mark-con').on('click',function (event) {
			event.stopPropagation();
		});
		
		
		
		
	// 退游返现弹出层js
	//弹出框操作、
	var commonClass = require("common.static.js.common"),
	    $markLayou =  $('#js-tuiyou-mark'), //点了退游返现弹出的大盒子
		$cancelLayou = $('#js-percenter-cancel'), //弹出层中的取消按钮
		gameuserid,
		cryid;
	$('.js-percenter-tuiyou').on('click',function () {

		if($(this).attr("data-pre")=="0" || $(this).attr("data-pre")=="0.00"){
			$(".js-mygame-mark2").show();
			$(".js-mygame-btns").on("click",function(){
				$(".js-mygame-mark2").hide();
			})
		}else{
			gameuserid = $(this).attr('data-id');
			$markLayou.show();
			cryid = $(this).attr('data-cry');
		}

	});
	$markLayou.on('click',function (event) {			
		$(this).hide();
	});
	$cancelLayou.on('click',function (event) {			
		$markLayou.hide();
	});
	
	$('#mark-con').on('click',function (event) {
		event.stopPropagation();
	});
	//弹出框的获取验证码倒计时
	var wait=60,
		textCode = "获取短信验证码",
		$errorInfoBox = $('#js-error-info'),
		$getCode = $('#js-percenter-get-code'), // 获取验证码的按钮
		$markOn = $('#js-percenter-markOn'); //确定按钮
		function time(o) {
	        if (wait == 0) {		        			                     
	            o.val(textCode);	
	            $getCode.removeClass('no-click');
	            wait = 60;
	        } else {
	        	$getCode.addClass('no-click');
	            o.val(wait +"s");
	            wait--;
	            setTimeout(function() {
	                time(o);
	            },
	            1000)
	        }
	    }
		$getCode.click(function(){						
			var url2 = '/com/verify/sms-vcode-user?position=1';
			data = {};			
			commonClass.newcommonAjax(url2,data,time($getCode));
		});
		
		var sdkAgent = $('#js-agent').val();
		
		
		$markOn.click(function () {
			var vfcCode = $('#js-percenter-vfcCode').val();				
			$.ajax({
					type:"post",
					url:"/usercenter/mygame/quit",
					async:true,
					dataType: "json",
					xhrFields:{withCredentials:true},
					data:{
						'gameuserid' : gameuserid,
						'verifycode' : vfcCode,
					},
					success:function (data) {
						if(data.errcode == 0){
							if(sdkAgent == 'TaoshouyouSDK'){
								window.sdk.clickOnSDK(cryid);
							}else{
								window.location.href = "/user/home/index";	
							}
							$markLayou.hide();
						}else{
							var msgInfo = data.msg;
							$errorInfoBox.html(msgInfo);
							$errorInfoBox.show();
						}
						
					}					
				});
		});
		
		var perurl = $('#js-perurl').val();
		
		$('#js-logout').on('click',function () {
			$.ajax({
				type:"post",
				url:perurl+"/api/user/logout",
				async:true,
				data:{},
				xhrFields:{withCredentials:true},
				success:function (data) {
					window.location.href = "/";		
				}	
			});
		});
		
		
		
		
		
		
		
		
		
		
	});

	
	
