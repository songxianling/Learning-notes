define('home.static.js.help.help', function () {
    
    // var $videoBox1 = $("#video-box1");
    // var $closeBtn1 = $("#close-btn1");
    // $closeBtn1.on("click",function(){
    //     document.getElementById('video2').pause();
    //     $videoBox1.hide();
    // });
	
})