define('home.static.js.errorpage.errorpage', function() {
		
})
