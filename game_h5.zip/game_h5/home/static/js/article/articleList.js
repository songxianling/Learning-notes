;define('home.static.js.article.articleList', function() {
	var commonClass = require("common.static.js.common"),
		index = 1,
		load = true,
		gameid = $("#js-gameId").val(),
		spelling = $("#js-spelling").val(),
		imghost = $('#js-imghost').val();
		
	$('#p-articleList-jz-move').on('click', function() {
		if(load){
			index ++;			
			var url = "/gonglue/page-ajax/"+gameid+"-"+index,
			data = {};			
			commonClass.newcommonAjax(url,data,zjMove);			
		}				
	});
		var $el = $("#List");
		function zjMove (data) {
			var dataAry = data.data.list,
				hasMore = data.data.hasmore;
			if(dataAry != "" && dataAry !=null){				
			var html = "";							
				for (var i=0;i<dataAry.length;i++) {					
					html='<li class="article-box clearfix">'+
					     '<a href="/gonglue/'+dataAry[i].spelling+'-'+dataAry[i].gameid+'-'+dataAry[i].id+'">'+
							'<div class="top clearfix" id="top">'+
								'<img src="'+imghost+''+dataAry[i].pic+'" alt="" />'+
								'<div class="right-box clearfix">'+
									'<p>'+dataAry[i].title+'</p>'+
									'<span>'+dataAry[i].typename+'</span>'+
									'<p><i></i><span>'+dataAry[i].addtime+'</span></p>'+
							'</div></div></a></li>';
					$el.append(html);	
				}
			if(hasMore == 0){
				load = false;
				$('#p-articleList-jz-move').html("全部数据已加载完成！");
				}
			}
		}

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scParAd = $(".sc_article_ad");

    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/article/default";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })

});
