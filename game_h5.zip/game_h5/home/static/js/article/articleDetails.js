;define('home.static.js.article.articleDetails', function() {

    // 神策统计
    var comAjax = require("common.static.js.common");
    var $scParAd = $(".sc_article_ad");

    $scParAd.on("click",function(){
        var postUrl = "click",
            data = {};

        data.clk_page_uri = "/article/default/view";
        data.clk_target_url = $(this).attr('href')&&$(this).attr('href')!="javascript:void(0)"?$(this).attr('href'):"";
        data.clk_item_index = 0;
        data.clk_name_en = $(this).attr('data-sc')?$(this).attr('data-sc'):"";

        comAjax.commonAjax(postUrl,data); 
    })

});
